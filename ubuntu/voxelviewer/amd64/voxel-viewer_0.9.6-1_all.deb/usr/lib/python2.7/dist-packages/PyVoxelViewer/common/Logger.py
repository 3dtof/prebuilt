#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from StreamWrapper import StreamWrapper
from PySide import QtGui, QtCore

from Common import makePath

from functools import partial

from datetime import datetime

from PyVoxelViewer.models.DataQueue import DataQueue

from PyVoxelViewer.common.ProducerConsumerThread import ProducerConsumerThread

import os

import Voxel

class LogMessage:
  def __init__(self, level, message):
    self.level = level
    self.message = message

#
# 
# Use Logger.writeLog(loglevel, message) to write log messages from python
#
#
#
class Logger(QtCore.QObject):
  
  outputAvailable = QtCore.Signal(object, object)
  
  loggers = []
  
  def __init__(self, parent = None):
    super(Logger, self).__init__(parent)
    
    self.logger = Voxel.cvar.logger
    
    self.logQueue = DataQueue(maxlen = None)
    
    self.stdout = StreamWrapper(self, True)
    self.stderr = StreamWrapper(self, False)
    
    self.f = None
    self.fileName = None
    
    c = Voxel.Configuration()
    
    r, logFileName = c.getLocalFile('logs', 'log.txt')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Path failed', 'Failed to get log directory')
      return
    
    self.setLogFileName(logFileName)
    
    self.loggerThread = ProducerConsumerThread(self.callBack, self.writeOutput)
    
    self.streamIndex = self.logger.addOutputStream(self.loggerThread.produceFunction)
    self.stdout.outputWritten.connect(partial(Logger.writeLog, Voxel.LOG_INFO))
    self.stderr.outputWritten.connect(partial(Logger.writeLog, Voxel.LOG_ERROR))
    
    Logger.loggers.append(self)
    
  def getLogFileName(self):
    return self.fileName
  
  def setLogFileName(self, fileName):
    if not makePath(fileName):
      QtGui.QMessageBox.critical(self, 'Log file', 'Failed to create directory "' + d + '"')
      return
    
    try:
      f = open(fileName, 'a')
    except IOError, e:
      QtGui.QMessageBox.critical(self, 'Log file', 'Failed to open file "' + fileName + '"')
      return
    
    self.f = f
    self.fileName = fileName
    
    Logger.writeLog(Voxel.LOG_INFO, '\n\n\n==========================================\n')
    Logger.writeLog(Voxel.LOG_INFO, 'Starting log at ' + str(datetime.now()) + '\n')
    Logger.writeLog(Voxel.LOG_INFO, '==========================================\n')
    
  def writeOutput(self):
    l = self.logQueue.tryGet()
    while l is not None:
      if self.f is not None:
        self.f.write(l.message)
      self.outputAvailable.emit(l.level, l.message)
      
      l = self.logQueue.tryGet()
    
  def callBack(self, message):
    if isinstance(message, str):
      self.logQueue.put(LogMessage(self.logger.getCurrentLogLevel(), message))
    elif isinstance(message, tuple):
      self.logQueue.put(LogMessage(*message))
    
  @staticmethod
  def writeLog(level, out):
    for l in Logger.loggers:
      l.loggerThread.produceFunction((level, out))
    
  
  def getDefaultLogLevel(self):
    return self.logger.getDefaultLogLevel()
  
  def setDefaultLogLevel(self, logLevel):
    return self.logger.setDefaultLogLevel(logLevel)
    
  def stop(self):
    print 'Deleting logger...'
    self.logger.removeOutputStream(self.streamIndex)
    self.loggerThread.stop()
    Logger.loggers.remove(self)