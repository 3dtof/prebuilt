#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from PyVoxelViewer.views.ParameterHandler import ParameterHandler
from PyVoxelViewer.models.Config import Config

import os

import shutil

import Voxel

from CalibrationPage import CalibrationPage, Calibration
from FactoryCalibrationLensPage import CalibrationLensPage
#from CalibrationLensPageCalculus import CalibrationLensPageCalculus
from FactoryCommonPhaseCalibration import CalibrationCommonPhasePage
from CalibrationPixelwisePhasePage import CalibrationPixelWisePhasePage
from CalibrationWriteToHardwarePage import CalibrationWriteToHardwarePage
from CalibrationDeleteConfFiles import CalibrationDeteteConfFiles
#from FactoryCommonPhaseCalibration import CalibrationCommonPhasePageModified
#from CalibrationWriteToConfPage import CalibrationWriteToConfPage
    
class CalibrationWizardBase(QtGui.QWizard):
  
  def __init__(self, cameraSystem, depthCamera, parent = None, flags = 0):
    super(CalibrationWizardBase, self).__init__(parent, flags)
    
    self.ready = False
    
    self.depthCamera = depthCamera
    self.cameraSystem = cameraSystem
    
    self.setMinimumHeight(600)
    self.setMinimumWidth(400)
    
    self.setWizardStyle(QtGui.QWizard.ModernStyle)
    self.setWindowTitle('Calibration Wizard')
    self.setOption(QtGui.QWizard.IndependentPages, False)
    
    self.mainConfiguration = self.depthCamera.configFile
    self.setPreviousConfiguration(self.depthCamera.getCurrentCameraProfileID())
    self.currentConfiguration = None
    self.currentProfileID = None
    self.currentProfileFileName = None
    self.isNewProfile = False
    
    self.accepted.connect(self.onCompletion)
    self.rejected.connect(self.restorePreviousCondition)
    
    self.currentIdChanged.connect(self.onPageChange)
    
    self.pages = []
    self.pageMap = {}
    self.doShowMap = {}
    
  def addCalibrationPage(self, name, page):
    self.pages.append(page)
    self.addPage(page)
    self.pageMap[name] = page
    self.doShowMap[name] = True
    
  def setPreviousConfiguration(self, id):
    c = self.depthCamera.configFile.getCameraProfile(id)
    
    if not c:
      QtGui.QMessageBox.critical(self, 'Calibration Wizard', 'Could not get configuration for camera profile "' + self.depthCamera.getCurrentCameraProfileID() + '"')
      return
    
    self.previousConfiguration = Voxel.ConfigurationFile(c)
    self.previousProfileID = self.depthCamera.getCurrentCameraProfileID()
    
  def isReady(self):
    return self.ready
  
  def onPageChange(self, currentID):
    p = self.currentPage()
    
    if hasattr(p, 'enterPage'):
      p.enterPage()
  
  def closePages(self):
    for p in self.pages:
      if isinstance(p, CalibrationPage):
        p.closePage()
  
  def restorePreviousCondition(self):
    
    if self.isNewProfile and self.currentProfileID:
      self.depthCamera.removeCameraProfile(self.currentProfileID)
      
    if not self.isNewProfile and self.previousConfiguration:
      p = self.depthCamera.configFile.getCameraProfile(self.previousProfileID)
      
      if p:
        p.copy(self.previousConfiguration)
    
    self.depthCamera.setCameraProfile(self.previousProfileID)
    
  def nextId(self):
    p = self.currentPage()
    
    id = self.currentId() + 1
    nextPage = self.page(id)
    
    if not nextPage:
      return -1
    
    if not isinstance(nextPage, CalibrationPage):
      return id
    
    while nextPage and not nextPage.doShow:
      if not nextPage.isPresentInPrevious():
        if not hasattr(nextPage, 'skipQuestionAnswer'):
          # r = QtGui.QMessageBox.question(self, nextPage.title(), 'Necessary parameters are not present for skipping "' + nextPage.title() + '" step.' + 
          #                        ' Do you want to really skip this step?', 
          #                        buttons = QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
          # 
          # if r == QtGui.QMessageBox.No:
          # return id
          # else:
          # nextPage.skipQuestionAnswer = True
          nextPage.skipQuestionAnswer = True
        else:
          if not nextPage.skipQuestionAnswer:
            return id
      id = id + 1
      nextPage = self.page(id)
      
      if not isinstance(nextPage, CalibrationPage):
        return id
    
    if not nextPage:
      return -1
    else:
      return id
    
class FactoryCalibrationWizard(CalibrationWizardBase):
  
  PROFILE_LENS_ONLY = "Lens Only"
  PROFILE_LONG_RANGE = "Long Range"
  PROFILE_SHORT_RANGE = "Short Range"
  PROFILE_HIGH_AMBIENT = "High Ambient"
  
  def __init__(self, cameraSystem, depthCamera, parent = None, flags = 0):
    super(FactoryCalibrationWizard, self).__init__(cameraSystem, depthCamera, parent, flags)
    
    self.setOption(QtGui.QWizard.DisabledBackButtonOnLastPage, True)
    
    info = self.depthCamera.configFile.getCalibrationInformation()
    
    calibPages = [
      ('lens', CalibrationLensPage), 
      ('common_phase_offset', CalibrationCommonPhasePage), 
      ('common_phase_offset', CalibrationCommonPhasePage), 
      ('common_phase_offset', CalibrationCommonPhasePage),
      ('pixelwise_phase_offset', CalibrationPixelWisePhasePage) 

    ]
    
    for i, c in calibPages:
      if info.has_key(i):
        inf = info[i]
        p = c(self, inf.id, definingParams = list(inf.definingParameters), calibParams = dict((el, 0) for el in list(inf.calibrationParameters)))
        p.doShow = True
        self.addCalibrationPage(i, p)
    self.addPage(CalibrationWriteToHardwarePage(self))
   # self.addPage(CalibrationDeteteConfFiles(self))
    
    # Create self.currentConfigurations for desired profiles
    self.currentConfigurations = {}
    self.currentConfigurationIDs = {}
    self.framesToCapture = None
    self.phaseCorrs = ''
    names = self.depthCamera.getCameraProfileNames().items()
    
    for id, name in names:
      p = self.depthCamera.configFile.getCameraProfile(id)
      
      if p is None:
        continue
      
      if ((name == FactoryCalibrationWizard.PROFILE_LENS_ONLY or  name ==FactoryCalibrationWizard.PROFILE_LONG_RANGE or name == FactoryCalibrationWizard.PROFILE_SHORT_RANGE or name ==FactoryCalibrationWizard.PROFILE_HIGH_AMBIENT) and (p.getLocation() == Voxel.ConfigurationFile.IN_HOST)):
        self.currentConfigurations[name] = p
        self.currentConfigurationIDs[name] = id
        
    
    
    self.currentProfileID = self.currentConfigurationIDs[FactoryCalibrationWizard.PROFILE_LENS_ONLY]
    self.currentProfileName = FactoryCalibrationWizard.PROFILE_LENS_ONLY
    self.depthCamera.setCameraProfile(self.currentProfileID)
    self.ready = True
    
  def onCompletion(self):
    pass # No default saving operations
    
  def onPageChange(self, currentID): 
    p = self.currentPage()
    
    if currentID==0:
      #self.pages[currentID].writeDefiningParams(self.currentConfigurations[FactoryCalibrationWizard.PROFILE_LENS_ONLY])  
      self.currentConfiguration = self.currentConfigurations[FactoryCalibrationWizard.PROFILE_LENS_ONLY]
      self.currentProfileID = self.currentConfigurationIDs[FactoryCalibrationWizard.PROFILE_LENS_ONLY]
      self.currentProfileName = FactoryCalibrationWizard.PROFILE_LENS_ONLY
      self.depthCamera.setCameraProfile(self.currentProfileID)
    elif currentID ==1 or currentID == 4:
      #self.pages[currentID].writeDefiningParams(self.currentConfigurations[FactoryCalibrationWizard.PROFILE_LONG_RANGE])    
      self.currentConfiguration = self.currentConfigurations[FactoryCalibrationWizard.PROFILE_LONG_RANGE]
      self.currentProfileID = self.currentConfigurationIDs[FactoryCalibrationWizard.PROFILE_LONG_RANGE]
      self.currentProfileName = FactoryCalibrationWizard.PROFILE_LONG_RANGE
      self.depthCamera.setCameraProfile(self.currentProfileID)
    elif currentID == 2:
      #self.pages[currentID].writeDefiningParams(self.currentConfigurations[FactoryCalibrationWizard.PROFILE_SHORT_RANGE])    
      self.currentConfiguration = self.currentConfigurations[FactoryCalibrationWizard.PROFILE_SHORT_RANGE]
      self.currentProfileID = self.currentConfigurationIDs[FactoryCalibrationWizard.PROFILE_SHORT_RANGE]
      self.currentProfileName = FactoryCalibrationWizard.PROFILE_SHORT_RANGE
      self.depthCamera.setCameraProfile(self.currentProfileID)
    
    elif currentID == 3:
      #self.pages[currentID].writeDefiningParams(self.currentConfigurations[FactoryCalibrationWizard.PROFILE_HIGH_AMBIENT])    
      self.currentConfiguration = self.currentConfigurations[FactoryCalibrationWizard.PROFILE_HIGH_AMBIENT]
      self.currentProfileID = self.currentConfigurationIDs[FactoryCalibrationWizard.PROFILE_HIGH_AMBIENT]
      self.currentProfileName = FactoryCalibrationWizard.PROFILE_HIGH_AMBIENT
      self.depthCamera.setCameraProfile(self.currentProfileID)    
      #self.depthCamera.setDefaultCameraProfile(self.currentProfileID)
      
    else:
      self.currentConfiguration = self.currentConfigurations[FactoryCalibrationWizard.PROFILE_LONG_RANGE]
      self.currentProfileID = self.currentConfigurationIDs[FactoryCalibrationWizard.PROFILE_LONG_RANGE]
      self.currentProfileName = FactoryCalibrationWizard.PROFILE_LONG_RANGE
      self.depthCamera.setCameraProfile(self.currentProfileID)
    super(FactoryCalibrationWizard, self).onPageChange(currentID)