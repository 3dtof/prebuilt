#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

import Voxel

from PySide import QtGui, QtCore

import numbers

from XYSpinBox import XYSpinBox

from functools import partial

from ParameterHandler import ParameterHandler

class IntegrationDutyCycleView(QtGui.QWidget):
  valueChanged = QtCore.Signal()
  
  @staticmethod
  def getID():
    return "intg_time"
  
  def getTitle(self):
    return "Integration Duty Cycle (" + IntegrationDutyCycleView.getID() + ")"
  
  def __init__(self, window, depthCameraController):
    super(IntegrationDutyCycleView, self).__init__()
    
    self.window = window
    self.depthCameraController = depthCameraController
    
    self.paramWidget = None
    
    vlayout = QtGui.QVBoxLayout(self)
    
    self.depthCamera = self.depthCameraController.getDepthCamera()
    
    if self.depthCamera:
      p = ParameterHandler.getParameterHandler(self.depthCamera, IntegrationDutyCycleView.getID())
      
      if p:
        self.paramWidget = p.getDetailedDisplayWidget()
        self.paramWidget.valueChanged.connect(self.valueChanged)
        self.paramWidget.spinbox.setSingleStep(3)
        vlayout.addWidget(self.paramWidget)
        
    self.frameRate = QtGui.QLabel()
    self.frameRate.setStyleSheet('QLabel { color: #777; }')
    self.frameRate.setAlignment(QtCore.Qt.AlignCenter)
    
    vlayout.addWidget(self.frameRate)
    
    self.setSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Minimum)
    
    self.init()
    
    self.valueChanged.connect(self.init)
      
  @QtCore.Slot()
  def init(self):
    
    if self.depthCamera is None:
      return
    
    if self.paramWidget:
      self.paramWidget.init()
    
    r, f = self.depthCamera.getFrameRate()
    
    r1, intgTime = self.depthCamera.getu(IntegrationDutyCycleView.getID())
    
    if r and r1:
      self.frameRate.setText('Integration time = %.2f ms'%(10.0/f.getFrameRate()*intgTime))
       
       
       