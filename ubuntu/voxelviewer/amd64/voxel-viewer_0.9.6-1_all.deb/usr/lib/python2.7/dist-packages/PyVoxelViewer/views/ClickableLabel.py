#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

class ClickableLabel(QtGui.QLabel):
  
  clicked = QtCore.Signal()
  
  def __init__(self, parent = None):
    super(ClickableLabel, self).__init__(parent)
    
  def mouseReleaseEvent(self, ev):
    self.clicked.emit()