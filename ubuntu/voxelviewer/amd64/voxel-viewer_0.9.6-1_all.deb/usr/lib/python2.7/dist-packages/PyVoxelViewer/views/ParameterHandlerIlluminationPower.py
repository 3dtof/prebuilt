#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

import Voxel

from PySide import QtGui, QtCore

import numbers

from XYSpinBox import XYSpinBox

from functools import partial

from ParameterHandler import ParameterHandler

class IlluminationPowerView(QtGui.QWidget):
  valueChanged = QtCore.Signal()
  
  paramsToShow = {
    "illum_power_percentage": "illum_power",
    "illum_volt": ""
  }
  
  @staticmethod
  def getID():
    return "illum_control"
  
  def getTitle(self):
    
    if self.param:
      return self.param.getDisplayName() + " (" + self.param.getName() + ")"
    else:
      return "Illumination Control"
  
  def __init__(self, window, depthCameraController):
    super(IlluminationPowerView, self).__init__()
    
    self.window = window
    self.depthCameraController = depthCameraController
    
    self.paramWidget = None
    
    vlayout = QtGui.QVBoxLayout(self)
    
    self.details = QtGui.QLabel()
    
    self.depthCamera = self.depthCameraController.getDepthCamera()
    
    if self.depthCamera:
      self.param = ParameterHandler.getParameterHandler(self.depthCamera, "illum_power_percentage")
      
      if not self.param:
        self.param = ParameterHandler.getParameterHandler(self.depthCamera, "illum_volt")
      
      if self.param:
        self.paramWidget = self.param.getDetailedDisplayWidget()
        self.paramWidget.valueChanged.connect(self.valueChanged)
        vlayout.addWidget(self.paramWidget)
      else:
        self.details.setText('Parameter not available')
    
    self.details.setStyleSheet('QLabel { color: #777; }')
    self.details.setAlignment(QtCore.Qt.AlignCenter)
    
    vlayout.addWidget(self.details)
    
    self.setSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Minimum)
    
    self.init()
    
    self.valueChanged.connect(self.init)
      
  @QtCore.Slot()
  def init(self):
    
    if self.depthCamera is None or self.param is None:
      return
    
    if self.paramWidget:
      self.paramWidget.init()
    
    t = ''
    
    n = self.paramsToShow[self.param.getName()]
    
    if n:
      p = ParameterHandler.getParameterHandler(self.depthCamera, n)
      
      if p:
        t += p.getName() + " = " + p.getDisplayValue()
        
    self.details.setText(t)