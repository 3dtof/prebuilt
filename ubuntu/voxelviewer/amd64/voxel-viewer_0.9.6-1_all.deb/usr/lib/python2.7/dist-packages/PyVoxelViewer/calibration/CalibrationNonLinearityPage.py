#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui
from CalibrationPage import CalibrationPage, c

import os
import csv

import numpy as np

class CalibrationNonLinearityTableDelegate(QtGui.QItemDelegate):
  def __init__(self, parent = None):
    super(CalibrationNonLinearityTableDelegate, self).__init__(parent)
    
  
  def createEditor(self, parent, option, index):
    if index.column() == 1 or index.column() == 2:
      spinbox = QtGui.QSpinBox(parent)
      spinbox.setRange(0, 4095)
    else:
      spinbox = QtGui.QDoubleSpinBox(parent)
      spinbox.setRange(0, 200) # 200m
      spinbox.setSingleStep(0.001)
      spinbox.setDecimals(3)
      
    return spinbox

class CalibrationNonLinearityPage(CalibrationPage):
  
  CSV_FILE_NAME = 'non-linearity.csv'
  MAX_PHASE_VALUE = 4096
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationNonLinearityPage, self).__init__(calibrationWizard, index, parent = parent, 
          definingParams = definingParams, calibParams = calibParams)
          
    self.calibrationWizard = calibrationWizard
    
    self.setTitle('Non-linearity Calibration')
    self.setSubTitle('Computation of non-linearity of phase vs distance. Please measure the phase value at cx, cy')
    
    self.layout = QtGui.QVBoxLayout(self)
    
    hlayout = QtGui.QHBoxLayout()
    self.centerPointText = QtGui.QLabel()
    hlayout.addWidget(self.centerPointText)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Phase Period'))
    
    self.phasePeriod = QtGui.QComboBox()
    if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
      self.phasePeriod.addItems(['90 degrees', '180 degrees'])
      self.phasePeriod.setCurrentIndex(1)
    else:
      self.phasePeriod.addItems(['90 degrees', '180 degrees', '360 degrees'])
      self.phasePeriod.setCurrentIndex(2)
    
    hlayout.addWidget(self.phasePeriod)
    
    hlayout.addStretch()
    
    self.calibrateButton = QtGui.QPushButton('&Calibrate')
    self.calibrateButton.pressed.connect(self.calibrate)
    self.calibrateButton.setShortcut('Alt+C')
    hlayout.addWidget(self.calibrateButton)
    
    self.layout.addLayout(hlayout)
    
    r, dealiasEnabled = self.depthCamera.getb('dealias_en')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not read "dealias_en" parameter')
      return
    
    self.dealiasEnabled = dealiasEnabled
    
    groupbox = QtGui.QGroupBox()
    groupbox.setTitle('Phase vs Distance Measurements')
    self.layout.addWidget(groupbox)
    vglayout = QtGui.QVBoxLayout()
    groupbox.setLayout(vglayout)
    
    self.phaseDistanceMeasurements = QtGui.QTableWidget()
    
    if self.dealiasEnabled and self.depthCamera.chipset() != CalibrationPage.CHIPSET_CALCULUS:
      self.rowLength = 3
      self.phaseDistanceMeasurements.setColumnCount(self.rowLength)
      self.phaseDistanceMeasurements.setHorizontalHeaderLabels(['Actual Distance', 'Phase 1', 'Phase 2'])
    else:
      self.rowLength = 2
      self.phaseDistanceMeasurements.setColumnCount(self.rowLength)
      self.phaseDistanceMeasurements.setHorizontalHeaderLabels(['Actual Distance', 'Phase 1'])
      
    self.phaseDistanceMeasurements.setContextMenuPolicy(QtCore.Qt.ActionsContextMenu)
    self.phaseDistanceMeasurements.setToolTip('Please ensure that entries are in increasing order of distance')
    self.phaseDistanceMeasurements.setItemDelegate(CalibrationNonLinearityTableDelegate())
    vglayout.addWidget(self.phaseDistanceMeasurements)
    
    insertRowAction = QtGui.QAction('Insert Row', self.phaseDistanceMeasurements)
    insertRowAction.setShortcut('Insert')
    insertRowAction.triggered.connect(self.insertRow)
    self.phaseDistanceMeasurements.addAction(insertRowAction)
    
    removeRowAction = QtGui.QAction('Remove Row', self.phaseDistanceMeasurements)
    removeRowAction.setShortcut('Del')
    removeRowAction.triggered.connect(self.removeRow)
    self.phaseDistanceMeasurements.addAction(removeRowAction)
    
    removeAllRowsAction = QtGui.QAction('Remove All Rows', self.phaseDistanceMeasurements)
    removeAllRowsAction.setShortcut('Shift+Del')
    removeAllRowsAction.triggered.connect(self.removeAllRows)
    self.phaseDistanceMeasurements.addAction(removeAllRowsAction)
    
    self.importCSVButton = QtGui.QPushButton('&Import From CSV')
    self.importCSVButton.setShortcut('Alt+I')
    self.importCSVButton.pressed.connect(self.importCSV)
    vglayout.addWidget(self.importCSVButton)
    
    self.paramsGroupbox = QtGui.QGroupBox()
    self.paramsGroupbox.setTitle('Non-linearity Parameters')
    self.layout.addWidget(self.paramsGroupbox)
    
    self.paramsText = QtGui.QTextEdit()
    self.paramsText.setReadOnly(True)
    self.paramsText.setMinimumHeight(100)
    
    vglayout = QtGui.QVBoxLayout()
    vglayout.addWidget(self.paramsText)
    self.paramsGroupbox.setLayout(vglayout)
    
    self.paramsGroupbox.hide()
    
    self.calibrated = False
    
  def isComplete(self):
    return self.calibrated
    
  def insertRow(self):
    i = self.phaseDistanceMeasurements.currentRow()
    
    if i >= 0 and i < self.phaseDistanceMeasurements.rowCount():
      self.phaseDistanceMeasurements.insertRow(i + 1)
    elif self.phaseDistanceMeasurements.rowCount() == 0:
      self.phaseDistanceMeasurements.insertRow(0)
      
  def removeRow(self):
    i = self.phaseDistanceMeasurements.currentRow()
    
    if i >= 0 and i < self.phaseDistanceMeasurements.rowCount():
      
      r = QtGui.QMessageBox.question(self, 'Remove Row', 'Are you sure you want to remove the current row?', \
            buttons = QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
      
      if r == QtGui.QMessageBox.Yes:
        self.phaseDistanceMeasurements.removeRow(i)
        
  def removeAllRows(self):
    r = QtGui.QMessageBox.question(self, 'Remove All Rows', 'Are you sure you want to remove all rows?', \
            buttons = QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
      
    if r == QtGui.QMessageBox.Yes:
      for i in range(0, self.phaseDistanceMeasurements.rowCount()):
        self.phaseDistanceMeasurements.removeRow(0)
    
  def writeCSV(self, data, csvFile):
    with open(csvFile, 'w') as f:
      for r in data:
        f.write(','.join(format(c, ".3f") for c in r) + '\n')
    
  def importCSV(self, csvFile = None):
    
    if csvFile is None:
      name, filter = QtGui.QFileDialog.getOpenFileName(self, 'Select CSV File', filter = '*.csv (CSV Files)')
      
      if name:
        csvFile = str(name)
      else:
        return
      
    if not os.path.exists(csvFile):
      return
    
    with open(csvFile, 'rb') as f:
      reader = csv.reader(f)
      
      c = 0
      for row in reader:
        if len(row) != self.rowLength:
          QtGui.QMessageBox.critical(self, 'Invalid row count', 'Expected %d columns per row,' + 
                                     ' but got %d for row %d.'%(self.rowLength, len(row), c))
          return
        
        r = self.phaseDistanceMeasurements.rowCount()
        self.phaseDistanceMeasurements.insertRow(self.phaseDistanceMeasurements.rowCount())
        
        for i in range(0, len(row)):
          self.phaseDistanceMeasurements.setItem(r, i, QtGui.QTableWidgetItem(row[i]))
        
        c += 1
      
  
  def initializePage(self):
    super(CalibrationNonLinearityPage, self).initializePage()
    
    self.centerPointText.setText('From lens calibration, cx = %.1f, cy = %.1f'%( \
      round(self.calibrationWizard.currentConfiguration.getFloat('calib', 'cx'), 1), \
        round(self.calibrationWizard.currentConfiguration.getFloat('calib', 'cy'), 1)))
    
    if os.path.exists(self.basePath + os.sep + CalibrationNonLinearityPage.CSV_FILE_NAME):
      self.importCSV(self.basePath + os.sep + CalibrationNonLinearityPage.CSV_FILE_NAME)
      
    
    
  def getData(self):
    d = []
    for r in range(0, self.phaseDistanceMeasurements.rowCount()):
      x = []
      for c in range(0, self.rowLength):
        t = self.phaseDistanceMeasurements.item(r, c).text()
        
        if len(t) == 0:
          QtGui.QMessageBox.critical(self, 'Data Missing', 'Data at row = %d, column = %d is empty'%(r, c))
          return []
        x.append(float(t))
      
      d.append(x)
      
    return d
      
    
  def calibrate(self):
    
    d1 = self.getData()
    
    if len(d1) == 0:
      QtGui.QMessageBox.critical(self, 'Data Missing', 'Cannot perform calibration with missing data')
      return
    
    mf = self.getModulationFrequencies()
    
    if mf == False:
      return
    
    mf1, mf2 = mf
    
    ds1 = c/(2*mf1*1E6)
    
    
    if mf2:
      ds2 = c/(2*mf2*1E6)
      
    d = np.array(d1)
    
    if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
      phasePeriods = [1024, 2048]
      phaseIntervals = 9
    else:
      phasePeriods = [1024, 2048, 4096]
      phaseIntervals = 16
    
    p = phasePeriods[self.phasePeriod.currentIndex()]
    
    d = d[d[:,0].argsort()]
    
    # Handling floating point overflows in arange with []
    x = np.arange(0, p, p/phaseIntervals, dtype = np.float32)[0:phaseIntervals]/4096.0
    
    y1 = np.interp(x*ds1, d[:,0], d[:,1])
    y1 = np.around(y1).astype(np.int16)
    y1 = y1 % 4096
    print y1
    
    self.calibParams['phase_lin_corr_period'] = self.phasePeriod.currentIndex()
    
    if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
      self.calibParams['phase_lin_coeff'] = ' '.join(np.char.mod('%d', y1))
      self.paramsText.setText(('phase_lin_coeff = %s,\nphase_lin_corr_period = %d')%\
        (self.calibParams['phase_lin_coeff'], self.calibParams['phase_lin_corr_period']))
    else:
      self.calibParams['phase_lin_coeff0'] = ' '.join(np.char.mod('%d', y1))
      
      if mf2:
        y2 = np.interp(x*ds2, d[:,0], d[:,2])
        y2 = np.around(y2)
        y2 = y2 % 4096
        print y2
        self.calibParams['phase_lin_coeff1'] = ' '.join(np.char.mod('%d', y2))
      else:
        self.calibParams['phase_lin_coeff1'] = ''
      
      self.paramsText.setText(('phase_lin_coeff0 = %s,\nphase_lin_coeff1 = %s,\nphase_lin_corr_period = %d')%\
        (self.calibParams['phase_lin_coeff0'], self.calibParams['phase_lin_coeff1'], self.calibParams['phase_lin_corr_period']))
    
    self.paramsGroupbox.show()
    self.calibrated = True
    
    self.writeCSV(d1, self.basePath + os.sep + CalibrationNonLinearityPage.CSV_FILE_NAME)
    
    self.completeChanged.emit()
  
  def wrapPhaseToSignedInteger(self, phase):
    if phase >= CalibrationNonLinearityPage.MAX_PHASE_VALUE/2:
      return -1*(CalibrationNonLinearityPage.MAX_PHASE_VALUE - phase)
    else:
      return phase