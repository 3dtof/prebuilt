#
# TI Voxel Viewer component.
#
# Copyright (c) 2015 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from functools import partial

import Voxel

from PyVoxelViewer.dialogs.StatisticsDialog import StatisticsDialog
from PyVoxelViewer.calibration.CalibrationWizard import CalibrationWizard
from PyVoxelViewer.factoryCalibration.FactoryCalibrationWizard import  FactoryCalibrationWizard
from PyVoxelViewer.dialogs.ProfilesManagerDialog import ProfilesManagerDialog


class ProfilesMenu(QtGui.QMenu):
  
  def __init__(self, window, parent = None):
    super(ProfilesMenu, self).__init__(parent)
      
    self.window = window
    self.statusBar = window.statusMessage
    self.dataEngine = window.dataEngine
    self.depthCameraStreamController = window.depthCameraStreamController
    
    self.depthCameraStreamController.onDepthCameraSet.connect(self.initMenu)
    
    self.initMenu()
    
    self.setTitle('&Camera Profiles')

  def initMenu(self):
    self.clear()
    
    d = self.depthCameraStreamController.getDepthCamera()
    
    if not d:
      return
    
    names = sorted(d.getCameraProfileNames().items(), key = lambda x: (d.configFile.getCameraProfile(x[0]).getLocation() << 16) + x[0], reverse = True)
    
    if len(names) == 0:
      return

    cameraProfilesGroup = QtGui.QActionGroup(self, exclusive = True)

    for id, n in names:
      profile = d.configFile.getCameraProfile(id)
      
      if profile:
        if profile.getLocation() == Voxel.ConfigurationFile.IN_CAMERA:
          n += " (HW)";
        a = QtGui.QAction(n, self)
        a.triggered.connect(partial(self.setCameraProfile, name = n, id = id))
        a.setCheckable(True)
        self.addAction(a)

        if d.getCurrentCameraProfileID() == id:
          a.setChecked(True)
        a.setActionGroup(cameraProfilesGroup)
      
    self.addSeparator()
    
    a = QtGui.QAction('&Manage Profiles', self)
    a.triggered.connect(self.showProfilesManager)
    self.addAction(a)
    
    a = QtGui.QAction('&Calibration Wizard', self)
    a.triggered.connect(self.showCalibrationWizard)
    self.addAction(a)
    
    a = QtGui.QAction('Factory Calibration &Wizard', self)
    a.triggered.connect(self.showFactoryCalibrationWizard)
    self.addAction(a)
    
    
  def showProfilesManager(self):
    d = self.depthCameraStreamController.getDepthCamera()
    
    if not d:
      QtGui.QMessageBox.critical(self, 'Calibration Wizard', 'Depthcamera not connected. Please connect to do calibration')
      return
    
    self.depthCameraStreamController.disconnectDepthCamera(onlyFromUI = True)
    
    ProfilesManagerDialog.showDialog(self.depthCameraStreamController.getCameraSystem(), d)
    self.initMenu()
    
    self.depthCameraStreamController.setDepthCamera(d)
    self.depthCameraStreamController.start()

  @QtCore.Slot()
  def showCalibrationWizard(self):
    d = self.depthCameraStreamController.getDepthCamera()
    
    if not d:
      QtGui.QMessageBox.critical(self, 'Calibration Wizard', 'Depthcamera not connected. Please connect to do calibration')
      return
    
    self.depthCameraStreamController.disconnectDepthCamera(onlyFromUI = True)
    
    self.w = CalibrationWizard(self.window.cameraSystem, d, parent=self.window)
    
    if not self.w.isReady():
      return
    
    self.w.exec_()
    self.w.closePages()
    
    self.depthCameraStreamController.setDepthCamera(d)
    self.depthCameraStreamController.start()
    
    del self.w
  
  @QtCore.Slot()
  def setCameraProfile(self, name, id):
    
    d = self.depthCameraStreamController.getDepthCamera()
    
    if d:
      r = d.isRunning()
      
      if r:
        self.depthCameraStreamController.stop()
      
      if not d.setCameraProfile(id):
        QtGui.QMessageBox.critical(self, 'Camera Profile selection', 'Could not select camera profile "' + name + '"')
      
      self.depthCameraStreamController.onDepthCameraSet.emit()
      
      if r:
        self.depthCameraStreamController.start()
        
        
  @QtCore.Slot()
  def showFactoryCalibrationWizard(self):
    d = self.depthCameraStreamController.getDepthCamera()
    
    if not d:
      QtGui.QMessageBox.critical(self, 'Factory Calibration Wizard', 'Depthcamera not connected. Please connect to do calibration')
      return
    
    self.depthCameraStreamController.disconnectDepthCamera(onlyFromUI = True)
    
    self.w = FactoryCalibrationWizard(self.window.cameraSystem, d, parent=self.window)
    
    if not self.w.isReady():
      return
    
    self.w.exec_()
    self.w.closePages()
    
    self.depthCameraStreamController.setDepthCamera(d)
    self.depthCameraStreamController.start()
    
    del self.w
  
