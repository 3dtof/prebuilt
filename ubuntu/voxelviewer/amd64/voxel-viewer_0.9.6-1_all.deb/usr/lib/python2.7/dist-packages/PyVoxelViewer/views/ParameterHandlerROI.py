#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

import Voxel

from PySide import QtGui, QtCore

import numbers

from XYSpinBox import XYSpinBox

from functools import partial

from ParameterHandler import WheelEventFilter

class RegionOfInterestParameterView(QtGui.QWidget):
  
  valueChanged = QtCore.Signal()
  
  @staticmethod
  def getID():
    return "ROI"
  
  def getTitle(self):
    return "Region of Interest"
  
  def __init__(self, window, depthCameraController):
    super(RegionOfInterestParameterView, self).__init__()
    
    self.setMinimumHeight(200)
    self.setMinimumWidth(100)
    
    self.backgroundColor = QtGui.QColor('gray').lighter(180)
    
    self.view = QtGui.QGraphicsView()
    self.scene = QtGui.QGraphicsScene()
    #self.scene.setBackgroundBrush(QtGui.QBrush(self.backgroundColor))
    
    self.view.setScene(self.scene)
    
    self.fullWidth = 120
    self.fullHeight = 80
    
    self.xScale = 1
    self.yScale = 1
    
    self.fullRect = QtGui.QGraphicsRectItem(0, 0, self.fullWidth, self.fullHeight)
    self.fullRect.setBrush(QtGui.QBrush(QtGui.QColor('gray').lighter(100), bs = QtCore.Qt.SolidPattern))
    p = QtGui.QPen(QtGui.QColor('gray').darker(200))
    p.setWidth(2)
    self.fullRect.setPen(p)
    self.fullRect.setPos(0, 0)
    
    vline = QtGui.QGraphicsLineItem(self.fullWidth/2.0, 0.0, self.fullWidth/2.0, self.fullHeight*1.0, self.fullRect)
    vline.setPen(p)
    
    hline = QtGui.QGraphicsLineItem(0.0, self.fullHeight/2.0, self.fullWidth, self.fullHeight/2.0, self.fullRect)
    hline.setPen(p)
    
    self.maxWidth = self.scene.addText('320')
    self.maxWidth.setPos(self.fullWidth, -self.maxWidth.boundingRect().height())
    self.maxHeight = self.scene.addText('240')
    self.maxHeight.setPos(-self.maxWidth.boundingRect().width(), self.fullHeight)
    
    self.roiRect = QtGui.QGraphicsRectItem(0, 0, self.fullWidth, self.fullHeight)
    c = QtGui.QColor('white')
    c.setAlpha(200)
    self.roiRect.setBrush(QtGui.QBrush(c, bs = QtCore.Qt.SolidPattern))
    self.roiRect.setPen(QtGui.QPen(self.roiRect.brush(), 0))
    self.roiRect.setPos(0, 0)
    
    self.scene.addItem(self.fullRect)
    
    self.scene.addItem(self.roiRect)
    
    self.topLeft = XYSpinBox()
    self.topLeft.installEventFilter(WheelEventFilter(self))
    #self.topLeft.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
    self.topLeftItem = self.scene.addWidget(self.topLeft)
    self.topLeft.setStyleSheet("background-color: rgba(255, 255, 255, 150);");
    #self.topLeft.resize(60, self.topLeft.height())
    self.topLeftItem.setPos(-self.topLeft.width()/2, -self.topLeft.height() - 2)
    
    
    self.bottomRight = XYSpinBox()
    self.bottomRight.installEventFilter(WheelEventFilter(self))
    self.bottomRightItem = self.scene.addWidget(self.bottomRight)
    self.bottomRight.setStyleSheet("background-color: rgba(255, 255, 255, 150);");
    #self.bottomRight.resize(60, self.bottomRight.height())
    self.bottomRightItem.setPos(self.fullWidth - self.bottomRight.width()/2, self.fullHeight + 2)
    
    self.window = window
    self.depthCameraController = depthCameraController
    
    self.depthCameraController.started.connect(self.streamStarted)
    self.depthCameraController.stopped.connect(self.streamStopped)
    
    self.depthCameraController.onDepthCameraSet.connect(self.init)
    
    vlayout = QtGui.QVBoxLayout()
    
    vlayout.addWidget(self.view)
    
    self.message = QtGui.QWidget()
    
    hlayout = QtGui.QHBoxLayout()
    
    self.icon = QtGui.QLabel()
    
    self.textMessage = QtGui.QLabel()
    self.textMessage.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
    
    hlayout.addWidget(self.icon)
    hlayout.addWidget(self.textMessage)
    
    self.message.setLayout(hlayout)
    
    self.message.hide()
    
    vlayout.addWidget(self.message)
    
    self.setLayout(vlayout)
    
    self.init()
    self.streamStopped()
    
    self.topLeft.xSpinBox.editingFinished.connect(self.updateROI)
    self.topLeft.xSpinBox.oldStepBy = self.topLeft.xSpinBox.stepBy
    self.topLeft.xSpinBox.stepBy = partial(self.stepBy, self.topLeft.xSpinBox)
    self.topLeft.xSpinBox.setSingleStep(16)
    self.topLeft.ySpinBox.setSingleStep(16)

    self.topLeft.ySpinBox.editingFinished.connect(self.updateROI)
    self.topLeft.ySpinBox.oldStepBy = self.topLeft.ySpinBox.stepBy
    self.topLeft.ySpinBox.stepBy = partial(self.stepBy, self.topLeft.ySpinBox)
    
    self.bottomRight.xSpinBox.editingFinished.connect(self.updateROI)
    self.bottomRight.xSpinBox.oldStepBy = self.bottomRight.xSpinBox.stepBy
    self.bottomRight.xSpinBox.stepBy = partial(self.stepBy, self.bottomRight.xSpinBox)
    self.bottomRight.xSpinBox.setSingleStep(16)
    self.bottomRight.ySpinBox.setSingleStep(16)
    
    self.bottomRight.ySpinBox.editingFinished.connect(self.updateROI)
    self.bottomRight.ySpinBox.oldStepBy = self.bottomRight.ySpinBox.stepBy
    self.bottomRight.ySpinBox.stepBy = partial(self.stepBy, self.bottomRight.ySpinBox)
    
  def stepBy(self, spinbox, value):
    spinbox.oldStepBy(value)
    self.updateROI()
    
  @QtCore.Slot()
  def streamStarted(self):
    s = self.depthCameraController.getCurrentSource()
    if s:
      if not s.isLiveStream():
        self.icon.setPixmap(self.window.style().standardIcon(QtGui.QStyle.SP_MessageBoxInformation).pixmap(24, 24))
        self.textMessage.setText('Frame size settings are not applicable')
        self.message.show()  
      else:
        self.message.hide()
      
  @QtCore.Slot()
  def streamStopped(self):
    s = self.depthCameraController.getCurrentSource()
    if s:
      self.setEnabled(True)
      
      if s.isLiveStream():
        self.message.hide()
      else:
        self.icon.setPixmap(self.window.style().standardIcon(QtGui.QStyle.SP_MessageBoxInformation).pixmap(24, 24))
        self.textMessage.setText('Frame size settings are not applicable')
        self.message.show()
      
  @QtCore.Slot()
  def updateROI(self):
    x1, y1 = self.topLeft.getXY()
    x2, y2 = self.bottomRight.getXY()
    
    #print x1, x2, y1, y2
    
    if self.engine:
      
      s = self.depthCameraController.getCurrentSource()
      
      isRunning = False
      if s and s.isLiveStream() and s.isRunning():
        self.depthCameraController.stop()
        isRunning = True
      
      roi = Voxel.RegionOfInterest()
      roi.x = x1
      roi.y = y1
      roi.width = x2 - x1
      roi.height = y2 - y1
      #print "Trying to set ROI = ", roi.x, roi.y, roi.width, roi.height
      r = self.engine.setROI(roi)
      
      if not r:
        QtGui.QMessageBox.critical(self, 'Region of Interest', 'Failed to set region of interest')
        
        roi.x = self.lastROI[0]
        roi.y = self.lastROI[1]
        roi.width = self.lastROI[2]
        roi.height = self.lastROI[3]
        
        r = self.engine.setROI(roi)
        
        if not r:
          QtGui.QMessageBox.critical(self, 'Region of Interest', 'Failed to restore region of interest')
        
        if isRunning:
          self.depthCameraController.start()
          
        self.init()
        
        return
      
      self.valueChanged.emit()
      
      if isRunning:
        self.depthCameraController.start()
        
      self.init()
      
  @QtCore.Slot()
  def init(self):
    self.engine = self.depthCameraController.getDepthCamera()
    
    if self.engine:
      r, f = self.engine.getMaximumFrameSize()
      
      if not r:
        return
      
      self.maxWidth.setPlainText(str(f.width))
      self.maxHeight.setPlainText(str(f.height))
      
      self.xScale = self.fullWidth*1.0/f.width
      self.yScale = self.fullHeight*1.0/f.height
      
      r, roi = self.engine.getROI()
      
      #print "ROI = ", roi.x, roi.y, roi.width, roi.height
      
      if not r:
        return
      
      self.lastROI = (roi.x, roi.y, roi.width, roi.height)
      
      x1 = roi.x*self.xScale
      y1 = roi.y*self.yScale
      x2 = (roi.x + roi.width)*self.xScale
      y2 = (roi.y + roi.height)*self.yScale
      
      self.topLeft.setRange(0, roi.x + roi.width, 0, roi.y + roi.height)
      self.topLeft.setXY(roi.x, roi.y)
      #self.topLeftItem.setPos(x1 - self.topLeft.width()/2, y1 - self.topLeft.height())
      
      self.bottomRight.setRange(roi.x, f.width, roi.y, f.height)
      self.bottomRight.setXY(roi.x + roi.width, roi.y + roi.height)
      
      #self.bottomRightItem.setPos(x2 - self.bottomRight.width()/2, y2)
      
      self.roiRect.setRect(x1, y1, x2 - x1, y2 - y1)