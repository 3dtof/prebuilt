#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui
from CalibrationPage import CalibrationPage, c

from PyVoxelViewer.models.DepthCameraStreamController import DepthCameraStreamController
from PyVoxelViewer.models.DataEngine import DataEngine
from PyVoxelViewer.views.DataViewContainer import DataViewContainer

import os
import csv

import math

import numpy as np

class CalibrationCommonPhasePage(CalibrationPage):
  
  MAX_PHASE_VALUE = 4096
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationCommonPhasePage, self).__init__(calibrationWizard, index, parent = parent, 
          definingParams = definingParams, calibParams = calibParams)
          
    self.calibrationWizard = calibrationWizard
    #title = 'Common Phase Calibration for %s profile' %(self.calibrationWizard.currentProfileName)
    self.setTitle('Common Phase Calibration')
    self.setSubTitle('Common phase offset computation. Please measure the phase value at cx, cy')  
    
    self.layout = QtGui.QVBoxLayout(self)
    
    self.setMinimumHeight(200)
    self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
    hlayout = QtGui.QHBoxLayout()
    self.centerPointText = QtGui.QLabel()
    hlayout.addWidget(self.centerPointText)
    
    hlayout.addStretch()
    
    self.calibrateButton = QtGui.QPushButton('&Calibrate')
    self.calibrateButton.pressed.connect(self.calibrate)
    self.calibrateButton.setShortcut('Alt+C')
    hlayout.addWidget(self.calibrateButton)
    
    self.layout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Distance from flat surface: '))
    
    self.distance = QtGui.QDoubleSpinBox()
    self.distance.setRange(0.1, 50)
    self.distance.setSingleStep(0.001)
    self.distance.setValue(0.750)
    self.distance.setDecimals(3)
    hlayout.addWidget(self.distance)
    hlayout.addWidget(QtGui.QLabel('m'))
    hlayout.addStretch()
    self.layout.addLayout(hlayout)
    
    
    hlayout = QtGui.QHBoxLayout()
    self.numberOfFrames = 200
    hlayout.addWidget(QtGui.QLabel('Number of frames to capture: '))
    self.frameCount = QtGui.QSpinBox()
    self.frameCount.setRange(50, 500)
    self.frameCount.setValue(self.numberOfFrames)
    self.frameCount.valueChanged.connect(self.setNumberOfFrames)
    hlayout.addWidget(self.frameCount)
    hlayout.addStretch()
    
    self.layout.addLayout(hlayout)
    
    self.depthCameraController = DepthCameraStreamController(self.calibrationWizard.cameraSystem, None)
    self.dataEngine = DataEngine(self.depthCameraController)
    self.dataEngine.disableStatistics()
    
    self.captureRunning = False
    self.dataEngine.connectData("phase", self.computeAveragePhases, QtCore.Qt.QueuedConnection)
    
    self.dataView = DataViewContainer(self.dataEngine, 'phase', shouldLinkViewBox = False, showFormatMenu = True)
    
    self.layout.addWidget(self.dataView)
    
    self.progressBar = QtGui.QProgressBar()
    self.currentProgressValue = 0
    self.progressBar.setValue(0)
    
    self.layout.addWidget(self.progressBar)
    
    self.progressText = QtGui.QLabel()
    self.layout.addWidget(self.progressText)
    
    self.paramsGroupbox = QtGui.QGroupBox()
    self.paramsGroupbox.setTitle('Common Phase Parameters')
    self.layout.addWidget(self.paramsGroupbox)
    
    self.paramsText = QtGui.QLabel()
    
    vglayout = QtGui.QVBoxLayout()
    vglayout.addWidget(self.paramsText)
    self.paramsGroupbox.setLayout(vglayout)
    
    self.paramsGroupbox.hide()
    
    self.dataView.dataView.graphicsWidget.scene().sigMouseMoved.connect(self.getMousePosition)
    
    self.calibrated = False
    self.frameSize = None
    self.phaseData = None
    
  def setNumberOfFrames(self, value):
    self.numberOfFrames = value
    self.calibrationWizard.framesToCapture = value
    
  def isComplete(self):
    return self.calibrated
  
  def initializePage(self):
    
    if self.calibrationWizard.currentConfiguration.isPresent('calib', 'actual_distance'):
      self.distance.setValue(self.calibrationWizard.currentConfiguration.getFloat('calib', 'actual_distance'))
    
    if self.calibrationWizard.framesToCapture is not None:
        self.setNumberOfFrames(self.calibrationWizard.framesToCapture)
        self.frameCount.setValue(self.calibrationWizard.framesToCapture)
    super(CalibrationCommonPhasePage, self).initializePage()
    
    
    self.cx = round(self.calibrationWizard.currentConfiguration.getFloat('calib', 'cx'), 1)
    self.cy = round(self.calibrationWizard.currentConfiguration.getFloat('calib', 'cy'), 1)
    
    self.centerPointText.setText('From lens calibration, cx = %.1f, cy = %.1f'%(self.cx, self.cy))
    if self.calibrationWizard.currentConfiguration.isPresent('calib', 'actual_distance'):
        self.calibrateButton.click()


  def enterPage(self):
    super(CalibrationCommonPhasePage, self).enterPage()
    self.depthCameraController.setDepthCamera(self.calibrationWizard.depthCamera)
    self.depthCameraController.start()
    
  def leavePage(self):
    self.depthCameraController.stop()
    
  def setProgress(self, progressIncrement, progressMessage = None):
    self.currentProgressValue += progressIncrement
    self.progressBar.setValue(self.currentProgressValue)
    
    if progressMessage is not None:
      self.progressText.setText(progressMessage)
      
  def closePage(self):
    self.dataEngine.stop()
    
  def validatePage(self):
    r = super(CalibrationCommonPhasePage, self).validatePage()
    
    if r:
      print 'Stopping camera...'
      self.depthCameraController.disconnectDepthCamera(onlyFromUI = True)
      
    return r
    
  @QtCore.Slot(int, long, object)
  def computeAveragePhases(self, id, timestamp, frame):
    

    if not self.captureRunning:
      return
    
    self.phaseData = frame
    
    self.frameSize = [self.phaseData.shape[1], self.phaseData.shape[0]]
    
    if self.currentFrameCount == 0:
      r = r1 = False
      if self.dealiasEnabled:
        if self.phaseAverage1 is None:
          r = self.depthCamera.setb('ind_freq_data_en', True)
          r1 = self.depthCamera.setb('ind_freq_data_sel', False)
          self.setProgress(0, 'Computing phase offset for first modulation frequency...')
        else:
          r = self.depthCamera.setb('ind_freq_data_en', True)
          r1 = self.depthCamera.setb('ind_freq_data_sel', True)
          self.skipFrameTotalCount = 30
          self.setProgress(0, 'Computing phase offset for second modulation frequency...')
      else:
        r = r1 = True
        
      if not r or not r1:
        self.stopCalibration()
    
    if self.skipFrameCount < self.skipFrameTotalCount:
      self.skipFrameCount += 1
      self.currentFrameCount += 1
      return
      
    
    if self.phaseAverage is None:
      self.phaseAverage = np.zeros((self.averageWindow, self.averageWindow), dtype='complex')
      
    phase = self.dataEngine.data['phase']\
      [self.centerShape[0]:self.centerShape[1], self.centerShape[2]:self.centerShape[3]]*np.pi/2048
    self.phaseAverage += self.dataEngine.data['amplitude']\
      [self.centerShape[0]:self.centerShape[1], self.centerShape[2]:self.centerShape[3]]*(np.cos(phase)+1j*np.sin(phase))
    self.currentFrameCount += 1
    self.setProgress(self.progressPercentage/self.numberOfFrames, None)
    
    if self.currentFrameCount >= self.numberOfFrames + self.skipFrameTotalCount:
      self.phaseAverage /= self.numberOfFrames
      self.phaseAverage = np.sum(self.phaseAverage)/self.averageWindow/self.averageWindow
      self.phaseAverage = np.angle(self.phaseAverage)*(4096/(2*math.pi))
      
      if not self.dealiasEnabled:
        self.phaseAverage1 = self.phaseAverage
        self.phaseAverage = None
        self.currentFrameCount = 0
        self.finishCalibration()
      elif self.phaseAverage1 is not None:
        self.phaseAverage2 = self.phaseAverage
        self.phaseAverage = None
        self.finishCalibration()
      else:
        self.phaseAverage1 = self.phaseAverage
        self.phaseAverage = None
        self.currentFrameCount = 0
        
  def getMousePosition(self, pos):
    p = self.dataView.dataView.imageItem.mapFromScene(pos)
    
    if self.dataEngine.frameSize is not None and self.phaseData is not None:
      if p.x() < 0 or p.x() >= self.frameSize[0] or p.y() < 0 or p.y() >= self.frameSize[1]:
        return
      
      x = int(p.x())
      y = int(p.y())
      
      self.progressText.setText('Current point (%d, %d). Phase = %d'%(x, y, self.phaseData[y, x]))
      
  def calibrate(self):
    r, dealiasEnabled = self.depthCamera.getb('dealias_en')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not read "dealias_en" parameter')
      return
    
    self.dealiasEnabled = dealiasEnabled
    
    if self.dealiasEnabled:
      self.progressPercentage = 50.0
    else:
      self.progressPercentage = 100.0
      
    print self.progressPercentage, self.dealiasEnabled
    
    self.averageWindow = 4 # Use even numbers only
    self.centerShape = [int(self.cy - self.averageWindow/2), int(self.cy + self.averageWindow/2),
                        int(self.cx - self.averageWindow/2), int(self.cx + self.averageWindow/2)]
    
    self.phaseAverage = None
    self.phaseAverage1 = self.phaseAverage2 = None
    self.currentFrameCount = 0
    self.skipFrameTotalCount = 0
    self.skipFrameCount = 0
    self.captureRunning = True
    self.currentProgressValue = 0
    self.calibrateButton.setDisabled(True)
    
  def stopCalibration(self):
    self.phaseAverage = None
    self.captureRunning = False
    self.currentProgressValue = 0
    self.progressBar.setValue(0)
    self.calibrateButton.setEnabled(True)
    
    if self.depthCamera.chipset() != CalibrationPage.CHIPSET_CALCULUS:
      r = self.depthCamera.setb('ind_freq_data_en', False)
    
  def finishCalibration(self):
    self.stopCalibration()
    if self.writePhaseOffsets(self.phaseAverage1, self.phaseAverage2, self.distance.value(), self.dealiasEnabled):
      self.paramsGroupbox.show()
      self.paramsText.setText(' For profile %s: tillum_calib = %d, tsensor_calib = %d, \nphase_corr_1 = %d, phase_corr_2 = %d,\n'%\
        (self.calibrationWizard.currentProfileName, self.calibParams['tillum_calib'], self.calibParams['tsensor_calib'], self.calibParams['phase_corr_1'], self.calibParams['phase_corr_2']))
      finalText = 'For Profile %s, phase_corr_1 = %d and phase_corr_2 = %d\n'\
      %(self.calibrationWizard.currentProfileName, self.calibParams['phase_corr_1'], self.calibParams['phase_corr_2'])
      self.calibrationWizard.phaseCorrs += finalText
      self.calibrated = True
      
      self.completeChanged.emit()
      
    
  def computePhaseOffsets(self, phaseAverage1, phaseAverage2, distance, dealiasEnabled):
    if phaseAverage1 is None or (dealiasEnabled and phaseAverage2 is None):
      QtGui.QMessageBox.critical(self, 'Data Missing', 'Cannot perform calibration with missing data')
      return False
    
    if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
      r, tSensorCalib = self.depthCamera.getu('tsensor')
    else:
      r, tSensorCalib = self.depthCamera.geti('tsensor')

    r1, tIllumCalib = self.depthCamera.geti('tillum')
    
    if not r:
      tSensorCalib = 0
      QtGui.QMessageBox.critical(self, 'Sensor temperature', 'Could not get sensor temperature')
      return False
      
    if not r1:
      tIllumCalib = 0
      
    r, mf1 = self.depthCamera.getf("mod_freq1")
    
    ds1 = c/(2*mf1*1E6)
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Modulation Frequency', 'Failed to get modulation frequency 1')
      return False
    
    phaseActual1 = distance/ds1*4096
    
    #print '\nphaseActual1 = ', phaseActual1
    
    if dealiasEnabled:
      if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
        r1, scaling = self.depthCamera.geti("alt_frm_sel")
        mf2 = mf1/(2**(scaling + 1))
      else:
        r1, mf2 = self.depthCamera.getf("mod_freq2")
      ds2 = c/(2*mf2*1E6)
      
      if not r1:
        QtGui.QMessageBox.critical(self, 'Modulation Frequency', 'Failed to get modulation frequency 2')
        return False
    
      phaseActual2 = distance/ds2*4096
      
      #print '\nphaseActual2 = ', phaseActual2
    else:
      phaseActual2 = phaseActual1
    
    if phaseAverage2 is None:
      phaseAverage2 = phaseActual2 # Canceling out and setting to zero
      
    self.calibParams['tillum_calib'] = int(tIllumCalib)
    if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
      self.calibParams['tsensor_calib'] = tSensorCalib
    else:
      self.calibParams['tsensor_calib'] = int(tSensorCalib)
    
    if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
      self.calibParams['coeff_sensor'] = int(-40)

    r, additivePhase = self.depthCamera.getb('phase_corr_add')
    
    #print(r, additivePhase)
    #print(phaseActual1, phaseAverage1)
    if additivePhase:
      phaseCorr1 = int(self.wrapPhaseToSignedInteger(phaseActual1 - phaseAverage1))
      phaseCorr2 = int(self.wrapPhaseToSignedInteger(phaseActual2 - phaseAverage2))
    else:  
      phaseCorr1 = int(self.wrapPhaseToSignedInteger(phaseAverage1 - phaseActual1))
      phaseCorr2 = int(self.wrapPhaseToSignedInteger(phaseAverage2 - phaseActual2))
    return True, phaseCorr1, phaseCorr2 

  def writePhaseOffsets(self, phaseAverage1, phaseAverage2, distance, dealiasEnabled):
    r = self.computePhaseOffsets(phaseAverage1, phaseAverage2, distance, dealiasEnabled)
    if r == False:
      return False
    r, phaseCorr1, phaseCorr2 = r

    self.calibParams['phase_corr_1'] = phaseCorr1
    self.calibParams['phase_corr_2'] = phaseCorr2
    self.calibParams['actual_distance'] = distance
    
    return True
  
  def wrapPhaseToSignedInteger(self, phase):
    if phase >= CalibrationCommonPhasePage.MAX_PHASE_VALUE/2:
      return -1*(CalibrationCommonPhasePage.MAX_PHASE_VALUE - phase)
    elif phase < -CalibrationCommonPhasePage.MAX_PHASE_VALUE/2:
      return (CalibrationCommonPhasePage.MAX_PHASE_VALUE + phase)
    else:
      return phase
  
  