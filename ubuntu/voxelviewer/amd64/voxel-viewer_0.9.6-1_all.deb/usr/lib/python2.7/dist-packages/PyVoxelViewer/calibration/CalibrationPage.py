#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from PyVoxelViewer.views.ParameterHandler import ParameterHandler
from PyVoxelViewer.models.Config import Config

import os

import shutil

import Voxel

#from scipy.constants import c
c = 299792458 # m/s

CALIB_LENS = 'lens'
CALIB_FREQUENCY = 'frequency'
CALIB_CROSS_TALK = 'cross_talk'
CALIB_NON_LINEARITY = 'non_linearity'
CALIB_TEMPERATURE = 'temperature'
CALIB_COMMON_PHASE_OFFSET = 'common_phase_offset'
CALIB_PIXELWISE_PHASE_OFFSET = 'pixelwise_phase_offset'


class Calibration(object):
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}):
    self.calibIndex = index
    self.definingParams = definingParams
    self.calibParams = calibParams
    self.calibrationWizard = calibrationWizard
    
  def needsCalibration(self):
    calib = False
    for p in self.definingParams:
      
      if p == 'frame_rate':
        r, f = self.calibrationWizard.depthCamera.getFrameRate()
        
        if not r:
          return True
        
        f1 = self.calibrationWizard.previousConfiguration.getFloat('defining_params', p)
        
        if int(f.getFrameRate()*100) != int(f1*100):
          return True
        
        continue
      
      param = ParameterHandler.getParameterHandler(self.calibrationWizard.depthCamera, p)
      
      if not param:
        continue
      
      r, v1 = param.get()
      
      if not r:
        return True
        
      if param.type == 'Int' or param.type == 'Uint':
        v2 = self.calibrationWizard.previousConfiguration.getInteger('defining_params', p)
        if v1 != v2:
          return True
      
      elif param.type == 'Float':
        v2 = self.calibrationWizard.previousConfiguration.getFloat('defining_params', p)
        if int(v1*100) != int(v2*100):
          return True
        
      elif param.type == 'Bool':
        v2 = self.calibrationWizard.previousConfiguration.getBoolean('defining_params', p)
        
        if v1 != v2:
          return True
      
      
    return not self.isPresentInPrevious()
    
  def isPresentInPrevious(self):
    for c in self.calibParams.keys():
      if not self.calibrationWizard.previousConfiguration.isPresent('calib', c):
        return False
    return True
    
    
class CalibrationPage(QtGui.QWizardPage):
  
  FILE_PREFIX = 'file:'
  CHIPSET_TINTIN = 'tintin.ti'
  CHIPSET_HADDOCK = 'haddock.ti'
  CHIPSET_CALCULUS = 'calculus.ti'
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationPage, self).__init__(parent)
    
    self.calibrationWizard = calibrationWizard
    self.calibIndex = index
    self.depthCamera = self.calibrationWizard.depthCamera
    
    self.chipset = self.depthCamera.chipset()
    
    self.definingParams = definingParams
    
    self.calibParams = calibParams
    
    self.calibrationObject = Calibration(calibrationWizard, index, definingParams, calibParams)
    
    self.doShow = self.needsCalibration()
    
  def writeDefiningParams(self, configuration = None):
    if configuration is None:
      configuration = self.calibrationWizard.currentConfiguration
    
    for p in self.definingParams:
      if p == 'frame_rate':
        r, f = self.depthCamera.getFrameRate()
        
        if not r:
          return True
        
        configuration.set('defining_params', p, str(f.getFrameRate()))
        continue
        
      param = ParameterHandler.getParameterHandler(self.depthCamera, p)
      
      if not param:
        continue
      
      r, v1 = param.get()
      
      if not r:
        return False
      
      configuration.set('defining_params', p, str(v1))
      
  def writeCalibrationParams(self, configuration = None):
    if configuration is None:
      configuration = self.calibrationWizard.currentConfiguration
      
    if configuration is None:
      return False
    for c, v in self.calibParams.iteritems():
      configuration.set('calib', c, str(v))
      
    return True
  
  def needsCalibration(self):
    return self.calibrationObject.needsCalibration()
  
  def isPresentInPrevious(self):
    return self.calibrationObject.isPresentInPrevious()
  
  def disableThisAndNextCalibrations(self):
    disableIndices = 0
    
    for p in self.calibrationWizard.pages:
      if p.calibIndex >= self.calibIndex:
        disableIndices += (1 << p.calibIndex)
      
    #print "indices to disable = %x"%disableIndices
    self.calibrationWizard.currentConfiguration.setInteger("calib", Voxel.CALIB_DISABLE, disableIndices)
    
  # Copy from previous configuration, and don't configure newly
  def copyCalibrationFromPrevious(self):
    if not self.calibrationWizard.currentConfiguration:
      return 
    
    for c in self.calibParams.keys():
      self.calibrationWizard.currentConfiguration.set('calib', c, \
        self.calibrationWizard.previousConfiguration.get('calib', c))
      self.calibParams[c] = self.calibrationWizard.previousConfiguration.get('calib', c)
  
  # Remove this calibration from current configuration
  def removeCalibration(self):
    if not self.calibrationWizard.currentConfiguration:
      return 
    
    for c in self.calibParams.keys():
      self.calibrationWizard.currentConfiguration.remove('calib', c)
      
  def initializePage(self):
    c = Voxel.Configuration()
    r, self.basePath = c.getLocalPath('profiles')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Path failed', 'Failed to get base path')
      return
    
    self.basePath += os.sep + self.depthCamera.name() + os.sep + self.calibrationWizard.currentProfileName
    
    if not os.path.exists(self.basePath):
      os.makedirs(self.basePath)
      
    self.leavePage()
      
  def cleanupPage(self):
    self.leavePage()
    
  def enterPage(self):
    self.disableThisAndNextCalibrations()
    pass
  
  def leavePage(self):
    pass
  
  def closePage(self):
    pass
    
  def validatePage(self):
    if self.isComplete():
      self.writeCalibrationParams()
        
      self.leavePage()
      return True
    else:
      return False
    
  def getModulationFrequencies(self):
    r, dealiasEnabled = self.depthCamera.getb('dealias_en')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not read "dealias_en" parameter')
      return False
    
    r, mf1 = self.depthCamera.getf("mod_freq1")
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Modulation Frequency', 'Failed to get modulation frequency 1')
      return False
    
    if dealiasEnabled:
      if self.depthCamera.chipset() == CalibrationPage.CHIPSET_CALCULUS:
        r1, scaling = self.depthCamera.geti("alt_frm_sel")
        mf2 = mf1/(2**(scaling + 1))
      else:
        r1, mf2 = self.depthCamera.getf("mod_freq2")
      ds2 = c/(2*mf2*1E6)
      
      if not r1:
        QtGui.QMessageBox.critical(self, 'Modulation Frequency', 'Failed to get modulation frequency 2')
        return False
    
      return (mf1, mf2)
    else:
      return (mf1, None)
    