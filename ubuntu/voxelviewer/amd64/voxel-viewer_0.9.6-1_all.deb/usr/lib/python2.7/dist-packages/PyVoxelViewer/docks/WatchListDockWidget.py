#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.views.WatchListPointComponent import PointWatchListView
from PyVoxelViewer.views.WatchListSpatialComponent import SpatialWatchListView
from PyVoxelViewer.views.WatchListObservedParametersComponent import ObservedParametersWatchListView
import string
import os



class WatchListDockWidget(QtGui.QDockWidget):
  
  def __init__(self, dataEngine):
    QtGui.QDockWidget.__init__(self, "Watch List")
    self.setMinimumWidth(300)
    
    self.dataEngine = dataEngine
    
    widget = QtGui.QSplitter()
    
    self.pointWatchList = PointWatchListView(dataEngine)
    self.spatialWatchList = SpatialWatchListView(dataEngine)
    
    self.observedParametersWatchList = ObservedParametersWatchListView(self.dataEngine.getDepthCameraController())
    
    widget.addWidget(self.pointWatchList)
    widget.addWidget(self.spatialWatchList)
    widget.addWidget(self.observedParametersWatchList)
    
    self.setWidget(widget)