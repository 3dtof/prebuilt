#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from PyVoxelViewer.models.DepthCameraStreamController import DepthCameraStreamController

import os
import csv

import math

import numpy as np

import Voxel


class CalibrationWriteToHardwarePage(QtGui.QWizardPage):
  
  def __init__(self, calibrationWizard, parent = None):
    super(CalibrationWriteToHardwarePage, self).__init__(parent)
    self.calibrationWizard = calibrationWizard
    
    self.complete = False
    
    #TODO Define the steps to write self.calibrationWizard.currentConfigurations (list of current configurations to write to hardware)
    self.setTitle('Congratulations!')
    self.setSubTitle('Calibration Successfully Completed')
    
    self.vlayout = QtGui.QVBoxLayout(self)
    self.label = QtGui.QLabel('')
    self.label.setWordWrap(True)
    self.vlayout.addWidget(self.label)
    hlayout1 = QtGui.QHBoxLayout()
    self.sensorLabel = QtGui.QLabel('coeff_sensor')
    self.illumLabel =  QtGui.QLabel('coeff_illum')
    self.illumText = QtGui.QLineEdit()
    self.illumText.setText('0')
    self.illumvalue = 0
    self.illumText.textChanged.connect(self.changeIllumCoeff)
    self.sensorText = QtGui.QLineEdit()
    self.sensorText.setText('-26')
    self.sensorValue = -26
    self.sensorText.textChanged.connect(self.changeSensorCoeff)
    hlayout1.addWidget(self.illumLabel)
    hlayout1.addStretch()
    hlayout1.addWidget(self.illumText)
    hlayout2 = QtGui.QHBoxLayout()
    hlayout2.addWidget(self.sensorLabel)
    hlayout2.addStretch()
    hlayout2.addWidget(self.sensorText)
    self.vlayout.addLayout(hlayout1)
    self.vlayout.addLayout(hlayout2)
    hlayout = QtGui.QHBoxLayout()
    hlayout.addStretch()
    self.button = QtGui.QPushButton('Write to Hardware')
    self.button.pressed.connect(self.writeToHardware)
    self.deleteButton = QtGui.QPushButton('Delete Conf Files')
    self.deleteButton.pressed.connect(self.deleteConfFiles)
    hlayout.addWidget(self.button)
    hlayout.addStretch()
    self.vlayout.addLayout(hlayout)
    hlayout = QtGui.QHBoxLayout()
    hlayout.addStretch()
    hlayout.addWidget(self.deleteButton)
    hlayout.addStretch()
    self.vlayout.addLayout(hlayout)
    self.deleteButton.setDisabled(True)
    self.phaseLabel = QtGui.QLabel('')
    self.phaseLabel.setWordWrap(True)
    self.vlayout.addWidget(self.phaseLabel)
    
  def enterPage(self):
    self.phaseLabel.setText(self.calibrationWizard.phaseCorrs)
    c = Voxel.Configuration()
    r, self.profilePath = c.getLocalPath('profiles')
    self.profilePath += os.sep + self.calibrationWizard.depthCamera.name() + os.sep + self.calibrationWizard.depthCamera.id().split(':')[-1].split(')')[0] + os.sep
    self.filename = self.profilePath + 'phaseCorrs.txt'
    file = open(self.filename , 'w')
    file.write(self.calibrationWizard.phaseCorrs)

    for name, c in self.calibrationWizard.currentConfigurations.iteritems():
        if (name == self.calibrationWizard.PROFILE_LENS_ONLY or  name ==self.calibrationWizard.PROFILE_LONG_RANGE\
          or name == self.calibrationWizard.PROFILE_SHORT_RANGE or self.calibrationWizard.PROFILE_HIGH_AMBIENT):
            self.label.setText('Writing profile "' + name + '"...')
            c.remove("calib", Voxel.CALIB_DISABLE)
            c.write()
    
    self.label.setText('Local profiles have been updated. Please click on the button below to write to camera.')
    
  @QtCore.Slot()
  def writeToHardware(self):
    self.label.setText('Erasing profiles on camera. Please wait...')
    
    if not self.calibrationWizard.depthCamera.configFile.removeAllHardwareCameraProfiles():
      self.label.setText('Failed to erase profiles on camera. Click on the button again to re-try')
      return
    
    self.label.setText('Writing profiles to camera. Please wait...')
    c = self.calibrationWizard.currentConfigurations[self.calibrationWizard.PROFILE_LENS_ONLY]
    c.set('calib', 'coeff_sensor', str(self.sensorValue))
    c.set('calib', 'coeff_illum', str(self.illumvalue))
    c.write()
    r, lensid = self.calibrationWizard.depthCamera.configFile.saveCameraProfileToHardware(self.calibrationWizard.currentConfigurationIDs[self.calibrationWizard.PROFILE_LENS_ONLY], True, True, 'Calibrated ' )
    if not r:
      QtGui.QMessageBox.critical(self, 'Save Profile to Hardware', 'Failed to save camera profile to hardware')
      self.label.setText('Sorry! Failed to save camera profile to hardware. Please re-run wizard or use the "Profiles Manager" to retry writing camera profiles to hardware.')
    else:
        c = self.calibrationWizard.depthCamera.configFile.getCameraProfile(self.calibrationWizard.currentConfigurationIDs[self.calibrationWizard.PROFILE_LONG_RANGE])
        c.set('global', 'parent', str(lensid))
        c.set('calib', 'coeff_sensor', str(self.sensorValue))
        c.set('calib', 'coeff_illum', str(self.illumvalue))
        c.write()
        r, longRangeId = self.calibrationWizard.depthCamera.configFile.saveCameraProfileToHardware(self.calibrationWizard.currentConfigurationIDs[self.calibrationWizard.PROFILE_LONG_RANGE], False, True, 'Calibrated ')
        if not r:
          QtGui.QApplication.critical(self, 'Save Profile to Hardware', 'Failed to save long range camera profile to hardware')
          self.label.setText('Sorry! Failed to save camera profile to hardware. Please re-run wizard or use the "Profile Manager" to retry writing camrea profiles to  hardware.')
        else:
          for name in self.calibrationWizard.currentConfigurationIDs:
            if (name != self.calibrationWizard.PROFILE_LENS_ONLY) and (name != self.calibrationWizard.PROFILE_LONG_RANGE) :
                c = self.calibrationWizard.depthCamera.configFile.getCameraProfile(self.calibrationWizard.currentConfigurationIDs[name])
                c.set('global', 'parent', str(longRangeId))
                c.set('calib', 'coeff_sensor', str(self.sensorValue))
                c.set('calib', 'coeff_illum', str(self.illumvalue))
                c.write()
                r, id = self.calibrationWizard.depthCamera.configFile.saveCameraProfileToHardware(self.calibrationWizard.currentConfigurationIDs[name], False, False, 'Calibrated ' )
                if not r:
                  QtGui.QMessageBox.critical(self, 'Save Profile to Hardware', 'Failed to save camera profile to hardware')
                  self.label.setText('Sorry! Failed to save camera profile to hardware. Please re-run wizard or use the "Profiles Manager" to retry writing camera profiles to hardware.')
                else:
                    self.label.setText('Congratulations! Camera profiles have been created and written to hardware. ' + \
                                       'Please click finish now and verify that calibration is alright in the viewer. If it is not fine, please re-run this wizard.')
                    self.button.setDisabled(True)
                    self.deleteButton.setEnabled(True)
                    
                    
  @QtCore.Slot()
  def deleteConfFiles(self):
      c = Voxel.Configuration()
      r, self.confPath = c.getLocalPath('conf')
      if not r:
          self.label.setText('Cannot find the path to conf files. \nPlease check if the conf files are saved.')
      else:
          for file in os.listdir(self.confPath):
              fullFileName = os.path.join(self.confPath, file)
              if (os.path.isfile(fullFileName)):
                    os.remove(fullFileName)
          self.deleteButton.setDisabled(True)
          self.label.setText('Successfully deleted the conf files')  
          
  def changeIllumCoeff(self, value):
        self.illumvalue = value 
             
  @QtCore.Slot()
  def changeSensorCoeff(self, value):
        self.sensorValue = value              
      
                        
