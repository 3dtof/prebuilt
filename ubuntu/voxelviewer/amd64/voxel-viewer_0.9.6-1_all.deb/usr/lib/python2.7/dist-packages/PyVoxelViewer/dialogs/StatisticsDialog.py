#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore
from PyVoxelViewer.models.Config import Config

class StatisticsDialog(QtGui.QDialog):
  
  def __init__(self, statusBar, dataEngine, parent = None):
    super(StatisticsDialog, self).__init__(parent)
    
    self.setWindowTitle('Parameters')
    self.statusBar = statusBar
    self.dataEngine = dataEngine
    
    layout = QtGui.QVBoxLayout(self)
    
    groupbox = QtGui.QGroupBox()
    layout.addWidget(groupbox)
    groupbox.setCheckable(True)
    groupbox.setTitle('Temporal Statistics')
    
    groupbox.toggled.connect(self.statisticsChanged)
    
    ivlayout = QtGui.QVBoxLayout()
    ilayout = QtGui.QHBoxLayout()
    
    ilayout.addWidget(QtGui.QLabel('Settling Time:'))
    
    spinbox = QtGui.QSpinBox()
    spinbox.setRange(1, 200)
    spinbox.setValue(self.dataEngine.settlingTime)
    spinbox.valueChanged.connect(self.dataEngine.setSettlingTime)
    self.dataEngine.rateFactorChanged.connect(self.setRateFactor, QtCore.Qt.QueuedConnection)
    
    ilayout.addWidget(spinbox)
    
    ivlayout.addLayout(ilayout)
    
    self.rateFactor = QtGui.QLabel()
    ivlayout.addWidget(self.rateFactor)
    
    groupbox.setLayout(ivlayout)
    
    self.setRateFactor(self.dataEngine.rateFactor)
    
    groupBox = QtGui.QGroupBox('Recording Params')
    layout.addWidget(groupBox)
    hlayout = QtGui.QHBoxLayout()
    label = QtGui.QLabel('Frames To Record')
    spinBox = QtGui.QSpinBox()
    spinBox.setRange(10, 5000)
    self.c = Config.getConfig(Config.VIEWER_MAIN_CONFIG)
    if self.c.hasOption('recording_params', 'frames_to_record'):
        frames = self.c.getInt('recording_params', 'frames_to_record')
    else:
        frames = 1000
        self.setFramesToSave(frames)
    spinBox.setValue(frames)
    
    hlayout.addWidget(label)
    hlayout.addStretch()
    hlayout.addWidget(spinBox)
    groupBox.setLayout(hlayout)
    spinBox.valueChanged.connect (self.setFramesToSave)
    
        
  def setFramesToSave(self, value):
    self.c.set('recording_params', 'frames_to_record', value)
    
  def setRateFactor(self, rateFactor):
    self.rateFactor.setText('Rate Factor = ' + str(rateFactor))
    
  def statisticsChanged(self, state):
    self.statusBar.enableStatistics.setChecked(state)

  # static method to create the dialog and return (date, time, accepted)
  @staticmethod
  def showDialog(statusBar, dataEngine, parent = None):
    dialog = StatisticsDialog(statusBar, dataEngine, parent)
    dialog.exec_()