#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

import Voxel

class RemoveCameraProfileDialog(QtGui.QDialog):
  def __init__(self, depthCamera, parent = None):
    super(RemoveCameraProfileDialog, self).__init__(parent)

    self.depthCamera = depthCamera

    layout = QtGui.QVBoxLayout(self)

    # nice widget for editing the date
    self.listview = QtGui.QListWidget()
    layout.addWidget(self.listview)

    # OK and Cancel buttons
    buttons = QtGui.QDialogButtonBox(self)
    
    self.removeButton = QtGui.QPushButton("&Remove", self)
    self.closeButton = QtGui.QPushButton("&Close", self)
    
    self.removeButton.clicked.connect(self.removeCameraProfile)
    self.closeButton.clicked.connect(self.reject)
    
    buttons.addButton(self.removeButton, QtGui.QDialogButtonBox.ActionRole)
    buttons.addButton(self.closeButton, QtGui.QDialogButtonBox.RejectRole)
    
    self.listview.setSelectionMode(QtGui.QListWidget.SingleSelection)
        
    layout.addWidget(buttons)
    
    self.populateList()

  @QtCore.Slot()
  def populateList(self):
    names = self.depthCamera.getCameraProfileNames()
    
    self.ns = []
    
    self.ids = []
    
    for id, n in names.items():
      profile = self.depthCamera.configFile.getCameraProfile(id)
      
      if profile:
        if profile.getLocation() == Voxel.ConfigurationFile.IN_CAMERA:
          n += " (HW)";
          
        self.ns.append(n)
        
        self.ids.append(id)
    
    self.listview.clear()
    
    if len(self.ns) > 0:
      self.listview.addItems(self.ns)
      self.listview.setCurrentRow(0)
      self.removeButton.setEnabled(True)
    else:
      self.removeButton.setDisabled(True)
      
  def removeCameraProfile(self):
    index = self.listview.currentIndex().row()
    
    if index < len(self.ids):
      q = QtGui.QMessageBox.question(self, 'Remove Camera Profile', 'Remove camera profile "' + self.ns[index] + '"?',\
        buttons = QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
      
      if q == QtGui.QMessageBox.Yes:
        id = self.ids[index]
        
        if not self.depthCamera.removeCameraProfile(id):
          QtGui.QMessageBox.critical(self, 'Remove Camera Profile', 'Failed to remove camera profile with id = ' + str(id))
          return
        
        del self.ids[index]
        del self.ns[index]
        self.listview.model().removeRow(index)

  # static method to create the dialog and return (date, time, accepted)
  @staticmethod
  def showDialog(depthCamera, parent = None):
    dialog = RemoveCameraProfileDialog(depthCamera, parent)
    dialog.exec_()