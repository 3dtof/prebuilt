#
# TI Voxel Viewer component.
#
# Copyright (c) 2015 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from functools import partial

import Voxel

from PyVoxelViewer.dialogs.StatisticsDialog import StatisticsDialog
from PyVoxelViewer.calibration.CalibrationWizard import CalibrationWizard
from PyVoxelViewer.dialogs.RemoveCameraProfileDialog import RemoveCameraProfileDialog

class SettingsMenu(QtGui.QMenu):
  
  def __init__(self, window, dataEngine, parent = None):
    super(SettingsMenu, self).__init__(parent)
    
    self.dataEngine = dataEngine
      
    self.window = window
    self.statusBar = window.statusMessage
    self.initMenu()
    
    self.setTitle('&Settings')

  def initMenu(self):
    self.clear()    
    parametersAction = QtGui.QAction(QtGui.QIcon.fromTheme('parameters'), '&Parameters', self)
    parametersAction.triggered.connect(self.showParametersDialog)
    parametersAction.setShortcut('Ctrl+S')
    self.addAction(parametersAction)
    
  def showParametersDialog(self):
    StatisticsDialog.showDialog(self.statusBar, self.dataEngine, self.window)