#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.views.DataView import DataView

from PyVoxelViewer.views.ParameterHandler import *

from XYSpinBox import XYSpinBox

import string
import os
import sys

import numpy as np

class ParamUpdateHandler(QtCore.QObject):
  
  STATE_VALID = 0
  STATE_INVALID = 1
  
  def __init__(self, depthCamera, model, index, paramName, paramSpec, parent = None):
    super(ParamUpdateHandler, self).__init__(parent)
    
    self.paramName = paramName
    self.paramSpec = paramSpec
    self.depthCamera = depthCamera
    self.paramModel = model
    self.index = index
    
    self.timer = None
    
    self.state = ParamUpdateHandler.STATE_VALID
    
    if not self.parseParamSpec():
      return
    
    self.timer = QtCore.QTimer(parent)
    self.timer.timeout.connect(self.update)
    self.timer.start(self.refreshTime)
    
    self.update() # First time update
    
  def clear(self):
    if self.timer and self.timer.isActive():
      self.timer.stop()
    
  @QtCore.Slot()
  def update(self):
    v = ParameterHandler.getParameterHandler(self.depthCamera, self.paramName)
    
    if not v:
      return
    
    r, value = v.get(refresh = True)
    
    if not r:
      return
    
    if isinstance(v, RangeParameterHandler):
      if len(self.valid) == 2 and (value < self.valid[0] or value > self.valid[1]):
        self.state = ParamUpdateHandler.STATE_INVALID
      else:
        self.state = ParamUpdateHandler.STATE_VALID
    else:
      p = False
      for val in self.valid:
        if value == val:
          p = True
      
      if p:
        self.state = ParamUpdateHandler.STATE_VALID
      else:
        self.state = ParamUpdateHandler.STATE_INVALID
    
    i = self.paramModel.index(self.index, 1)
    self.paramModel.dataChanged.emit(i, i)
    
  def parseParamSpec(self):
    v = ParameterHandler.getParameterHandler(self.depthCamera, self.paramName)
    
    if not v:
      sys.stderr.write('WatchListObservedParametersComponent.ParamUpdateHandler: Invalid parameter ' + self.paramName)
      return False
    
    ps = self.paramSpec.split(';')
    
    self.refreshTime = 1000
    self.valid = []
    
    for p in ps:
      p = p.strip()
      
      if len(p) == 0:
        continue
      
      x = p.split(':')
      
      if len(x) != 2:
        sys.stderr.write('WatchListObservedParametersComponent.ParamUpdateHandler: Invalid syntax at ' + p + '\n')
        return False
      
      if x[0] == 'refresh':
        self.refreshTime = 1000*int(x[1])
        if self.refreshTime <= 0:
          sys.stderr.write('WatchListObservedParametersComponent.ParamUpdateHandler: Invalid refresh time = %ds. Setting it to 1s.\n'%self.refreshTime/1000)
          self.refreshTime = 1000
      elif x[0] == 'valid':
        if isinstance(v, RangeParameterHandler):
          r = x[1].split('-')
          if len(r) != 2:
            sys.stderr.write('WatchListObservedParametersComponent.ParamUpdateHandler: Invalid syntax at ' + x[1] + '\n')
            return False
          
          if isinstance(v, FloatParameterHandler):
            self.valid = [float(r[0]), float(r[1])]
          else:
            self.valid = [int(r[0]), int(r[1])]
            
          if self.valid[0] > self.valid[1]:
            sys.stderr.write('WatchListObservedParametersComponent.ParamUpdateHandler: Invalid value at ' + x[1] + '\n')
            return False
        else:
          r = x[1].split(',')
          self.valid = []
          for i in r:
            self.valid.append(int(i))
            
    return True
    

class ParameterModel(QtCore.QAbstractTableModel):
  def __init__(self, depthCamera, params, parent = None):
    super(ParameterModel, self).__init__(parent)
    
    self.params = params
    self.paramNames = params.keys()
    self.depthCamera = depthCamera
    
    self.paramHandlers = []
    
    i = 0
    for p, v in self.params.items():
      self.paramHandlers.append(ParamUpdateHandler(self.depthCamera, self, i, p, v, self))
      i += 1
      
  def clear(self):
    for p in self.paramHandlers:
      p.clear()
    
  def flags(self, index):
    f = super(ParameterModel, self).flags(index)
    
    return f | QtCore.Qt.ItemIsSelectable
    
  def rowCount(self, parent = QtCore.QModelIndex()):
    return len(self.params)
  
  def columnCount(self, parent = QtCore.QModelIndex()):
    return 2
  
  def data(self, index, role = QtCore.Qt.DisplayRole):
    
    if role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      param = self.paramNames[index.row()]
      
      if param:
        v = ParameterHandler.getParameterHandler(self.depthCamera, param)
        
        if not v:
          return None
        
        if index.column() == 0:
          return v.getName()
        else: # index.column() == 1
          return v.getDisplayValue()
      else:
        return None
  
  def headerData(self, section, orientation, role = QtCore.Qt.DisplayRole):
    if role == QtCore.Qt.DisplayRole:
      if orientation == QtCore.Qt.Horizontal:
        if section == 0:
          return "Name"
        else:
          return "Value"
      else:
        return None
    elif role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      return None
  
  
class ParameterDelegate(QtGui.QAbstractItemDelegate):
  def __init__(self, tableView, depthCamera, params, parent = None):
    super(ParameterDelegate, self).__init__(parent)
    
    self.tableView = tableView
    self.paramModel = self.tableView.paramModel
    
    self.depthCamera = depthCamera
    self.params = params
    
  def paint(self, painter, option, index):
    if index.row() > len(self.paramModel.paramHandlers):
      return
    
    ph = self.paramModel.paramHandlers[index.row()]
    
    if index.column() == 0 or ph.state == ParamUpdateHandler.STATE_VALID:
      if option.state & QtGui.QStyle.State_Selected:
        if option.state & QtGui.QStyle.State_Active:
          painter.setBrush(QtGui.QBrush(self.tableView.palette().highlight()))
        else:
          painter.setBrush(QtGui.QBrush(self.tableView.palette().color(QtGui.QPalette.Inactive, QtGui.QPalette.Highlight)))
        painter.drawRect(option.rect)
    else:
      # painter.setBrush(QtGui.QBrush(QtGui.QColor('#DD8888')))
      # painter.drawRect(option.rect)
      pass
    painter.drawText(option.rect, QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter, index.data())
  
  def sizeHint(self, option, index):
    return option.rect.size() # Occupy full size
  

class ObservedParametersWatchTableView(QtGui.QTableView):
  def __init__(self, parent = None):
    super(ObservedParametersWatchTableView, self).__init__(parent)
    self.horizontalHeader().setResizeMode(QtGui.QHeaderView.Stretch)
    self.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
    self.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
    
    self.menu = QtGui.QMenu(self)
    
    copyAction = QtGui.QAction('Copy to clipboard', self)
    copyAction.triggered.connect(self.copyObservedParametersWatchListElement)
    
    saveAction = QtGui.QAction('Save all to CSV', self)
    saveAction.triggered.connect(self.saveWatchList)
    
    self.menu.addAction(copyAction)
    self.menu.addAction(saveAction)
    self.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
    
    self.paramModel = None
    self.watchListDelegate = None
    
  def setDepthCamera(self, depthCamera):
    self.depthCamera = depthCamera
    r, c = self.depthCamera.configFile.getConfigSet("observed_params")
    
    if not r or not c:
      return False
    
    self.clear()
    
    self.paramModel = ParameterModel(self.depthCamera, c.params, self)
    
    self.currentRow = -1
    
    self.watchListDelegate = ParameterDelegate(self, depthCamera, c.paramNames, self)
    self.setItemDelegate(self.watchListDelegate)
    self.setModel(self.paramModel)
    
    return True
    
  def contextMenuEvent(self, event):
    self.menu.popup(event.globalPos())
    
  def clear(self):
    if self.paramModel:
      self.paramModel.clear()
      
    self.setModel(None)
    self.setItemDelegate(None)
    
  @QtCore.Slot()
  def copyObservedParametersWatchListElement(self):
    s = self.paramModel.getWatchElementString(self.currentRow)
    print s
    if s:
      c = QtGui.QApplication.clipboard()
      c.setText(s)
      self.currentRow = -1
    else:
      QtGui.QMessageBox.critical(self, 'Watch List Element', 'Failed to copy watch list element')
      
  @QtCore.Slot()
  def saveWatchList(self):
    
    s = 'sep=;\n' + self.paramModel.getHeaderCSVString() + '\n'
    
    for k in self.paramModel.watchListRows:
      if not self.paramModel.watchListElements.has_key(k):
        continue
      
      w = self.paramModel.watchListElements[k]
      s += k + ";" + w[0] + ";" + w[1] + '\n'
    
    filename, _ = QtGui.QFileDialog.getSaveFileName(self, 'Save CSV to file', filter = "CSV files (*.csv)")
    
    if filename:
      try:
        print 'Saving CSV to file ', filename, '...'
        f = open(filename, 'w')
        f.write(s)
        f.close()
        print 'Done'
      except IOError, e:
        QtGui.QMessageBox.critical('Save CSV to file', 'Failed to save CSV to file ' + filename)
    
  def mousePressEvent(self, e):
    super(ObservedParametersWatchTableView, self).mousePressEvent(e)
    self.currentRow = self.currentIndex().row()
    
    
class ObservedParametersWatchListView(QtGui.QWidget):
  
  def __init__(self, depthCameraController, parent = None):
    super(ObservedParametersWatchListView, self).__init__(parent)
    
    self.setMaximumWidth(300)
    self.setMinimumWidth(300)
    
    self.depthCameraController = depthCameraController
    
    self.depthCameraController.sourceListChanged.connect(self.init)
    self.depthCameraController.sourceSelected.connect(self.init)
    
    vlayout = QtGui.QVBoxLayout(self)
    
    l = QtGui.QLabel('Observed Parameters')
    l.setAlignment(QtCore.Qt.AlignCenter)
    l.setStyleSheet('font-weight: 500;')
    
    vlayout.addWidget(l)
    
    self.tableView = ObservedParametersWatchTableView()
    
    vlayout.addWidget(self.tableView)
    
    self.width = self.height = 0
    
    self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Preferred)
    
    
  def init(self):
    s = self.depthCameraController.getCurrentSource()
    if s is not None and s.isLiveStream():
      if self.tableView.setDepthCamera(self.depthCameraController.getDepthCamera()):
        self.setMinimumWidth(300)
        self.setMaximumWidth(300)
      else:
        self.setMinimumWidth(0)
        self.setMaximumWidth(0)
    else:
      self.tableView.clear()
      self.setMinimumWidth(0)
      self.setMaximumWidth(0)
    
    
    
      