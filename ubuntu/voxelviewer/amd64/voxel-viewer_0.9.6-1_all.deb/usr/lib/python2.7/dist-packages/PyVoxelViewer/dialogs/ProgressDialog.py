#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.common.Logger import Logger

import Voxel

from threading import Thread


class Messager(QtCore.QObject):
  setProgress = QtCore.Signal(bool, object, str)
  def __init__(self, parent = None):
    super(Messager, self).__init__(parent)
    
    self.qthread = QtCore.QThread()
    self.qthread.start()
    
    self.moveToThread(self.qthread)
  
  def stop(self):
    self.qthread.exit()
    self.qthread.wait()

class ProgressDialog(QtGui.QDialog):
  
  messager = Messager()
  dialog = None
  
  def __init__(self, parent = None):
    super(ProgressDialog, self).__init__(parent)
    
    self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.Dialog)
    self.setModal(True)
    
    self.setMinimumWidth(400)

    layout = QtGui.QVBoxLayout(self)

    self.progress = QtGui.QProgressBar()
    
    layout.addWidget(self.progress)
    self.progress.setValue(0)
    
    self.logBox = QtGui.QLabel()
    layout.addWidget(self.logBox)
    
  @staticmethod
  def showProgressDialog(completed, p, message, parent = None):
    if not completed:
      if not ProgressDialog.dialog:
        ProgressDialog.dialog = ProgressDialog(parent)
        ProgressDialog.dialog.show()
      
      if p >= 0:
        ProgressDialog.dialog.progress.setRange(0, 100)
        ProgressDialog.dialog.progress.setValue(p)
      else:
        ProgressDialog.dialog.progress.setRange(0, 0)
      ProgressDialog.dialog.logBox.setText(message)
    else:
      ProgressDialog.dialog.accept()
    
  @staticmethod
  def setProgress(completed, p, message):
    ProgressDialog.messager.setProgress.emit(completed, p, message)
    
  def keyPressEvent(self, ev):
    if ev.key() == QtCore.Qt.Key_Escape:
      ev.accept()
    else:
      super(ProgressDialog, self).keyPressEvent(ev)

  
ProgressDialog.messager.setProgress.connect(ProgressDialog.showProgressDialog, QtCore.Qt.QueuedConnection)