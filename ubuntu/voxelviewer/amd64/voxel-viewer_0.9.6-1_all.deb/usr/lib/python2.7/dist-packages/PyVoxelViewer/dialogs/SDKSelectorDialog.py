#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from PyVoxelViewer.common.SDKSelector import SDKSelector

import os, sys

class SDKSelectorDialog(QtGui.QDialog):
  def __init__(self, showExit = False, parent = None):
    super(SDKSelectorDialog, self).__init__(parent)

    self.setWindowTitle('Voxel SDK Selection')
    self.setMinimumWidth(500)

    layout = QtGui.QVBoxLayout()

    self.message = QtGui.QLabel('Please specify path to Voxel SDK below. Some possible examples paths are given below - ' +
                                '<ol>' +
                                '<li>C:\\Program Files\\Voxel SDK x.y.z which refers to an installed SDK with version x.y.z</li>' +
                                '<li>C:\\path\\to\\voxelsdk\\build which refers to binary build directory in source directory of Voxel SDK' +
                                '<li>C:\\Program Files\\Voxel Viewer x.y.z\\voxel-sdk which refers to minimal Voxel SDK which is part of Voxel viewer with version x.y.z</li>' +
                                '</ol><br/>')

    layout.addWidget(self.message)

    hlayout = QtGui.QHBoxLayout()
    hlayout.addWidget(QtGui.QLabel('SDK Path'))
    self.sdkPath = QtGui.QLineEdit()
    self.completer = QtGui.QCompleter(self)
    self.completer.setModel(QtGui.QDirModel(self.completer))
    self.completer.setCompletionMode(QtGui.QCompleter.PopupCompletion)
    self.sdkPath.setCompleter(self.completer)
    self.sdkPath.setText(SDKSelector.getSDKPath())
    hlayout.addWidget(self.sdkPath)

    self.sdkPathBrowse = QtGui.QPushButton('...')
    hlayout.addWidget(self.sdkPathBrowse)
    self.sdkPathBrowse.clicked.connect(self.browseSDKPath)

    layout.addLayout(hlayout)

    self.sdkVersion = QtGui.QLabel()
    layout.addWidget(self.sdkVersion)

    buttons = QtGui.QDialogButtonBox(self)

    self.detect = QtGui.QPushButton("&Detect", self)

    self.closeButton = QtGui.QPushButton("&Close", self)

    self.detect.clicked.connect(self.setAndDetectSDKVersion)

    buttons.addButton(self.detect, QtGui.QDialogButtonBox.ActionRole)
    buttons.addButton(self.closeButton, QtGui.QDialogButtonBox.RejectRole)

    if showExit:
      self.exitButton = QtGui.QPushButton('E&xit Application', self)
      buttons.addButton(self.exitButton, QtGui.QDialogButtonBox.ResetRole)
      self.exitButton.clicked.connect(self.exitApplication)

    self.setWindowFlags(QtCore.Qt.Dialog | QtCore.Qt.CustomizeWindowHint | QtCore.Qt.WindowTitleHint)

    buttons.rejected.connect(self.reject)
    layout.addWidget(buttons)

    self.setLayout(layout)

    self.getSDKVersion()
    self.changed = False
    self.detect.setFocus()


  def exitApplication(self):
    app = QtGui.QApplication.instance()
    app.quit()
    sys.exit(0)

  def browseSDKPath(self):
    dirname = QtGui.QFileDialog.getExistingDirectory(self, 'Save Frame Stream', str(self.sdkPath.text()), QtGui.QFileDialog.ShowDirsOnly)

    if dirname:
      self.sdkPath.setText(dirname)


  def setAndDetectSDKVersion(self):
    sdkPath = SDKSelector.getSDKPath()
    newSDKPath = str(self.sdkPath.text())

    if sdkPath != "" and sdkPath == newSDKPath:
      return

    if newSDKPath == "":
      QtGui.QMessageBox.critical(self, "Invalid path", "Please specify a non-empty SDK path")
      return

    if not os.path.isdir(newSDKPath):
      QtGui.QMessageBox.critical(self, "Invalid path", "Please specify a valid directory for SDK path")
      return

    SDKSelector.setSDKPath(newSDKPath)
    self.changed = True
    self.getSDKVersion()

  def getSDKVersion(self):
    Voxel = SDKSelector.getVoxelSDK()

    if Voxel is not None:
      version = Voxel.Configuration.getSDKVersion()
      self.sdkVersion.setText('Detected Voxel SDK with version: %d.%d.%d (ABI: %d, CONF: %d)'%(version.major, version.minor, version.patch, version.abi, version.conf))
      self.sdkVersion.setStyleSheet('QLabel {color: inherit;}')
    else:
      self.sdkVersion.setText('Failed to import Voxel SDK')
      self.sdkVersion.setStyleSheet('QLabel {color: #FFAAAA;}')

  @staticmethod
  def interactiveGetVoxelSDK(V = None, showExit = False):

    changed = False
    while V is None:
      changed = SDKSelectorDialog.showDialog(showExit = showExit)
      V = SDKSelector.getVoxelSDK()

    if changed:
      print 'Restarting Voxel Viewer...'
      app = QtGui.QApplication.instance()
      app.quit()
      os.execl(sys.executable, sys.executable, *sys.argv)

    return V

  # static method to create the dialog and return
  @staticmethod
  def showDialog(parent = None, showExit = False):
    dialog = SDKSelectorDialog(showExit, parent)
    result = dialog.exec_()

    return dialog.changed