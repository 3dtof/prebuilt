#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

class CalibrationConclusionPage(QtGui.QWizardPage):
  
  def __init__(self, calibrationWizard, parent = None):
    super(CalibrationConclusionPage, self).__init__(parent)
    self.calibrationWizard = calibrationWizard
    
    self.setTitle('Congratulations!')
    self.setSubTitle('Calibration completed')
    
    
    
  