#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from PyVoxelViewer.models.DepthCameraStreamController import DepthCameraStreamController

import os
import csv

import math

import numpy as np

import Voxel


class CalibrationWriteToHardwarePage(QtGui.QWizardPage):
  
  def __init__(self, calibrationWizard, parent = None):
    super(CalibrationWriteToHardwarePage, self).__init__(parent)
    self.calibrationWizard = calibrationWizard
    
    self.complete = False
    
    #TODO Define the steps to write self.calibrationWizard.currentConfigurations (list of current configurations to write to hardware)
    self.setTitle('Congratulations!')
    self.setSubTitle('Calibration Successfully Completed')
    
    self.vlayout = QtGui.QVBoxLayout(self)
    self.label = QtGui.QLabel('')
    self.label.setWordWrap(True)
    self.vlayout.addWidget(self.label)
    
    hlayout = QtGui.QHBoxLayout()
    hlayout.addStretch()
    self.button = QtGui.QPushButton('Write to Hardware')
    self.button.pressed.connect(self.writeToHardware)
    hlayout.addWidget(self.button)
    hlayout.addStretch()
    
    self.vlayout.addLayout(hlayout)
    
  def enterPage(self):
    for n, c in self.calibrationWizard.currentConfigurations.iteritems():
      self.label.setText('Writing profile "' + n + '"...')
      c.remove("calib", Voxel.CALIB_DISABLE)
      c.write()
    
    self.label.setText('Local profiles have been updated. Please click on the button below to write to camera.')
    
  @QtCore.Slot()
  def writeToHardware(self):
    self.label.setText('Erasing profiles on camera. Please wait...')
    
    if not self.calibrationWizard.depthCamera.configFile.removeAllHardwareCameraProfiles():
      self.label.setText('Failed to erase profiles on camera. Click on the button again to re-try')
      return
    
    self.label.setText('Writing profiles to camera. Please wait...')
    
    r, id = self.calibrationWizard.depthCamera.configFile.saveCameraProfileToHardware(self.calibrationWizard.currentConfigurationIDs[self.calibrationWizard.PROFILE_NORMAL], True, True, "Calibrated ")
    if not r:
      QtGui.QMessageBox.critical(self, 'Save Profile to Hardware', 'Failed to save camera profile to hardware')
      self.label.setText('Sorry! Failed to save camera profile to hardware. Please re-run wizard or use the "Profiles Manager" to retry writing camera profiles to hardware.')
    else:
        self.label.setText('Congratulations! Camera profiles have been created and written to hardware. ' + \
      'Please click finish now and verify that calibration is alright in the viewer. If it is not fine, please re-run this wizard.')
        self.button.setEnabled(False)
    