#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.views.ParameterHandler import *

from PyVoxelViewer.dialogs.DetailedMessageDialog import DetailedMessageDialog

class ParameterModel(QtCore.QAbstractTableModel):
  def __init__(self, depthCamera, params):
    super(ParameterModel, self).__init__()
    
    self.params = params
    self.depthCamera = depthCamera
    
  def flags(self, index):
    f = super(ParameterModel, self).flags(index)
    
    param = self.params[index.row()]
    
    if index.column() == 1 and param and param.ioType() != Voxel.Parameter.IO_READ_ONLY:
      return f | QtCore.Qt.ItemIsEditable | QtCore.Qt.ItemIsSelectable
    else:
      return f | QtCore.Qt.ItemIsSelectable
    
  def rowCount(self, parent = QtCore.QModelIndex()):
    return len(self.params)
  
  def columnCount(self, parent = QtCore.QModelIndex()):
    return 2
  
  def data(self, index, role = QtCore.Qt.DisplayRole):
    
    if role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      param = self.params[index.row()]
      
      if param:
        v = ParameterHandler.getParameterHandler(self.depthCamera, param)
        
        if index.column() == 0:
          return v.getName()
        else: # index.column() == 1
          return v.getDisplayValue()
      else:
        return None
  
  def headerData(self, section, orientation, role = QtCore.Qt.DisplayRole):
    if role == QtCore.Qt.DisplayRole:
      if orientation == QtCore.Qt.Horizontal:
        if section == 0:
          return "Name"
        else:
          return "Value"
      else:
        return None
    elif role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      return None
  
  
class ParameterDelegate(QtGui.QAbstractItemDelegate):
  def __init__(self, tableWidget, tableView, depthCamera, params, proxyModel):
    super(ParameterDelegate, self).__init__()
    
    self.tableWidget = tableWidget
    self.tableView = tableView
    
    self.depthCamera = depthCamera
    self.params = params
    self.proxyModel = proxyModel
    
    self.currentEditor = None
    
  def paint(self, painter, option, index):
    if option.state & QtGui.QStyle.State_Selected:
      if option.state & QtGui.QStyle.State_Active:
        painter.setBrush(QtGui.QBrush(self.tableView.palette().highlight()))
      else:
        painter.setBrush(QtGui.QBrush(self.tableView.palette().color(QtGui.QPalette.Inactive, QtGui.QPalette.Highlight)))
      painter.drawRect(option.rect)
    painter.drawText(option.rect, QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter, index.data())
  
  def sizeHint(self, option, index):
    return option.rect.size() # Occupy full size
  
  def createEditor(self, parent, option, index):
    if index.column() == 0:
      return None
    
    i = self.proxyModel.mapToSource(index)
    
    p = self.params[i.row()]
    
    if p:
      self.param = ParameterHandler.getParameterHandler(self.depthCamera, p)
      
      self.currentEditor = self.param.getDisplayWidget(parent)
      
      self.currentEditor.paramValueChanged.connect(lambda v: (self.param.set(v), self.tableWidget.paramValueSet.emit(p.name())))
      
      return self.currentEditor
    else:
      return None
  
  def setModelData(self, editor, model, index):
    i = self.proxyModel.mapToSource(index)
    
    p = self.params[i.row()]
    
    if p:
      h = ParameterHandler.getParameterHandler(self.depthCamera, p)
      
      r, value = h.set(editor.getValue())
      
      if not r:
        QtGui.QMessageBox.critical(self.tableView, 'Parameter', 'Failed to set parameter "' + p.name() + '"')
        
      self.tableWidget.paramValueSet.emit(p.name())
        
  def updateEditorGeometry(self, editor, option, index):
    editor.setGeometry(option.rect)
    
  def closeCurrentEditor(self):
    if self.currentEditor:
      self.closeEditor.emit(self.currentEditor, QtGui.QAbstractItemDelegate.NoHint)
      self.currentEditor = None
    
  def eventFilter(self, object, event):
    if not object.isWidgetType():
      return
    
    if event.type() == QtCore.QEvent.KeyPress:
      if event.key() == QtCore.Qt.Key_Tab:
        self.commitData.emit(object)
        self.closeEditor.emit(object, QtGui.QAbstractItemDelegate.EditNextItem)
      elif event.key() == QtCore.Qt.Key_Backtab:
        self.commitData.emit(object)
        self.closeEditor.emit(object, QtGui.QAbstractItemDelegate.EditPreviousItem)
      elif event.key() == QtCore.Qt.Key_Enter or event.key() == QtCore.Qt.Key_Return:
        self.commitData.emit(object)
        self.closeEditor.emit(object, QtGui.QAbstractItemDelegate.NoHint)
      elif event.key() == QtCore.Qt.Key_Escape:
        self.closeEditor.emit(object, QtGui.QAbstractItemDelegate.RevertModelCache)
      else:
        return False
        
      self.currentEditor = None
      #if object.parentWidget():
      #  object.parentWidget().setFocus()
        
      return True
    else:
      return False
      

class ParameterDockWidget(QtGui.QDockWidget):
  
  paramValueSet = QtCore.Signal(str)
  
  def __init__(self, window, depthCameraController):
    QtGui.QDockWidget.__init__(self, "Parameters")
    self.setMinimumWidth(300)
    self.setMaximumWidth(350)
    
    self.search = QtGui.QLineEdit()
    self.search.setPlaceholderText("Search")
    self.search.textEdited.connect(self.filterParameters)
    self.tableView = QtGui.QTableView()
    self.tableView.setEditTriggers(QtGui.QAbstractItemView.CurrentChanged | QtGui.QAbstractItemView.DoubleClicked | QtGui.QAbstractItemView.SelectedClicked | QtGui.QAbstractItemView.EditKeyPressed)
    self.proxyModel = None
    self.paramViewDelegate = None
    self.params = None
    self.tableView.horizontalHeader().setResizeMode(QtGui.QHeaderView.Stretch)
    self.tableView.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
    self.tableView.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
    
    p  = self.tableView.palette()
    p.setColor(QtGui.QPalette.Highlight, p.color(QtGui.QPalette.Highlight).lighter(180))
    p.setColor(QtGui.QPalette.HighlightedText, QtGui.QColor("black"))
    self.tableView.setPalette(p)
    
    aboutAction = QtGui.QAction('Ab&out Parameter', self)
    aboutAction.setShortcut('Ctrl+O')
    aboutAction.setStatusTip('About selected parameter')
    aboutAction.triggered.connect(self.showAboutParameterDialog)
    
    refreshAction = QtGui.QAction('R&efresh', self)
    refreshAction.setShortcut('Ctrl+E')
    refreshAction.setStatusTip('About selected parameter')
    refreshAction.triggered.connect(self.refreshParameter)
    
    self.tableView.addAction(refreshAction)
    self.tableView.addAction(aboutAction)
    self.tableView.setContextMenuPolicy(QtCore.Qt.ActionsContextMenu)
    
    layout = QtGui.QVBoxLayout()
    hlayout = QtGui.QHBoxLayout()
    self.saveParameters = QtGui.QToolButton()
    self.saveParameters.setIcon(window.style().standardIcon(QtGui.QStyle.SP_DialogSaveButton))
    self.saveParameters.setToolTip('Save Parameters to CSV')
    self.saveParameters.clicked.connect(self.saveParametersToCSV)
    hlayout.addWidget(self.search)
    hlayout.addWidget(self.saveParameters)
    layout.addLayout(hlayout)
    layout.addWidget(self.tableView)
    
    self.mwidget = QtGui.QWidget()
    self.mwidget.setLayout(layout)
    
    self.model = None
    
    self.setWidget(self.mwidget)
    
    self.depthCameraController = depthCameraController
    
    self.setParamList()
    
    self.depthCameraController.onDepthCameraSet.connect(self.setParamList)
    
  @QtCore.Slot(str)
  def initParams(self, paramName):
    if self.model:
      self.model.reset()
    
  @QtCore.Slot()
  def showAboutParameterDialog(self):
    
    r = self.proxyModel.mapToSource(self.tableView.currentIndex()).row()
    
    if self.depthCameraController.getDepthCamera() and self.params and len(self.params) > r:
      p = self.params[r]
      h = ParameterHandler.getParameterHandler(self.depthCameraController.getDepthCamera(), p)
      about = DetailedMessageDialog.showDialog('About Parameter', h.getDescription(), self)
    else:
      QtGui.QMessageBox.critical(self, 'About Parameter', 'Failed to get description')
      
  def saveParametersToCSV(self):
    if not self.params:
      QtGui.QMessageBox.critical(self, 'Save Parameters Failed', 'Could not find parameters to save')
      return
    
    s = 'sep=;\nName;Value\n'
    
    for p in self.params:
      v = ParameterHandler.getParameterHandler(self.depthCameraController.getDepthCamera(), p)
      
      if v:
        s += v.getName() + ';' + v.getDisplayValue() + '\n'
    
    filename, _ = QtGui.QFileDialog.getSaveFileName(self, 'Save Parameters to CSV file', filter = "CSV files (*.csv)")
    
    if filename:
      try:
        print 'Saving parameters to CSV file ', filename, '...'
        f = open(filename, 'w')
        f.write(s)
        f.close()
        print 'Done'
      except IOError, e:
        QtGui.QMessageBox.critical('Save Parameters', 'Failed to save CSV to file ' + filename)
  
  @QtCore.Slot()
  def refreshParameter(self):
    
    r = self.proxyModel.mapToSource(self.tableView.currentIndex()).row()
    
    if self.depthCameraController.getDepthCamera() and self.params and len(self.params) > r:
      p = self.params[r]
      h = ParameterHandler.getParameterHandler(self.depthCameraController.getDepthCamera(), p)
      
      h.get(refresh = True)
    else:
      QtGui.QMessageBox.critical(self, 'Refresh Parameter', 'Failed to get parameter')
  
  @QtCore.Slot(str)
  def filterParameters(self, text):
    if self.proxyModel:
      self.proxyModel.setFilterRegExp(text)
      
      if self.paramViewDelegate:
        self.paramViewDelegate.closeCurrentEditor()
      self.tableView.clearFocus()
      self.tableView.clearSelection()
      self.search.setFocus()
  
  @QtCore.Slot()
  def setParamList(self):
    
    d = self.depthCameraController.getDepthCamera()
    
    if d:
      self.params = d.getParameters().values()
      self.model = ParameterModel(d, self.params)
      self.proxyModel = QtGui.QSortFilterProxyModel()
      self.proxyModel.setSortCaseSensitivity(QtCore.Qt.CaseInsensitive)
      self.proxyModel.setFilterCaseSensitivity(QtCore.Qt.CaseInsensitive)
      self.paramViewDelegate = ParameterDelegate(self, self.tableView, d, self.params, self.proxyModel)
      self.tableView.setItemDelegate(self.paramViewDelegate)
      self.tableView.setModel(self.proxyModel)
      self.tableView.setAlternatingRowColors(True)
      self.proxyModel.setSourceModel(self.model)
      self.tableView.resizeColumnsToContents()
      self.tableView.setSortingEnabled(True)
    
      
