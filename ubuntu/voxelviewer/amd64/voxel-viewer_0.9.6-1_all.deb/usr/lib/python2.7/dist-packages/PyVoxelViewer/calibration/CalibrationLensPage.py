#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui
from CalibrationPage import CalibrationPage

from PyVoxelViewer.views.XYSpinBox import XYSpinBox

from PyVoxelViewer.icons import icons

from PyVoxelViewer.calibration.CalibrationDataCaptureDialog import CalibrationDataCaptureDialog

import os

import glob

import numpy as np

import cv2

import datetime


class CalibrationImage(QtGui.QListWidgetItem):
  
  def __init__(self, imageFile, calibrationLensPage):
    super(CalibrationImage, self).__init__(QtGui.QIcon(imageFile), os.path.basename(imageFile))
    
    self.imageFile = imageFile
    self.calibrationLensPage = calibrationLensPage
    self.criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
    
  def computeCorners(self):
    self.rows, self.cols = self.calibrationLensPage.checkerBoard.getXY()

    # prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
    self.objpoints = np.zeros((self.rows*self.cols, 3), np.float32)
    self.objpoints[:,:2] = np.mgrid[0:self.cols, 0:self.rows].T.reshape(-1,2)
    
    self.img = cv2.imread(self.imageFile)
    gray = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)# images are converted to grayscale
    self.imageShape = gray.shape
    
    # Find the chess board corners
    self.ret, self.corners = cv2.findChessboardCorners(gray, (self.cols, self.rows),None)
    
    if self.corners is not None:
      cv2.cornerSubPix(gray, self.corners, (4, 4),(-1,-1), self.criteria)
      
  def showCorners(self):
    self.computeCorners()
    
    if self.corners is None:
      QtGui.QMessageBox.critical(self.calibrationLensPage, 'Corners not found', 'Necessary corners could not be computed')
      return
    
    cv2.drawChessboardCorners(self.img, (self.cols, self.rows), self.corners, self.ret)
    cv2.namedWindow(os.path.basename(self.imageFile), cv2.WINDOW_NORMAL)
    cv2.imshow(os.path.basename(self.imageFile), self.img)
    cv2.waitKey()
    cv2.destroyWindow(os.path.basename(self.imageFile))
    
    del self.img



class CalibrationLensPage(CalibrationPage):
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationLensPage, self).__init__(calibrationWizard, index, parent = parent, 
          definingParams = definingParams, calibParams = calibParams)
    
    self.setTitle('Lens Calibration')
    self.setSubTitle('Lens related calibration')
    
    
    self.vlayout = QtGui.QVBoxLayout(self)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Checkerboard Layout:'))
    
    self.checkerBoard = XYSpinBox()
    self.checkerBoard.xSpinBox.setRange(2, 24)
    self.checkerBoard.ySpinBox.setRange(2, 24)
    self.checkerBoard.setXY(9, 13)
    self.checkerBoard.xSpinBox.valueChanged.connect(self.computeCorners)
    self.checkerBoard.ySpinBox.valueChanged.connect(self.computeCorners)
    
    hlayout.addWidget(self.checkerBoard)
    hlayout.addStretch()
    
    self.calibrateButton = QtGui.QPushButton('&Calibrate')
    self.calibrateButton.setShortcut('Alt+C')
    self.calibrateButton.pressed.connect(self.performCalibration)
    hlayout.addWidget(self.calibrateButton)
    
    self.vlayout.addLayout(hlayout)
    
    groupbox = QtGui.QGroupBox()
    groupbox.setTitle('Input Images showing Lens Distortion')
    self.vlayout.addWidget(groupbox)
    
    self.calibrationImages = QtGui.QListWidget()
    self.calibrationImages.keyPressEvent = self.calibratedImagesKeyPressEvent
    self.calibrationImages.setResizeMode(QtGui.QListView.Adjust)
    self.calibrationImages.setWordWrap(True)
    self.calibrationImages.setTextElideMode(QtCore.Qt.ElideNone)
    self.calibrationImages.itemDoubleClicked.connect(self.showImage)
    self.calibrationImages.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
    self.calibrationImages.customContextMenuRequested.connect(self.showContextMenu)
    
    self.menu = QtGui.QMenu(self.calibrationImages)
    
    self.removeAction = QtGui.QAction('Remove', self.calibrationImages)
    self.removeAction.triggered.connect(self.deleteImage)
    self.removeAction.setShortcut('Del')
    self.menu.addAction(self.removeAction)
    
    self.showAction = QtGui.QAction('Show Corners', self.calibrationImages)
    self.showAction.triggered.connect(self.showImage)
    self.showAction.setShortcut('Return')
    self.menu.addAction(self.showAction)
    
    vglayout = QtGui.QVBoxLayout()
    vglayout.addWidget(self.calibrationImages)
    groupbox.setLayout(vglayout)
    
    self.calibrationImages.setViewMode(QtGui.QListView.IconMode)
    self.calibrationImages.setIconSize(QtCore.QSize(80, 60))
    self.calibrationImages.setSpacing(4)
    self.calibrationImages.addItem(QtGui.QListWidgetItem(QtGui.QIcon(':/add.png'), 'Add'))
    
    self.lensParamsGroupbox = QtGui.QGroupBox()
    self.lensParamsGroupbox.setTitle('Lens Parameters')
    self.vlayout.addWidget(self.lensParamsGroupbox)
    
    self.lensParams = QtGui.QLabel()
    
    vglayout = QtGui.QVBoxLayout()
    vglayout.addWidget(self.lensParams)
    self.lensParamsGroupbox.setLayout(vglayout)
    
    self.lensParamsGroupbox.hide()
    
    self.calibrated = False
    
  def showContextMenu(self, point):
    item = self.calibrationImages.itemAt(point)
    
    if item:
      index = self.calibrationImages.row(item)
      
      if index < self.calibrationImages.count() - 1:
        self.menu.popup(self.calibrationImages.mapToGlobal(point))
        
    
  def calibratedImagesKeyPressEvent(self, event):
    if event.key() == QtCore.Qt.Key_Return:
      self.showImage()
      event.accept()
    elif event.key() == QtCore.Qt.Key_Delete:
      self.deleteImage()
      event.accept()
    else:
      QtGui.QListWidget.keyPressEvent(self.calibrationImages, event)
  
  def initializePage(self):
    super(CalibrationLensPage, self).initializePage()
    
    self.calibrated = False
    self.calibrationImages.clear()
    self.calibrationImages.addItem(QtGui.QListWidgetItem(QtGui.QIcon(':/add.png'), 'Add'))
    
    if not os.path.exists(self.basePath):
      os.makedirs(self.basePath)
    
    self.calibrationImageFiles = glob.glob(self.basePath + os.sep + '*.png')
    
    for f in self.calibrationImageFiles:
      self.calibrationImages.insertItem(self.calibrationImages.count() - 1, CalibrationImage(f, self))
      
  def addImage(self, image):
    self.calibrationImages.insertItem(self.calibrationImages.count() - 1, CalibrationImage(image, self))

  @QtCore.Slot(int)
  def computeCorners(self, checkerBoardSize):
    for i in range(0, self.calibrationImages.count()):
      image = self.calibrationImages.item(i)
      
      if isinstance(image, CalibrationImage):
        image.computeCorners()
    
  def performCalibration(self):
    
    self.objpoints = [] # 3d point in real world space
    self.imgpoints = [] # 2d points in image plane.
    self.imageShape = None
    
    for i in range(0, self.calibrationImages.count()):
      image = self.calibrationImages.item(i)
      
      if isinstance(image, CalibrationImage):
        image.computeCorners()
        if self.imageShape is None:
          self.imageShape = image.imageShape
          
        self.objpoints.append(image.objpoints)
        self.imgpoints.append(image.corners)
        
    try:
      retval, cameraMatrix, distCoeffs, rvecs, tvecs = cv2.calibrateCamera(self.objpoints, self.imgpoints, self.imageShape[::-1])
    except Exception, e:
      print e
      retval = False
    
    if retval:
      fx = cameraMatrix[0][0]
      fy = cameraMatrix[1][1]
      
      cx = cameraMatrix[0][2]
      cy = cameraMatrix[1][2]
      
      if len(distCoeffs[0]) >= 5:
        k1, k2, p1, p2, k3 = distCoeffs[0]
      else:
        k1, k2, p1, p2 = distCoeffs[0][0:4]
        k3 = 0
      
      self.calibParams['fx'] = fx
      self.calibParams['fy'] = fy
      self.calibParams['cx'] = cx
      self.calibParams['cy'] = cy
      self.calibParams['k1'] = k1
      self.calibParams['k2'] = k2
      self.calibParams['k3'] = k3
      self.calibParams['p1'] = p1
      self.calibParams['p2'] = p2
      
      self.lensParams.setText('fx = %f, fy = %f, \ncx = %f, cy = %f, \nk1 = %f, k2 = %f, k3 = %f, \np1 = %f, p2 = %f'%(fx, fy, cx, cy, k1, k2, k3, p1, p2))
      self.lensParamsGroupbox.show()
      self.calibrated = True
      self.completeChanged.emit()
    else:
      QtGui.QMessageBox.critical(self.calibrationWizard, 'Lens Calibration Failed', 'Failed to perform lens calibration')
      
  def isComplete(self):
    return self.calibrated
  
  def showImage(self, item = None):
    if not item:
      item = self.calibrationImages.currentItem()
      
    if isinstance(item, CalibrationImage):
      item.showCorners()
    else: # Capture and add image
      newFileName = self.basePath + os.sep + '%s.png'%(datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S'))
      data = CalibrationDataCaptureDialog.showDialog(self.calibrationWizard.cameraSystem, \
        self.depthCamera, newFileName,
        'amplitude', 200)

      if data is None:
        return

      self.addImage(newFileName)

  def deleteImage(self):
    item = self.calibrationImages.currentItem()
    
    if not item:
      return
    
    if isinstance(item, CalibrationImage):
      
      d = QtGui.QMessageBox.question(self.calibrationWizard, 'Remove Image', \
        'Are you sure you want to remove the image?', buttons = QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
      
      if d == QtGui.QMessageBox.Yes:
        os.remove(item.imageFile)
        self.calibrationImages.takeItem(self.calibrationImages.row(item))