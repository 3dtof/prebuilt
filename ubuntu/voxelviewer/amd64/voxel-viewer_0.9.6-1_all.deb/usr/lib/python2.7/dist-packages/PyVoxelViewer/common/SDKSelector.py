
from PyVoxelViewer.models.Config import Config

from PyVoxelViewer.common.Common import insertToPathVariable, removeFromPathVariable

import os, sys

class SDKSelector:

  VIEWER_SDK_CONF = "sdk.conf"

  VOXEL_SDK = None

  @staticmethod
  def initEnvironment():
    SDKSelector.VOXEL_SDK = None

    c = Config.getConfig(SDKSelector.VIEWER_SDK_CONF)

    # Add installed location to PATH for picking all necessary DLLs - especially the dynamically loaded MSVCRT ones
    if os.name == 'nt':
      import win32api
      path = win32api.GetLongPathName(os.path.dirname(os.path.realpath(sys.argv[0])))
      sys.path.insert(0, path)
      insertToPathVariable('PATH', path)

    path = ''
    if not c.hasOption("sdk", "path"):
      if os.name == 'nt':
        import win32api
        path = win32api.GetLongPathName(os.path.dirname(os.path.realpath(sys.argv[0])))
        path = path + os.sep + "voxel-sdk"
      else:
        path = "/usr"

      p = path + os.sep + "lib" + os.sep + "voxel"

      if os.path.isdir(p):
        c.set("sdk", "path", path)
      else:
        if 'VOXEL_SDK_PATH' in os.environ:
          path = os.environ['VOXEL_SDK_PATH']
          c.set("sdk", "path", path)
        else:
          print 'Failed to get default Voxel SDK path'
          return
    else:
      path = c.get("sdk", "path")

    libPath = path + os.sep + "lib"
    pythonPath = libPath + os.sep + "python2.7"

    sys.path.insert(0, pythonPath)

    if os.name == 'nt':
      insertToPathVariable('PATH', libPath)
    else:
      insertToPathVariable('LD_LIBRARY_PATH', libPath)

  @staticmethod
  def clearEnvironment():
    c = Config.getConfig(SDKSelector.VIEWER_SDK_CONF)

    if not c.hasOption("sdk", "path"):
      return

    sdkPath = c.get("sdk", "path")
    libPath = sdkPath + os.sep + "lib"
    pythonPath = libPath + os.sep + "python2.7"

    sys.path.remove(pythonPath)

    if os.name == 'nt':
      removeFromPathVariable('PATH', libPath)
    else:
      removeFromPathVariable('LD_LIBRARY_PATH', libPath)

  @staticmethod
  def setSDKPath(sdkPath):
    sdkPath = sdkPath.rstrip('/').rstrip('\\')
    SDKSelector.clearEnvironment()
    c = Config.getConfig(SDKSelector.VIEWER_SDK_CONF)
    c.set("sdk", "path", sdkPath)
    SDKSelector.initEnvironment()

  @staticmethod
  def getSDKPath():
    c = Config.getConfig(SDKSelector.VIEWER_SDK_CONF)

    if c.hasOption("sdk", "path"):
      return c.get("sdk", "path").rstrip('/').rstrip('\\')
    else:
      return ""

  @staticmethod
  def getVoxelSDK():
    if SDKSelector.VOXEL_SDK is not None:
      return SDKSelector.VOXEL_SDK

    try:
      sdkPath = SDKSelector.getSDKPath()
      libPath = sdkPath + os.sep + "lib"

      V = __import__("Voxel")
      reload(V)
      Voxel = SDKSelector.VOXEL_SDK = __import__("Voxel")

      if os.name == 'nt':
        Voxel.Configuration.addPathToEnvironmentVariable("PATH", libPath)
      else:
        Voxel.Configuration.addPathToEnvironmentVariable("LD_LIBRARY_PATH", libPath)

      Voxel.Configuration.setSDKPath(sdkPath)
      return Voxel
    except ImportError, e:
      sys.stderr.write('Failed to import Voxel SDK Python bindings\n')
      return None