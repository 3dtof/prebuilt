#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

class XYSpinBox(QtGui.QWidget):
  
  def __init__(self, parent = None, flags = 0):
    super(XYSpinBox, self).__init__(parent, flags)
    
    layout = QtGui.QHBoxLayout()
    self.xSpinBox = QtGui.QSpinBox()
    self.ySpinBox = QtGui.QSpinBox()
    
    layout.addWidget(self.xSpinBox)
    layout.addWidget(QtGui.QLabel('x'))
    layout.addWidget(self.ySpinBox)
    
    layout.setContentsMargins(0, 0, 0, 0)
    
    self.setLayout(layout)
    
  def setXY(self, x, y):
    self.xSpinBox.setValue(x)
    self.ySpinBox.setValue(y)
    
  def getXY(self):
    return [self.xSpinBox.value(), self.ySpinBox.value()]
    
  def setRange(self, x1, x2, y1, y2):
    self.xSpinBox.setRange(x1, x2)
    self.ySpinBox.setRange(y1, y2)
    
  def installEventFilter(self, filter):
    super(XYSpinBox, self).installEventFilter(filter)
    self.xSpinBox.installEventFilter(filter)
    self.ySpinBox.installEventFilter(filter)