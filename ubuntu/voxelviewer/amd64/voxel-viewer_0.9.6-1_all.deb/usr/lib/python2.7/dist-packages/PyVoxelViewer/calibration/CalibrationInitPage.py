#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from functools import partial

import os

import copy

from PyVoxelViewer.models.Config import Config

import shutil

import Voxel

class CalibrationInitPage(QtGui.QWizardPage):
  
  def __init__(self, calibrationWizard, editIndex = -1, parent = None):
    super(CalibrationInitPage, self).__init__(parent)
    self.calibrationWizard = calibrationWizard
    self.depthCamera = self.calibrationWizard.depthCamera
    self.editIndex = editIndex
    
    self.setTitle('Calibration Wizard for Depth Camera')
    self.setSubTitle('Choose types of calibrations to perform')
    
    
  def initializePage(self):
    
    self.vlayout = QtGui.QVBoxLayout(self)
    
    self.groupbox = QtGui.QGroupBox()
    self.vlayout.addWidget(self.groupbox)
    
    self.groupbox.setTitle('Calibrations to perform')
    
    vglayout = QtGui.QVBoxLayout()
    
    self.groupbox.setLayout(vglayout)
    
    self.profileSelections = []
    
    for p in self.calibrationWizard.pages:
      
      c = QtGui.QCheckBox()
      c.setText(p.title())
      c.setChecked(p.doShow)
      
      self.profileSelections.append(c)
      
      #if not p.isPresentInPrevious():
      #  c.setDisabled(True)
        
      c.stateChanged.connect(partial(self.doShowStateChange, p))
      vglayout.addWidget(c)
      
    self.profileGroupbox = QtGui.QGroupBox()
    self.vlayout.addWidget(self.profileGroupbox)
    
    self.profileGroupbox.setTitle('Camera Profile')
    
    vglayout = QtGui.QVBoxLayout()
    self.profileGroupbox.setLayout(vglayout)
      
    hlayout = QtGui.QHBoxLayout()
    hlayout.addWidget(QtGui.QLabel('Select Camera Profile:'))
    
    self.profileNamesAndID = self.depthCamera.getCameraProfileNames()
    
    currentProfileID = self.depthCamera.getCurrentCameraProfileID()
    
    self.profileNames = []
    self.profileIDs = []
    
    i = 0
    index = 0
    editIndex = 0
    
    for k, v in self.profileNamesAndID.items():
      profile = self.depthCamera.configFile.getCameraProfile(k)
      
      if profile:
        if profile.getLocation() == Voxel.ConfigurationFile.IN_CAMERA:
          v += " (HW)";
      
      self.profileIDs.append(k)
      self.profileNames.append(v)
      
      if k == currentProfileID:
        index = i
        
      if k == self.editIndex:
        editIndex = i + 1
      
      i += 1
    
    profileNames = copy.deepcopy(self.profileNames)
    profileNames.insert(0, 'Add New')
    
    self.profiles = QtGui.QComboBox()
    self.profiles.addItems(profileNames)
    
    self.profiles.currentIndexChanged.connect(self.showHideNewProfileName)
    
    hlayout.addWidget(self.profiles)
    
    vglayout.addLayout(hlayout)
    
    self.newProfileName = QtGui.QWidget()
    
    vlayout = QtGui.QVBoxLayout()
    hlayout = QtGui.QHBoxLayout()
    hlayout.addWidget(QtGui.QLabel('New Camera Profile Name:'))
    
    self.newProfileNameEdit = QtGui.QLineEdit()
    self.newProfileNameEdit.setValidator(QtGui.QRegExpValidator(QtCore.QRegExp('[A-Za-z0-9 ]*')))
    self.newProfileNameEdit.setToolTip('Only alphanumeric characters are allowed')
    hlayout.addWidget(self.newProfileNameEdit)
    
    self.newProfileNameEdit.textChanged.connect(self.checkTextCompletion)
    
    vlayout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    hlayout.addWidget(QtGui.QLabel('Parent Camera Profile:'))
    
    self.parentProfiles = QtGui.QComboBox()
    self.parentProfiles.addItems(self.profileNames)
    self.parentProfiles.setCurrentIndex(index)
    
    self.parentProfiles.currentIndexChanged.connect(self.updatePreviousConfiguration)
    
    hlayout.addWidget(self.parentProfiles)
    vlayout.addLayout(hlayout)
    
    self.newProfileName.setLayout(vlayout)
    
    vglayout.addWidget(self.newProfileName)
    
    self.settings = QtGui.QGroupBox()
    self.vlayout.addWidget(self.settings)
    
    self.settings.setTitle('Settings')
    
    vglayout = QtGui.QVBoxLayout()
    self.settings.setLayout(vglayout)
    
    self.saveToHW = QtGui.QCheckBox('Save also to DepthCamera Hardware')
    
    if not self.depthCamera.configFile.hasHardwareConfigurationSupport():
      self.saveToHW.setDisabled(True)
    
    self.setAsDefault = QtGui.QCheckBox('Set as Default Profile')
    
    self.saveToHW.setChecked(self.calibrationWizard.saveToHW)
    self.setAsDefault.setChecked(self.calibrationWizard.setAsDefault)
    
    self.saveToHW.toggled.connect(self.changeSaveToHW)
    self.setAsDefault.toggled.connect(self.changeSetAsDefault)
    
    vglayout.addWidget(self.saveToHW)
    vglayout.addWidget(self.setAsDefault)
    
    self.profiles.setCurrentIndex(editIndex)
    
  def checkTextCompletion(self, text):
    self.completeChanged.emit()
    
  def changeSaveToHW(self, checked):
    self.calibrationWizard.saveToHW = checked      
  
  def changeSetAsDefault(self, checked):
    self.calibrationWizard.setAsDefault = checked
  
  def showHideNewProfileName(self, index):
    if index == 0:
      self.newProfileName.show()
      self.updatePreviousConfiguration(self.parentProfiles.currentIndex())
      self.updateSelections()
    else:
      self.newProfileName.hide()
      self.calibrationWizard.setPreviousConfiguration(self.depthCamera.getCurrentCameraProfileID())
      self.updateSelections()
    self.completeChanged.emit()
    
  def updatePreviousConfiguration(self, index):
    self.calibrationWizard.setPreviousConfiguration(self.profileIDs[index])
    
  def updateSelections(self):
    i = 0
    for p in self.calibrationWizard.pages:
      print p.title(), p.needsCalibration()
      self.profileSelections[i].setChecked(p.needsCalibration())
      i += 1
  
  def doShowStateChange(self, page, state):
    page.doShow = (state != QtCore.Qt.Unchecked)
    
    for n, p in enumerate(self.calibrationWizard.pageMap):
      if p == page:
        self.calibrationWizard.doShowMap[n] = p.doShow
    
  def isComplete(self):
    if self.profiles.currentIndex() == 0:
      return len(str(self.newProfileNameEdit.text())) > 0
    else:
      return True
  
  def validatePage(self):
    
    createNew = False
    
    if self.profiles.currentIndex() == 0: # Create new configuration
      createNew = True
      profileName = str(self.newProfileNameEdit.text())
      
      parentProfileID = self.profileIDs[self.parentProfiles.currentIndex()]
        
      if profileName in self.profileNames:
        r = QtGui.QMessageBox.question(self.calibrationWizard, 'Profile Name Present', \
          'A profile with name "' + profileName + '" already exists. Would you like to edit that' + \
          ' instead?', buttons = QtGui.QMessageBox.Ok | QtGui.QMessageBox.Cancel)
        
        if r == QtGui.QMessageBox.Cancel:
          return False
        else:
          createNew = False
    else:
      parentProfileID = self.profileIDs[self.profiles.currentIndex() - 1]
          
    if createNew: # Create new configuration
      
      id = self.depthCamera.addCameraProfile(profileName, parentProfileID)
      
      if id < 0:
        QtGui.QMessageBox.critical('Failed to create a new profile "' + profileName + '". See logs for more details.')
        return False
      
      self.calibrationWizard.currentProfileID = id
      self.calibrationWizard.currentConfiguration = self.depthCamera.configFile.getCameraProfile(id)
      self.calibrationWizard.currentProfileName = profileName
      
      self.calibrationWizard.previousConfiguration = self.depthCamera.configFile.getCameraProfile(parentProfileID)
      self.calibrationWizard.previousProfileID = parentProfileID
    else:
      c = self.depthCamera.configFile.getCameraProfile(parentProfileID)
      
      if not c:
        QtGui.QMessageBox.critical(self.calibrationWizard, 'Calibration Initialization', 'Failed to get camera profile "' + self.profileNames[self.profiles.currentIndex() - 1] + '"') 
        return False
      
      self.calibrationWizard.setPreviousConfiguration(parentProfileID)
      self.calibrationWizard.currentConfiguration = c
      self.calibrationWizard.currentProfileName = self.profileNames[self.profiles.currentIndex() - 1]
      self.calibrationWizard.currentProfileID = self.depthCamera.getCurrentCameraProfileID()
      
      
    for p in self.calibrationWizard.pages:
      p.writeDefiningParams()
      
    self.depthCamera.setCameraProfile(self.calibrationWizard.currentProfileID)
    self.calibrationWizard.isNewProfile = createNew
    
    return True
    
      