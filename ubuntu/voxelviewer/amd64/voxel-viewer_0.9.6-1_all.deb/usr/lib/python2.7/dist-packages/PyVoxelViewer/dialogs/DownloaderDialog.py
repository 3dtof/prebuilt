#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.common.Logger import Logger

import Voxel

from threading import Thread


class DownloadMessager(QtCore.QObject):
  setProgress = QtCore.Signal(object)
  gotLogMessage = QtCore.Signal(str)
  disableActionsSignal = QtCore.Signal()
  enableActionsSignal = QtCore.Signal()
  
  def __init__(self, parent = None):
    super(DownloadMessager, self).__init__(parent)

class DownloaderDialog(QtGui.QDialog):
  
  def __init__(self, cameraSystem, parent = None):
    super(DownloaderDialog, self).__init__(parent)
    
    self.setWindowTitle('File Programmer')
    
    self.setMinimumWidth(500)

    self.cameraSystem = cameraSystem

    layout = QtGui.QVBoxLayout(self)

    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Devices:'))
    self.devicesComboBox = QtGui.QComboBox()
    self.devicesComboBox.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
    hlayout.addWidget(self.devicesComboBox)
    self.refreshButton = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_BrowserReload), '')
    self.refreshButton.clicked.connect(self.populateList)
    hlayout.addWidget(self.refreshButton)
    layout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('File:'))
    self.fileName = QtGui.QLineEdit()
    self.fileName.returnPressed.connect(self.performDownload)
    hlayout.addWidget(self.fileName)
    self.browseButton = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_DirOpenIcon), '')
    self.browseButton.clicked.connect(self.browseFile)
    hlayout.addWidget(self.browseButton)
    
    layout.addLayout(hlayout)
    
    self.progress = QtGui.QProgressBar()
    
    layout.addWidget(self.progress)
    
    self.progress.setValue(0)
    
    self.logBox = QtGui.QTextBrowser()
    
    self.logBox.setReadOnly(True)
    
    layout.addWidget(self.logBox)
    
    # OK and Cancel buttons
    buttons = QtGui.QDialogButtonBox(self)
    
    self.downloadButton = QtGui.QPushButton("&Download", self)
    
    self.cancelButton = QtGui.QPushButton("&Close", self)
    
    self.downloadButton.clicked.connect(self.performDownload)
    
    buttons.addButton(self.downloadButton, QtGui.QDialogButtonBox.ActionRole)
    buttons.addButton(self.cancelButton, QtGui.QDialogButtonBox.RejectRole)
    
    self.setWindowFlags(QtCore.Qt.Dialog | QtCore.Qt.CustomizeWindowHint | QtCore.Qt.WindowTitleHint)
    
    buttons.rejected.connect(self.reject)
    layout.addWidget(buttons)
    
    self.downloadButton.setDisabled(True)
    self.isDownloading = False
    
    self.populateList()
    
    self.thread = None
    
    self.qthread = QtCore.QThread()
    self.qthread.start()
    
    self.downloadMessager = DownloadMessager()
    
    self.downloadMessager.setProgress.connect(self.updateProgress, QtCore.Qt.QueuedConnection)
    self.downloadMessager.gotLogMessage.connect(self.updateLogBox, QtCore.Qt.QueuedConnection)
    self.downloadMessager.disableActionsSignal.connect(self.disableActions, QtCore.Qt.QueuedConnection)
    self.downloadMessager.enableActionsSignal.connect(self.enableActions, QtCore.Qt.QueuedConnection)
    
    self.downloadMessager.moveToThread(self.qthread)
    
  @QtCore.Slot(object)
  def updateProgress(self, p):
    self.progress.setValue(p)
    
  def gotProgress(self, p):
    self.downloadMessager.setProgress.emit(p)
    
  def keyPressEvent(self, ev):
    if ev.key() == QtCore.Qt.Key_Escape and self.isDownloading:
      ev.accept()
    else:
      super(DownloaderDialog, self).keyPressEvent(ev)

  @QtCore.Slot()
  def performDownload(self):
    self.progress.setValue(0)
    d = self.cameraSystem.getDownloader(self.devices[self.devicesComboBox.currentIndex()])
    
    if not d:
      Logger.writeLog(Voxel.LOG_ERROR, 'Could not get the downloader for selected device\n')
      return
    
    d.setLogCallback(self.getLogText)
    d.setProgressFunction(self.gotProgress)
    
    self.thread = Thread(target = self.downloadThread, args = (d,))
    self.thread.start()
    
  def downloadThread(self, d):
    self.downloadMessager.disableActionsSignal.emit()
    self.isDownloading = True
    if not d.download(str(self.fileName.text())):
      self.downloadMessager.gotLogMessage.emit('\nFailed to download file "' + str(self.fileName.text()) + '"\n')
      
    d.removeLogCallback()
    d.removeProgressFunction()
    del d
    self.isDownloading = False
    self.downloadMessager.enableActionsSignal.emit()
  
  def getLogText(self, text):
    self.downloadMessager.gotLogMessage.emit(text)
  
  @QtCore.Slot()
  def updateLogBox(self, text):
    self.logBox.moveCursor(QtGui.QTextCursor.End)
    self.logBox.insertPlainText(text)
  
  @QtCore.Slot()
  def disableActions(self):
    self.downloadButton.setDisabled(True)
    self.cancelButton.setDisabled(True)
    self.refreshButton.setDisabled(True)
    self.browseButton.setDisabled(True)
    
  @QtCore.Slot()
  def enableActions(self):
    self.downloadButton.setEnabled(True)
    self.cancelButton.setEnabled(True)
    self.refreshButton.setEnabled(True)
    self.browseButton.setEnabled(True)
  
  @QtCore.Slot()
  def populateList(self):
    self.devices = self.cameraSystem.getProgrammableDevices()
    
    names = []
    for d in self.devices:
      names.append(d.description() + " (" + d.id() + ")") ## Assuming that description is present for all devices
    
    self.devicesComboBox.clear()
    
    if len(names) > 0:
      self.devicesComboBox.addItems(names)
      self.devicesComboBox.setCurrentIndex(0)
      
      if len(str(self.fileName.text())) > 0:
        self.downloadButton.setEnabled(True)
    else:
      self.downloadButton.setDisabled(True)
    
  @QtCore.Slot()
  def browseFile(self):
    filename, _ = QtGui.QFileDialog.getOpenFileName(self, 'Firmware file', filter = "Firmware files (*.tie *.tip)")
    
    if filename:
      self.fileName.setText(filename)
      
      if self.devicesComboBox.count() > 0:
        self.downloadButton.setEnabled(True)
    else:
      self.downloadButton.setDisabled(True)
      
      
  def __del__(self):
    if self.thread is not None:
      self.thread.join()
    
    self.qthread.exit()
    self.qthread.wait()

  # static method to create the dialog and return (date, time, accepted)
  @staticmethod
  def showDialog(cameraSystem, parent = None):
    dialog = DownloaderDialog(cameraSystem, parent)
    result = dialog.exec_()
    
    del dialog
    
    return None