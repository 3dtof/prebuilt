#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

class DetailedMessageDialog(QtGui.QDialog):
  def __init__(self, title, message, parent = None):
    super(DetailedMessageDialog, self).__init__(parent)

    layout = QtGui.QVBoxLayout(self)
    
    self.setWindowTitle(title)

    self.messageBox = QtGui.QTextBrowser()
    self.messageBox.setText(message)
    layout.addWidget(self.messageBox)

    # OK and Cancel buttons
    buttons = QtGui.QDialogButtonBox(self)
    
    self.okButton = QtGui.QPushButton("&Ok", self)\
    
    buttons.addButton(self.okButton, QtGui.QDialogButtonBox.AcceptRole)
    
    buttons.accepted.connect(self.accept)
    layout.addWidget(buttons)
    
  # static method to create the dialog and return (date, time, accepted)
  @staticmethod
  def showDialog(title, message, parent = None):
    dialog = DetailedMessageDialog(title, message, parent)
    result = dialog.exec_()
    
    return None