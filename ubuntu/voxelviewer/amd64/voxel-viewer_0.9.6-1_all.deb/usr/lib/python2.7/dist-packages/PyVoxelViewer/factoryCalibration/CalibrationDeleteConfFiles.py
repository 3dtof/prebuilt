#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

import Voxel
import os

class CalibrationDeteteConfFiles(QtGui.QWizardPage):
  
  def __init__(self, calibrationWizard, parent = None):
    super(CalibrationDeteteConfFiles, self).__init__(parent)
    self.calibrationWizard = calibrationWizard
    
    
    #TODO Define the steps to write self.calibrationWizard.currentConfigurations (list of current configurations to write to hardware)
    self.setTitle('Erase Conf Files')
    self.setSubTitle('Click Button to delete the conf files')
    
    self.vlayout = QtGui.QVBoxLayout(self)
    self.label = QtGui.QLabel('')
    self.label.setWordWrap(True)
    self.vlayout.addWidget(self.label)
    
    hlayout = QtGui.QHBoxLayout()
    hlayout.addStretch()
    self.button = QtGui.QPushButton('Delete Conf Files')
    self.button.pressed.connect(self.deleteConfFiles)
    hlayout.addWidget(self.button)
    hlayout.addStretch()
    
    self.vlayout.addLayout(hlayout)
    
  def enterPage(self):
    pass
    
  @QtCore.Slot()
  def deleteConfFiles(self):
      c = Voxel.Configuration()
      r, self.confPath = c.getLocalPath('conf')
      if not r:
          self.label.setText('Cannot find the path to conf files. \nPlease check if the conf files are saved.')
      else:
          for file in os.listdir(self.confPath):
              fullFileName = os.path.join(self.confPath, file)
              if (os.path.isfile(fullFileName)):
                    os.remove(fullFileName)
          self.button.setEnabled(False)
          self.label.setText('Successfully deleted the conf files')       
             
              
      
    
    