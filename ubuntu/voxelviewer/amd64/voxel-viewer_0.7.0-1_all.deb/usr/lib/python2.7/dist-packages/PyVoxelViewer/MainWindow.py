#
# TI Voxel Viewer component.
#
# Copyright (c) 2015 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.docks.CameraDockWidget import CameraDockWidget
from PyVoxelViewer.docks.DataDiagramDockWidget import DataDiagramDockWidget
from PyVoxelViewer.docks.LogDockWidget import LogDockWidget
from PyVoxelViewer.docks.ParameterDockWidget import ParameterDockWidget
from PyVoxelViewer.docks.WatchListDockWidget import WatchListDockWidget
from PyVoxelViewer.docks.FrequentlyUsedParametersDockWidget import FrequentlyUsedParametersDockWidget

from PyVoxelViewer.dialogs.SelectDepthCameraDialog import SelectDepthCameraDialog
from PyVoxelViewer.dialogs.DownloaderDialog import DownloaderDialog
from PyVoxelViewer.dialogs.ExportRawStreamDialog import ExportRawStreamDialog
from PyVoxelViewer.dialogs.AboutDialog import AboutDialog
from PyVoxelViewer.dialogs.SplashDialog import SplashDialog
from PyVoxelViewer.dialogs.SDKSelectorDialog import SDKSelectorDialog
from PyVoxelViewer.common.SDKSelector import SDKSelector

from PyVoxelViewer.views.StatusBar import StatusBar

from PyVoxelViewer.views.SourceToolbar import SourceToolbar

from PyVoxelViewer.views.DataViewContainer import DataViewContainer

from PyVoxelViewer.views.SettingsMenu import SettingsMenu
from PyVoxelViewer.views.ProfilesMenu import ProfilesMenu

from PyVoxelViewer.common.Logger import Logger

from PyVoxelViewer.models.DepthCameraStreamController import *
from PyVoxelViewer.models.DataEngine import *

from PyVoxelViewer.common.about import *

import Voxel

class MainWindow(QtGui.QMainWindow):
  
  def __init__(self, cameraSystem):
    super(MainWindow, self).__init__()
    self.baseWindowTitle = "Voxel Viewer (v" + VERSION_NUMBER + ")"
    self.setWindowTitle(self.baseWindowTitle)
    icon = QtGui.QIcon(':/voxelevm.png')
    self.setWindowIcon(icon)
    
    self.showMaximized()
    
    self.setMinimumWidth(1024)
    self.setMinimumHeight(700)
    
    self.cameraSystem = cameraSystem
    
    self.depthCameraStreamController = DepthCameraStreamController(self.cameraSystem)
    self.depthCameraStreamController.sourceSelected.connect(self.updateDockViews)
    self.depthCameraStreamController.sourceListChanged.connect(self.updateDockViews)
    self.dataEngine = DataEngine(self.depthCameraStreamController)
    
    self.setDockOptions(QtGui.QMainWindow.AllowTabbedDocks | QtGui.QMainWindow.VerticalTabs)
    
    try:
      self.viewer3 = DataViewContainer(self.dataEngine, 'pointcloud')
    except Exception as exceptInst:
      print(exceptInst)
      self.viewer3 = DataViewContainer(self.dataEngine, 'phase')
    self.setCentralWidget(self.viewer3)

    self.cameraDockWidget = CameraDockWidget(self.dataEngine)
    self.cameraDockWidget.setDepthCameraStreamController(self.depthCameraStreamController)
    self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self.cameraDockWidget)
    
    self.frequentlyUsedParametersDockWidget = FrequentlyUsedParametersDockWidget(self, self.depthCameraStreamController)
    self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.frequentlyUsedParametersDockWidget)
    
    self.parameterDockWidget = ParameterDockWidget(self, self.depthCameraStreamController)
    self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.parameterDockWidget)
    
    self.tabifyDockWidget(self.frequentlyUsedParametersDockWidget, self.parameterDockWidget)
    
    self.watchListDockWidget = WatchListDockWidget(self.dataEngine)
    self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.watchListDockWidget)
    
    self.dataDiagramDockWidget = DataDiagramDockWidget(self.cameraSystem, self.depthCameraStreamController)
    self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.dataDiagramDockWidget)
    
    self.logDockWidget = LogDockWidget(self)
    self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.logDockWidget)
    
    self.tabifyDockWidget(self.watchListDockWidget, self.dataDiagramDockWidget)
    self.tabifyDockWidget(self.dataDiagramDockWidget, self.logDockWidget)
    
    self.initToolbar()
    
    self.initStatusBar()
    
    self.initMenu()
    
    self.statusMessage.setProfilesMenu(self.profilesMenu)
    self.cameraDockWidget.setStatusBar(self.statusMessage)
    self.viewer3.setStatusBar(self.statusMessage)
    
    self.selectDepthCamera()
    
    self.parameterDockWidget.paramValueSet.connect(self.statusMessage.checkCalibration)
    self.frequentlyUsedParametersDockWidget.paramValueSet.connect(self.statusMessage.checkCalibration)
    
    self.parameterDockWidget.paramValueSet.connect(self.frequentlyUsedParametersDockWidget.initParams)
    self.frequentlyUsedParametersDockWidget.paramValueSet.connect(self.parameterDockWidget.initParams)
    
  def setDepthCamera(self, depthCamera):
    
    if depthCamera:
      self.depthCameraStreamController.setDepthCamera(depthCamera)
      self.depthCameraStreamController.start()
    
    
  def selectDepthCamera(self):
    devices = self.cameraSystem.scan()
    
    if len(devices) == 1:
      self.setDepthCamera(self.cameraSystem.connect(devices[0]))
    else:
      if SplashDialog.dialog != None:
        SplashDialog.dialog.timer.timeout.connect(self.showSelectDepthCameraDialog)
      else:
        self.showSelectDepthCameraDialog()
      
  @QtCore.Slot()
  def showSelectDepthCameraDialog(self):
    self.setDepthCamera(SelectDepthCameraDialog.showDialog(self.cameraSystem, parent=self))
    
  @QtCore.Slot()
  def showDownloaderDialog(self):
    self.disconnectDepthCamera()
    DownloaderDialog.showDialog(self.cameraSystem)
    self.selectDepthCamera()
    
  @QtCore.Slot()
  def showExportRawStreamDialog(self):
    self.disconnectDepthCamera()
    ExportRawStreamDialog.showDialog(self.cameraSystem)
    self.selectDepthCamera()
  
  def initMenu(self):
    exitAction = QtGui.QAction(QtGui.QIcon.fromTheme('exit'), 'E&xit', self)
    exitAction.setShortcut('Ctrl+Q')
    exitAction.setStatusTip('Exit application')
    exitAction.triggered.connect(self.close)
    
    cameraAction = QtGui.QAction(QtGui.QIcon.fromTheme('list'), '&Connect Depth Camera', self)
    cameraAction.setShortcut('Ctrl+C')
    cameraAction.setStatusTip('Select depth camera')
    cameraAction.triggered.connect(self.showSelectDepthCameraDialog)
    
    openFileAction = QtGui.QAction(QtGui.QIcon.fromTheme('open'), '&Open Saved Stream', self)
    openFileAction.setShortcut('Ctrl+O')
    openFileAction.triggered.connect(self.openSavedStreamDialog)
    
    exportRawFileAction = QtGui.QAction(QtGui.QIcon.fromTheme('export'), '&Export Raw Stream', self)
    exportRawFileAction.setShortcut('Ctrl+E')
    exportRawFileAction.triggered.connect(self.showExportRawStreamDialog)
    
    downloaderAction = QtGui.QAction(QtGui.QIcon.fromTheme('download'), 'EEPROM &Programmer', self)
    downloaderAction.setShortcut('Ctrl+P')
    downloaderAction.setStatusTip('Programmer/Downloader')
    downloaderAction.triggered.connect(self.showDownloaderDialog)

    sdkSelectAction = QtGui.QAction(QtGui.QIcon.fromTheme('select'), 'SDK Se&lection', self)
    sdkSelectAction.setShortcut('Ctrl+L')
    sdkSelectAction.setStatusTip('Choose Voxel SDK to use with the viewer')
    sdkSelectAction.triggered.connect(self.showSDKSelectorDialog)
    
    disconnectAction = QtGui.QAction(QtGui.QIcon.fromTheme('disconnect'), '&Disconnect Depth Camera', self)
    disconnectAction.setShortcut('Ctrl+D')
    disconnectAction.setStatusTip('Disconnect currect depth camera')
    disconnectAction.triggered.connect(self.disconnectDepthCamera)

    menubar = self.menuBar()
    fileMenu = menubar.addMenu('&File')
    fileMenu.addAction(cameraAction)
    fileMenu.addAction(disconnectAction)
    fileMenu.addSeparator()
    fileMenu.addAction(openFileAction)
    fileMenu.addAction(exportRawFileAction)
    fileMenu.addSeparator()
    fileMenu.addAction(downloaderAction)
    fileMenu.addSeparator()
    fileMenu.addAction(sdkSelectAction)
    fileMenu.addSeparator()
    fileMenu.addAction(exitAction)
    
    self.profilesMenu = ProfilesMenu(self)
    menubar.addMenu(self.profilesMenu)
    
    self.settingsMenu = SettingsMenu(self, self.dataEngine)
    menubar.addMenu(self.settingsMenu)
    
    docks = self.createPopupMenu()
    docks.setTitle('&Windows')
    menubar.addMenu(docks)

    helpAction = QtGui.QAction(QtGui.QIcon.fromTheme('help'), '&Help', self)
    helpAction.setShortcut('Ctrl+H')
    helpAction.setStatusTip('Help about Voxel Viewer')
    helpAction.setEnabled(False)
    
    aboutAction = QtGui.QAction(QtGui.QIcon.fromTheme('about'), '&About', self)
    aboutAction.setShortcut('Ctrl+B')
    aboutAction.triggered.connect(self.showAboutDialog)
    aboutAction.setStatusTip('About Voxel Viewer')

    helpMenu = menubar.addMenu('&Help')
    helpMenu.addAction(helpAction)
    helpMenu.addAction(aboutAction)
    
  def openSavedStreamDialog(self):
    filename, _ = QtGui.QFileDialog.getOpenFileName(self, 'Open Frame Stream', filter = "Voxel files (*.vxl)")
    
    if filename:
      i = self.depthCameraStreamController.addFileStreamSource(filename)
      self.depthCameraStreamController.setCurrentSource(i)
      self.depthCameraStreamController.start()
      
  def showAboutDialog(self):
    AboutDialog.showDialog(parent=self)
    
  def initToolbar(self):
    playback = self.addToolBar("Source tool bar")
    self.sourceToolbar = SourceToolbar(self.depthCameraStreamController, self.dataEngine, self, playback)

  def initStatusBar(self):
    self.statusMessage = StatusBar(self.dataEngine)
    self.statusMessage.setAddTextFunction(self.getTemperatureStatus, 60)
    self.statusBar().addPermanentWidget(self.statusMessage, 1)
    self.statusBar().setSizeGripEnabled(False)
    
    
  def getTemperatureStatus(self):
    # d = self.depthCameraStreamController.getDepthCamera()
    # TODO Identify temperature parameters for each type of depth camera
    return None
    
  def closeEvent(self, event):
    self.depthCameraStreamController.stop()
    self.dataEngine.stop()
    self.logDockWidget.stop()
    event.accept()
    
  @QtCore.Slot()
  def disconnectDepthCamera(self):
    self.depthCameraStreamController.disconnectDepthCamera()

  def showSDKSelectorDialog(self):
    SDKSelectorDialog.interactiveGetVoxelSDK(None)
    
  def updateDeviceConnectStatus(self, connected):
    self.statusMessage.setConnected(connected)
    
  @QtCore.Slot()
  def updateDockViews(self):
    s = self.depthCameraStreamController.getCurrentSource()
    
    if s != None and s.isLiveStream():
      self.frequentlyUsedParametersDockWidget.setVisible(True)
      self.parameterDockWidget.setVisible(True)
      self.dataDiagramDockWidget.setVisible(True)
      self.updateDeviceConnectStatus(True)
    else:
      self.updateDeviceConnectStatus(False)
      self.parameterDockWidget.setVisible(False)
      self.frequentlyUsedParametersDockWidget.setVisible(False)
      self.dataDiagramDockWidget.setVisible(False)
      
