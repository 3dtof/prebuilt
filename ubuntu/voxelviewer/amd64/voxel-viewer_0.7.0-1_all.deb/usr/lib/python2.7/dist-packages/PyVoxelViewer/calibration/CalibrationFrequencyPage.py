#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from CalibrationWizard import CalibrationPage

class CalibrationFrequencyPage(CalibrationPage):
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationFrequencyPage, self).__init__(calibrationWizard, index, parent = parent, 
          definingParams = definingParams, calibParams = calibParams)
          
    self.calibrationWizard = calibrationWizard
    
    self.setTitle('Modulation Frequency Calibration')
    self.setSubTitle('Modulation frequency related measurements are to be entered below.')
    
    self.vlayout = QtGui.QVBoxLayout(self)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Measured Modulation Frequency: '))
    self.measuredFrequency = QtGui.QDoubleSpinBox()
    self.measuredFrequency.setRange(1, 100)
    self.measuredFrequency.setSingleStep(0.001)
    self.measuredFrequency.setDecimals(3)
    self.measuredFrequency.valueChanged.connect(self.setMeasuredFrequency)
    hlayout.addWidget(self.measuredFrequency)
    hlayout.addWidget(QtGui.QLabel('MHz'))
    
    self.vlayout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Expected Modulation Frequency: '))
    self.expectedFrequency = QtGui.QDoubleSpinBox()
    self.expectedFrequency.setRange(1, 100)
    self.expectedFrequency.setSingleStep(0.001)
    self.expectedFrequency.setDecimals(3)
    self.expectedFrequency.valueChanged.connect(self.setExpectedFrequency)
    hlayout.addWidget(self.expectedFrequency)
    hlayout.addWidget(QtGui.QLabel('MHz'))
    
    self.vlayout.addLayout(hlayout)
    
    self.ratioText = QtGui.QLabel()
    
    self.vlayout.addWidget(self.ratioText)
    
    self.mFrequency = 0
    self.eFrequency = 0
    self.ratio = 0
    
  def initializePage(self):
    if self.isPresentInPrevious():
      self.copyCalibrationFromPrevious()
      
      if self.calibParams.has_key('freq_corr_at') > 0:
        self.expectedFrequency.setValue(float(self.calibParams['freq_corr_at']))
      self.measuredFrequency.setValue(float(self.calibParams['freq_corr'])*float(self.calibParams['freq_corr_at']))
      
    super(CalibrationFrequencyPage, self).initializePage()

    
  @QtCore.Slot(float)
  def setMeasuredFrequency(self, f):
    self.mFrequency = f
    self.setRatio()
    
  @QtCore.Slot(float)
  def setExpectedFrequency(self, f):
    self.eFrequency = f
    self.setRatio()
    
  def setRatio(self):
    if self.mFrequency == 0 or self.eFrequency == 0:
      return
    
    print self.mFrequency, self.eFrequency
    
    self.ratio = self.mFrequency/self.eFrequency
    self.ratioText.setText('Frequency scaling Factor = %.3f'%self.ratio)
    self.calibParams['freq_corr_at'] = self.eFrequency
    self.calibParams['freq_corr'] = self.ratio
    
    self.completeChanged.emit()
    
  def isComplete(self):
    return self.eFrequency != 0 and self.mFrequency != 0 and self.ratio > 0.9 and self.ratio < 1.1
  