#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

import Voxel

from PyVoxelViewer.views.ParameterHandler import ParameterHandler

from PyVoxelViewer.calibration.CalibrationWizard import CalibrationWizard

class ProfileItemDelegateWithoutBorder(QtGui.QStyledItemDelegate):
  def __init__(self, parent = None):
    super(ProfileItemDelegateWithoutBorder, self).__init__(parent)
    self.parent = parent
  
  def paint(self, painter, option, index):
    if self.parent.locations[index.row()] == Voxel.ConfigurationFile.IN_CAMERA:
      painter.fillRect(option.rect, QtGui.QColor("#FFEEEE"))
    else:
      painter.fillRect(option.rect, QtGui.QColor("#EEFFEE"))
    super(ProfileItemDelegateWithoutBorder, self).paint(painter, option, index)


class ProfileItemDelegateWithBorder(ProfileItemDelegateWithoutBorder):
  def __init__(self, parent = None):
    super(ProfileItemDelegateWithBorder, self).__init__(parent)
  
  def paint(self, painter, option, index):
    super(ProfileItemDelegateWithBorder, self).paint(painter, option, index)
      
    painter.setPen(QtGui.QPen(QtGui.QColor("#BBBBBB"), 4))
    painter.drawLine(option.rect.topLeft(), option.rect.topRight())

class ProfilesManagerDialog(QtGui.QDialog):
  def __init__(self, cameraSystem, depthCamera, parent = None):
    super(ProfilesManagerDialog, self).__init__(parent)
    
    self.cameraSystem = cameraSystem
    self.depthCamera = depthCamera
    
    self.setWindowTitle('Manage Profiles')
    
    self.setMinimumWidth(900)
    self.setMinimumHeight(500)
    
    layout = QtGui.QVBoxLayout(self)

    # nice widget for editing the date
    self.tableWidget = QtGui.QTableWidget()
    self.tableWidget.setColumnCount(7)
    self.tableWidget.setHorizontalHeaderLabels(["ID", "Parent", "Name", "Default", "Location", "Defining Parameters", "Calibrations"])
    self.tableWidget.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
    self.tableWidget.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
    self.tableWidget.setStyleSheet("QTableWidget::item { padding: 10px }");
    self.tableWidget.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
    self.tableWidget.verticalHeader().setVisible(False)
    
    self.tableWidget.currentItemChanged.connect(self.rowChanged)
    
    layout.addWidget(self.tableWidget)

    # OK and Cancel buttons
    buttons = QtGui.QDialogButtonBox(self)
    
    self.addButton = QtGui.QPushButton("&Add", self)
    self.removeButton = QtGui.QPushButton("&Remove", self)
    self.editButton = QtGui.QPushButton("&Edit", self)
    
    self.copyButton = QtGui.QPushButton("&Copy to Camera", self)
    
    self.addButton.clicked.connect(self.addCameraProfile)
    self.removeButton.clicked.connect(self.removeCameraProfile)
    self.editButton.clicked.connect(self.editCameraProfile)
    self.copyButton.clicked.connect(self.copyProfileToDevice)
    
    buttons.addButton(self.addButton, QtGui.QDialogButtonBox.ActionRole)
    buttons.addButton(self.removeButton, QtGui.QDialogButtonBox.ActionRole)
    buttons.addButton(self.editButton, QtGui.QDialogButtonBox.ActionRole)
    buttons.addButton(self.copyButton, QtGui.QDialogButtonBox.ActionRole)
    
    layout.addWidget(buttons)
    
    self.populateTable()
    
  @QtCore.Slot(object, object)
  def rowChanged(self, current, previous):
    r = self.tableWidget.currentRow()
    if r < len(self.locations):
      if self.locations[r] == Voxel.ConfigurationFile.IN_HOST:
        self.copyButton.setEnabled(True)
      else:
        self.copyButton.setDisabled(True)
        

  @QtCore.Slot()
  def populateTable(self):
    
    self.tableWidget.clearContents()
    
    while self.tableWidget.rowCount() > 0:
      self.tableWidget.removeRow(0)
    
    calibrationWizard = CalibrationWizard(self.cameraSystem, self.depthCamera)
    
    names = self.depthCamera.getCameraProfileNames()
    
    self.ns = []
    self.locations = []
    
    row = 0
    
    self.inCameraButtonGroup = QtGui.QButtonGroup(self.tableWidget)
    self.inCameraButtonGroup.setExclusive(True)
    self.inHostButtonGroup = QtGui.QButtonGroup(self.tableWidget)
    self.inHostButtonGroup.setExclusive(True)
    
    self.inCameraButtonGroup.buttonClicked[int].connect(self.changeDefaultProfile)
    self.inHostButtonGroup.buttonClicked[int].connect(self.changeDefaultProfile)
    
    self.ids = sorted(names, key = lambda x: (self.depthCamera.configFile.getCameraProfile(x).getLocation() << 16) + x, reverse = True)
    
    previousLocation = -1
    
    for id in self.ids:
      profile = self.depthCamera.configFile.getCameraProfile(id)
      
      if not profile:
        print 'Unable to get profile for ID = %d'%(id)
        
      self.tableWidget.insertRow(self.tableWidget.rowCount())
      self.tableWidget.setItem(row, 0, QtGui.QTableWidgetItem(str(profile.getID())))
      self.tableWidget.setItem(row, 1, QtGui.QTableWidgetItem(str(profile.getParentID())))
      self.tableWidget.setItem(row, 2, QtGui.QTableWidgetItem(str(profile.getProfileName())))
      
      q = QtGui.QCheckBox(self.tableWidget)
      
      if profile.getLocation() == Voxel.ConfigurationFile.IN_CAMERA:
        self.inCameraButtonGroup.addButton(q)
        self.inCameraButtonGroup.setId(q, id)
        if self.depthCamera.configFile.getDefaultCameraProfileIDInCamera() == id:
          q.setChecked(True)
        
        self.tableWidget.setItem(row, 4, QtGui.QTableWidgetItem(str("In Camera")))
      else:
        self.inHostButtonGroup.addButton(q)
        self.inHostButtonGroup.setId(q, id)
        if self.depthCamera.configFile.getDefaultCameraProfileIDInHost() == id:
          q.setChecked(True)
        
        self.tableWidget.setItem(row, 4, QtGui.QTableWidgetItem(str("In Host")))
          
      self.tableWidget.setCellWidget(row, 3, q)
      
      r, c = profile.getConfigSet('defining_params')
      
      s = ""
      
      if r and c:
        params = sorted(c.params.items(), key = lambda x: x[0])
        for p, v in params:
          if p == 'frame_rate':
            if len(s) > 0:
              s += "\n"
            s += "Frame rate: " + str(v) + "fps"
          else:
            param = ParameterHandler.getParameterHandler(self.depthCamera, p)
          
            if not param:
              continue
          
            if len(s) > 0:
              s += "\n"
            try:
              s = s + (param.getName() + ": " + param.getDisplayValue(float(v)))
            except ValueError, e:
              s = s + (param.getName() + ": " + param.getDisplayValue(v))
        
      self.tableWidget.setItem(row, 5, QtGui.QTableWidgetItem(s))
      
      calibrationWizard.previousConfiguration = profile
      
      s = ""
      
      for p in calibrationWizard.pages:
        if len(s) > 0:
          s += "\n"
        s += p.title() + ":"
        if p.isPresentInPrevious():
          s += "yes"
        else:
          s += "no"
        
      self.tableWidget.setItem(row, 6, QtGui.QTableWidgetItem(s))
      
      self.locations.append(profile.getLocation())
      self.ns.append(names[id])
      
      if previousLocation != profile.getLocation() and row > 0:
        self.tableWidget.setItemDelegateForRow(row, ProfileItemDelegateWithBorder(self))
      else:
        self.tableWidget.setItemDelegateForRow(row, ProfileItemDelegateWithoutBorder(self))
      
      previousLocation = profile.getLocation()
      row += 1
    
    self.tableWidget.setCurrentCell(0, 0)
    self.tableWidget.resizeColumnsToContents()
    self.tableWidget.resizeRowsToContents()
    
    calibrationWizard.closePages()
      
  def removeCameraProfile(self):
    index = self.tableWidget.currentIndex().row()
    
    if index < len(self.ids):
      q = QtGui.QMessageBox.question(self, 'Remove Camera Profile', 'Remove camera profile "' + self.ns[index] + '"?',\
        buttons = QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
      
      if q == QtGui.QMessageBox.Yes:
        id = self.ids[index]
        
        if not self.depthCamera.removeCameraProfile(id):
          QtGui.QMessageBox.critical(self, 'Remove Camera Profile', 'Failed to remove camera profile with id = ' + str(id))
          return
        
        del self.ids[index]
        del self.ns[index]
        self.populateTable()
  
  @QtCore.Slot(int)
  def changeDefaultProfile(self, id):
    if not self.depthCamera.configFile.setDefaultCameraProfile(id):
      QtGui.QMessageBox.critical(self, 'Set Default Profile', 'Failed to set "id = %d" as default profile'%id)
      self.populateTable()
        
  def addCameraProfile(self):
    calibrationWizard = CalibrationWizard(self.cameraSystem, self.depthCamera)
    
    if not calibrationWizard.isReady():
      return
    
    calibrationWizard.exec_()
    calibrationWizard.closePages()
    
    del calibrationWizard
    
    self.populateTable()
  
  def editCameraProfile(self):
    index = self.tableWidget.currentIndex().row()
    
    if index < len(self.ids):
      id = self.ids[index]
      calibrationWizard = CalibrationWizard(self.cameraSystem, self.depthCamera, editIndex = id)
      
      if not calibrationWizard.isReady():
        return
      
      calibrationWizard.exec_()
      calibrationWizard.closePages()
      
      del calibrationWizard
      
      self.populateTable()
  
  @QtCore.Slot()
  def copyProfileToDevice(self):
    index = self.tableWidget.currentIndex().row()
    
    if index < len(self.ids):
      self.copyButton.setText('Copying...')
      self.setDisabled(True)
      
      id = self.ids[index]
      r, newID = self.depthCamera.configFile.saveCameraProfileToHardware(id)
      
      self.copyButton.setText('&Copy to Camera')
      self.setEnabled(True)
      
      if not r:
        QtGui.QMessageBox.critical(self, 'Copy Profile to Hardware', 'Failed to copy profile with "id = %d" to hardware'%id)
      else:
        self.populateTable()

  # static method to create the dialog and return (date, time, accepted)
  @staticmethod
  def showDialog(cameraSystem, depthCamera, parent = None):
    dialog = ProfilesManagerDialog(cameraSystem, depthCamera, parent)
    dialog.exec_()