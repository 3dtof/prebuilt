#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

import Voxel

from PySide import QtGui, QtCore

import numbers

from XYSpinBox import XYSpinBox

from functools import partial

from ParameterHandler import WheelEventFilter

class VideoModeParameterView(QtGui.QWidget):
  
  valueChanged = QtCore.Signal()
  
  @staticmethod
  def getID():
    return "video_mode"
  
  def getTitle(self):
    return "Video Mode"
  
  def __init__(self, window, depthCameraController, parent = None, flags = 0):
    super(VideoModeParameterView, self).__init__(parent, flags)
    
    self.window = window
    self.depthCameraController = depthCameraController
    
    self.depthCameraController.started.connect(self.streamStarted)
    self.depthCameraController.stopped.connect(self.streamStopped)
    
    self.depthCameraController.onDepthCameraSet.connect(self.init)
    
    vlayout = QtGui.QVBoxLayout()
    
    hLayout = QtGui.QHBoxLayout()
    self.frameSizeLabel = QtGui.QLabel('Frame Size:')
    hLayout.addWidget(self.frameSizeLabel)
    
    self.frameSize = QtGui.QComboBox()
    self.frameSize.activated.connect(self.updateFrameSize)
    hLayout.addWidget(self.frameSize)
    
    self.currentSelection = -1
    
    vlayout.addLayout(hLayout)
    
    hlayout = QtGui.QHBoxLayout()
    self.rateSlider = QtGui.QSlider()
    self.rateSlider.setOrientation(QtCore.Qt.Horizontal)
    self.rateSlider.setMinimumWidth(100)
    self.rateSlider.setSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Preferred)
    self.rateSlider.valueChanged.connect(self.updateRateBox)
    hlayout.addWidget(self.rateSlider)
    self.rateBox = QtGui.QDoubleSpinBox()
    
    self.oldStepBy = self.rateBox.stepBy
    self.rateBox.stepBy = partial(self.stepBy, self.rateBox)
    
    self.rateBox.editingFinished.connect(self.rateBoxEditingFinished)
    hlayout.addWidget(self.rateBox)
    hlayout.addWidget(QtGui.QLabel('fps'))
    
    vlayout.addLayout(hlayout)
    
    self.frameSize.installEventFilter(WheelEventFilter(self))
    self.rateBox.installEventFilter(WheelEventFilter(self))
    self.rateSlider.installEventFilter(WheelEventFilter(self))
    
    self.message = QtGui.QWidget()
    
    hlayout = QtGui.QHBoxLayout()
    
    self.icon = QtGui.QLabel()
    
    self.textMessage = QtGui.QLabel()
    self.textMessage.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
    self.textMessage.font().setPointSize(6)
    
    hlayout.addWidget(self.icon)
    hlayout.addWidget(self.textMessage)
    
    self.message.setLayout(hlayout)
    
    self.message.hide()
    
    vlayout.addWidget(self.message)
    
    self.setLayout(vlayout)
    
    self.init()
    self.streamStopped()
    
    
  @QtCore.Slot()
  def streamStarted(self):
    s = self.depthCameraController.getCurrentSource()
    if s:
      if not s.isLiveStream():
        self.icon.setPixmap(self.window.style().standardIcon(QtGui.QStyle.SP_MessageBoxInformation).pixmap(24, 24))
        self.textMessage.setText('Frame size settings are not applicable for saved streams')
        self.message.show()  
      else:
        self.message.hide()
      
  @QtCore.Slot()
  def streamStopped(self):
    s = self.depthCameraController.getCurrentSource()
    if s:
      self.setEnabled(True)
      
      if s.isLiveStream():
        self.message.hide()
      else:
        self.icon.setPixmap(self.window.style().standardIcon(QtGui.QStyle.SP_MessageBoxInformation).pixmap(24, 24))
        self.textMessage.setText('Frame size settings are not applicable for saved streams')
        self.message.show()
      
  @QtCore.Slot()
  def init(self):
    self.engine = self.depthCameraController.getDepthCamera()
    
    if self.engine:
      r, self.videoModes = self.engine.getSupportedVideoModes()
      
      r1, f = self.engine.getFrameSize() 
        
      r2, rate = self.engine.getFrameRate()
      
      r3, bpp = self.engine.getBytesPerPixel()
      
      if not r or not r1 or not r2 or not r3:
        return
      
      if len(self.videoModes) > 0:
        self.frameSizeLabel.show()
        self.frameSize.show()
        self.frameSize.clear()
        
        selected = 0
        
        for i in range(0, len(self.videoModes)):
          v = self.videoModes[i]
          self.frameSize.addItem('%dx%d (%d bpp)'%(v.frameSize.width, v.frameSize.height, v.bytesPerPixel*8))
          
          if f.width == v.frameSize.width and f.height == v.frameSize.height and bpp == v.bytesPerPixel:
            selected = i
            
        self.currentSelection = selected
        self.frameSize.setCurrentIndex(selected)
        self.rateSlider.setValue(rate.getFrameRate())
        self.rateBox.setValue(rate.getFrameRate())
        
        self.setFrameRateRange(selected)
        
      else:
        
        maxRate = Voxel.FrameRate()
        r4 = self.engine.getMaximumFrameRate(maxRate, f)
        
        if not r4:
          return
      
        self.rateSlider.setValue(rate.getFrameRate())
        self.rateBox.setValue(rate.getFrameRate())
        self.setFrameRateRange(maxRate)
        
        self.frameSizeLabel.hide()
        self.frameSize.hide()
      
  def setFrameRateRange(self, r):
    if isinstance(r, Voxel.FrameRate):
      rate = r
    elif self.videoModes and len(self.videoModes) > r:
      rate = self.videoModes[r]
    
    self.rateSlider.setRange(5, rate.getFrameRate())
    self.rateBox.setRange(5, rate.getFrameRate())
            
  @QtCore.Slot(int)
  def updateRateBox(self, value):
    self.rateBox.setValue(value)
    self.updateFrameRate()
    
  def stepBy(self, spinbox, value):
    self.oldStepBy(value)
    self.rateBoxEditingFinished()

  @QtCore.Slot()
  def rateBoxEditingFinished(self):
    value = self.rateBox.value()
    self.rateSlider.setValue(int(value))
    self.updateFrameRate()

  def updateFrameRate(self):
    value = self.rateBox.value()
    
    if self.engine:
      r = Voxel.FrameRate()
      r.numerator = int(value)*10000;
      r.denominator = 10000;
    
      g = Voxel.gcd(r.numerator, r.denominator);
      r.numerator = r.numerator/g;
      r.denominator = r.denominator/g;
      ret = self.engine.setFrameRate(r)
      
      if not ret:
        QtGui.QMessageBox.critical(self, 'Video Mode', "Failed to set frame rate as %.2ffps."%value)
      else:
        self.valueChanged.emit()
      
  @QtCore.Slot(int)
  def updateFrameSize(self, index):
    if self.engine and self.videoModes and len(self.videoModes) > index and self.currentSelection != index:
      
      f = self.videoModes[index].frameSize
      
      s = self.depthCameraController.getCurrentSource()
      
      isRunning = False
      if s and s.isLiveStream() and s.isRunning():
        self.depthCameraController.stop()
        isRunning = True
      
      # NOTE: Set the bytes per pixel, before setting frame size
      r1 = self.engine.setBytesPerPixel(self.videoModes[index].bytesPerPixel)
      
      r = self.engine.setFrameSize(f)
      
      if not r or not r1:
        QtGui.QMessageBox.critical(self, 'Video Mode', "Failed to set frame size as %dx%d."%(f.width, f.height))
        self.frameSize.setCurrentIndex(self.currentSelection)
        return
      else:
        self.currentSelection = index
        self.valueChanged.emit()
        
      if isRunning:
        self.depthCameraController.start()
        
      self.setFrameRateRange(index)