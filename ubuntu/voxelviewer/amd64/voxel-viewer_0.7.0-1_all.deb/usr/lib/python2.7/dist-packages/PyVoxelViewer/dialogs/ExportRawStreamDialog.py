#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.models.DepthCameraStreamController import DepthCameraStreamController
from PyVoxelViewer.models.DataEngine import DataEngine

from PyVoxelViewer.common.Logger import Logger

import Voxel

import numpy as np

import time


class ExportRawStreamDialog(QtGui.QDialog):
  
  def __init__(self, cameraSystem, parent = None):
    super(ExportRawStreamDialog, self).__init__(parent)
    
    self.setWindowTitle('Raw Stream Export')
    
    self.setMinimumWidth(400)

    self.cameraSystem = cameraSystem
    self.depthCameraController = DepthCameraStreamController(cameraSystem)
    self.dataEngine = DataEngine(self.depthCameraController, queueLength = None)
    self.dataEngine.enableStatistics()
    
    layout = QtGui.QVBoxLayout(self)

    hlayout = QtGui.QHBoxLayout()
    hlayout.addWidget(QtGui.QLabel('Data Type:'))
    self.dataComboBox = QtGui.QComboBox()
    self.dataComboBox.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
    hlayout.addWidget(self.dataComboBox)
    layout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    self.vxlFileName = QtGui.QLineEdit()
    self.vxlFileName.setPlaceholderText('Saved VXL Stream File Name')
    self.vxlFileName.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
    self.vxlFileName.textChanged.connect(self.fileNameChanged)
    hlayout.addWidget(self.vxlFileName)
    self.vxlBrowseButton = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_DirOpenIcon), '')
    self.vxlBrowseButton.clicked.connect(self.vxlBrowseFile)
    hlayout.addWidget(self.vxlBrowseButton)
    layout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    self.rawFileName = QtGui.QLineEdit()
    self.rawFileName.setPlaceholderText('Output Raw Stream File Name')
    self.rawFileName.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
    self.rawFileName.textChanged.connect(self.fileNameChanged)
    hlayout.addWidget(self.rawFileName)
    self.rawBrowseButton = QtGui.QPushButton(self.style().standardIcon(QtGui.QStyle.SP_DirOpenIcon), '')
    self.rawBrowseButton.clicked.connect(self.rawBrowseFile)
    hlayout.addWidget(self.rawBrowseButton)
    layout.addLayout(hlayout)
    
    self.progress = QtGui.QProgressBar()
    
    layout.addWidget(self.progress)
    
    self.progress.setValue(0)
    
    self.logBox = QtGui.QLabel()
    
    layout.addWidget(self.logBox)
    
    # OK and Cancel buttons
    buttons = QtGui.QDialogButtonBox(self)
    
    self.processButton = QtGui.QPushButton("&Export", self)
    self.vxlFileName.returnPressed.connect(self.processButton.click)
    self.rawFileName.returnPressed.connect(self.processButton.click)
    self.cancelButton = QtGui.QPushButton("&Close", self)
    
    self.processButton.clicked.connect(self.processRawData)
    
    buttons.addButton(self.processButton, QtGui.QDialogButtonBox.ActionRole)
    buttons.addButton(self.cancelButton, QtGui.QDialogButtonBox.RejectRole)
    
    self.setWindowFlags(QtCore.Qt.Dialog | QtCore.Qt.CustomizeWindowHint | QtCore.Qt.WindowTitleHint)
    
    buttons.rejected.connect(self.reject)
    layout.addWidget(buttons)
    
    self.processButton.setDisabled(True)
    
    self.populateData()
    
    self.isProcessing = False
    self.fileIndex = -1
    self.frameID = -1
    self.frameCount = 0
    self.totalFrameCount = 1
    self.dataFormat = None
    self.rawFile = None
    
  @QtCore.Slot(str)
  def fileNameChanged(self, text):
    if len(self.rawFileName.text()) > 0 and len(self.vxlFileName.text()) > 0:
      self.processButton.setEnabled(True)
    else:
      self.processButton.setDisabled(True)
    
  def updateProgress(self):
    self.progress.setValue(self.frameCount*100/self.totalFrameCount)
    self.logBox.setText('Saving %d of %d frames...'%(self.frameCount, self.totalFrameCount))
    
  def keyPressEvent(self, ev):
    if ev.key() == QtCore.Qt.Key_Escape and self.isProcessing:
      ev.accept()
    else:
      super(ExportRawStreamDialog, self).keyPressEvent(ev)

  @QtCore.Slot()
  def processRawData(self):
    self.progress.setValue(0)
    self.fileIndex = self.depthCameraController.addFileStreamSource(self.vxlFileName.text())
    
    if not self.depthCameraController.sources[self.fileIndex].isInitialized():
      self.depthCameraController.removeStreamSource(self.fileIndex)
      QtGui.QMessageBox.critical(self, 'Open VXL File', 'Could not open VXL file')
      return
    
    if not self.depthCameraController.setCurrentSource(self.fileIndex):
      QtGui.QMessageBox.critical(self, 'Open VXL File', 'Could not stream from VXL file')
      return
    
    self.dataFormat = self.formatKeys[self.dataComboBox.currentIndex()]
    self.dataEngine.connectData(self.dataFormat, self.exportFrame)
    self.frameCount = 0
    
    try:
      self.rawFile = open(self.rawFileName.text(), 'wb')
    except Exception, e:
      QtGui.QMessageBox.critical(self, 'Open Raw File', 'Could not open raw file to save stream')
      return
    
    self.totalFrameCount = self.depthCameraController.sources[self.fileIndex].length()
    self.isProcessing = True
    self.disableActions()
    self.depthCameraController.start()
    
  @QtCore.Slot(object, object, object)
  def exportFrame(self, id, timestamp, frame):
    
    if not self.isProcessing:
      return
    
    if self.rawFile == None:
      return
    
    if self.frameID == id: # ignore duplicate which can occur for the first frame
      return
    
    self.frameID = id
    
    d = frame.astype(self.dataEngine.dataFormats[self.dataFormat].elementType)
    d.tofile(self.rawFile)
    
    self.frameCount += 1
    self.updateProgress()
    
    if self.frameCount >= self.totalFrameCount: # or not self.depthCameraController.isRunning():
      self.isProcessing = False
      self.stopExport()
    
  @QtCore.Slot()
  def stopExport(self):
    self.enableActions()
    
    if self.rawFile:
      self.rawFile.close()
      self.rawFile = None
      
    self.frameID = -1
    self.frameCount = 0
    self.updateProgress()
    self.dataEngine.disconnectData(self.dataFormat, self.exportFrame)
    self.logBox.setText('Saved %d frames'%self.totalFrameCount)
  
  @QtCore.Slot()
  def disableActions(self):
    self.processButton.setDisabled(True)
    self.cancelButton.setDisabled(True)
    self.dataComboBox.setDisabled(True)
    self.vxlFileName.setDisabled(True)
    self.rawFileName.setDisabled(True)
    self.vxlBrowseButton.setDisabled(True)
    self.rawBrowseButton.setDisabled(True)
    
  @QtCore.Slot()
  def enableActions(self):
    self.processButton.setEnabled(True)
    self.cancelButton.setEnabled(True)
    self.dataComboBox.setEnabled(True)
    self.vxlFileName.setEnabled(True)
    self.rawFileName.setEnabled(True)
    self.vxlBrowseButton.setEnabled(True)
    self.rawBrowseButton.setEnabled(True)
  
  @QtCore.Slot()
  def populateData(self):
    
    df = self.dataEngine.getDataFormats()
    
    formats = []
    self.formatKeys = []
    
    for d in df:
      formats.append(self.dataEngine.dataFormats[d].title)
      self.formatKeys.append(d)
      
    self.dataComboBox.addItems(formats)
    self.dataComboBox.setCurrentIndex(0)
    
  @QtCore.Slot()
  def vxlBrowseFile(self):
    filename, _ = QtGui.QFileDialog.getOpenFileName(self, 'VXL file', filter = "VXL files (*.vxl)")
    
    if filename:
      self.vxlFileName.setText(filename)
      
  @QtCore.Slot()
  def rawBrowseFile(self):
    filename, _ = QtGui.QFileDialog.getSaveFileName(self, 'Raw Data file', filter = "Raw Data files (*.bin *.dat)")
    
    if filename:
      self.rawFileName.setText(filename)
      
  def __del__(self):
    self.depthCameraController.stop()
    self.dataEngine.stop()

  # static method to create the dialog and return (date, time, accepted)
  @staticmethod
  def showDialog(cameraSystem, parent = None):
    dialog = ExportRawStreamDialog(cameraSystem, parent)
    result = dialog.exec_()
    
    del dialog
    
    return None