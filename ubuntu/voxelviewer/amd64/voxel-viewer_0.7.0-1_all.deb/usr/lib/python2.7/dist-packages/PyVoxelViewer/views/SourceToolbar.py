#
# TI Voxel Viewer component.
#
# Copyright (c) 2015 Texas Instruments Inc.
#

from PySide import QtGui, QtCore
import time
import datetime

import os

import tempfile
import shutil

import Voxel

from PyVoxelViewer.common.Common import *

class FrameCountDisplay(QtGui.QLCDNumber):
  
  def __init__(self):
    super(FrameCountDisplay, self).__init__()
    
    self.setDigitCount(9)
    
    self.frameCountAction = QtGui.QAction('Show frame count', self)
    self.frameCountAction.setCheckable(True)
    self.addAction(self.frameCountAction)
    
    self.frameTimestampAction = QtGui.QAction('Show frame time', self)
    self.frameTimestampAction.setCheckable(True)
    self.addAction(self.frameTimestampAction)
    
    self.frameCountAction.triggered.connect(self.frameCountTriggered)
    self.frameTimestampAction.triggered.connect(self.frameTimestampTriggered)
    
    self.showFrameCount()
    
    self.setContextMenuPolicy(QtCore.Qt.ActionsContextMenu)
    
  @QtCore.Slot()
  def frameCountTriggered(self):
    if self.frameCountAction.isChecked():
      self.showFrameCount()
    else:
      self.showFrameTime()
  
  @QtCore.Slot()
  def frameTimestampTriggered(self):
    if self.frameTimestampAction.isChecked():
      self.showFrameTime()
    else:
      self.showFrameCount()
    
  def showFrameCount(self):
    self.frameCounter = True
    self.setMinimumWidth(100)
    self.frameCountAction.setChecked(True)
    self.frameTimestampAction.setChecked(False)
    self.updateDisplay()
    
  def showFrameTime(self):
    self.frameCounter = False
    self.setMinimumWidth(200)
    self.frameCountAction.setChecked(False)
    self.frameTimestampAction.setChecked(True)
    self.updateDisplay()


  def updateDisplay(self):
    if self.frameCounter and hasattr(self, 'frameCount'):
      displayCount = '%d'%self.frameCount
      if len(displayCount) > 6:
        self.setDigitCount(len(displayCount))
      else:
        self.setDigitCount(6)
      self.display(displayCount)
    elif hasattr(self, 'frameTime'):
      displayTime = getDisplayTime(self.frameTime)

      self.setDigitCount(len(displayTime))
      self.display(displayTime)

  def setData(self, frameTime, frameCount):
    self.frameTime = frameTime
    self.frameCount = frameCount
    self.updateDisplay()
      

class RecordTool(QtGui.QWidget):
  
  updateUI = QtCore.Signal(str)
  
  stopRecording = QtCore.Signal()
  
  showWarning = QtCore.Signal()
  
  def __init__(self, depthCameraController, window):
    super(RecordTool, self).__init__()
    
    self.depthCameraController = depthCameraController
    
    self.window = window
    
    self.layout = QtGui.QHBoxLayout()
    
    self.recordButton = QtGui.QToolButton()
    self.recordButton.setShortcut('Ctrl+S')
    self.layout.addWidget(self.recordButton)
    
    self.recordingDetails = QtGui.QLabel()
    self.layout.addWidget(self.recordingDetails)
    
    self.setLayout(self.layout)
    
    self.recordButton.clicked.connect(self.toggleRecordingState)
    self.stopRecording.connect(self.toggleRecordingState, QtCore.Qt.QueuedConnection)
    self.showWarning.connect(self.displayWarningDialog, QtCore.Qt.QueuedConnection)
    
    self.depthCameraController.resumed.connect(self.onDepthCameraResumed)
    
    self.updateUI.connect(self.setRecordingMessage, QtCore.Qt.QueuedConnection)
    
    self.recording = False
    self.setRecordingUI(False)
    
    self.startingIndex = None
    self.warningShown = False
    
  def setRecordingUI(self, r):
    if r:
      self.recordButton.setIcon(self.window.style().standardIcon(QtGui.QStyle.SP_MediaStop))
      self.recordButton.setToolTip('Stop recording')
      self.recordingDetails.setVisible(True)
    else:
      self.recordButton.setIcon(self.window.style().standardIcon(QtGui.QStyle.SP_DialogSaveButton))
      self.recordButton.setToolTip('Start recording')
      self.recordingDetails.setVisible(False)
      
  @QtCore.Slot()
  def toggleRecordingState(self):
    
    depthCamera = self.depthCameraController.getDepthCamera()
    
    if not depthCamera or not depthCamera.isRunning() or self.depthCameraController.isPaused():
      return
    
    if self.recording:
      if depthCamera.isSavingFrameStream():
        depthCamera.closeFrameStream()
        self.depthCameraController.clearCallback(Voxel.DepthCamera.FRAME_RAW_FRAME_UNPROCESSED, self.updateFrameTime)
        self.showFileSaveDialog()
      
      self.setRecordingUI(False)
      self.recording = False
      self.startingIndex = None
      self.warningShown = False
    else:
      self.setRecordingMessage('')
      self.currentTime = time.time()*1E6
      self.recordingTime = 0
      self.recordingFrameCount = 0
      id = generateTemporaryID()
      self.temporaryFile = os.path.join(tempfile.gettempdir(), 'VoxelViewer-' + id + ".vxl")
      print 'Saving to temporary file ', self.temporaryFile, '...'
      if not depthCamera.saveFrameStream(self.temporaryFile):
        QtGui.QMessageBox.critical(self, 'Save Frames', 'Failed to save frames to file ' + self.temporaryFile)
      else:
        self.recording = True
        self.depthCameraController.registerCallback(Voxel.DepthCamera.FRAME_RAW_FRAME_UNPROCESSED, self.updateFrameTime)
        self.setRecordingUI(True)
        
  def displayWarningDialog(self):
    QtGui.QMessageBox.warning(self, 'Save Frames', 'You are recording for more than %d minutes. To save a typical QVGA (320x240) data at 25fps for 2 minutes, more than 500MB of storage space is used'%self.durationCrossed)
        
  def showFileSaveDialog(self):
    filename, _ = QtGui.QFileDialog.getSaveFileName(self, 'Save Frame Stream', filter = "Voxel files (*.vxl)")
    
    if filename:
      try:
        print 'Moving saved stream to ', filename, '...'
        shutil.move(self.temporaryFile, filename)
        self.depthCameraController.addFileStreamSource(filename)
        print 'Done'
      except IOError, e:
        QtGui.QMessageBox.critical('Save Frames', 'Failed to save frames in file ' + filename)
    else:
      try:
        os.remove(self.temporaryFile)
      except Exception, e:
        print 'SourceToolbar::RecordTool: Could not remove temporary file ' + self.temporaryFile
        pass
        
        
  def updateFrameTime(self, depthCamera, frame, type):
    
    self.recordingFrameCount += 1
    
    # Uncomment this to limit recording to a fixed number of frames
    if self.recordingFrameCount > 1000:
      self.stopRecording.emit()
      
    self.recordingTime += (frame.timestamp - self.currentTime)
    
    self.currentTime = frame.timestamp
    
    if self.recordingTime > 120E6: # 2 minutes
      self.durationCrossed = 2 # minutes. This is used in the dialog
      if not self.warningShown:
        self.showWarning.emit()
        self.warningShown = True
    
    self.updateUI.emit(getDisplayTime(self.recordingTime))
    
  @QtCore.Slot(str)
  def setRecordingMessage(self, m):
    self.recordingDetails.setText(m)
    
  def onDepthCameraResumed(self):
    self.currentTime = time.time()*1E6
    

class SourceToolbar(QtCore.QObject):
  
  frameUpdated = QtCore.Signal(object, object)
  
  def __init__(self, depthCameraController, dataEngine, window, toolbar):
    super(SourceToolbar, self).__init__()
    self.toolbar = toolbar
    self.window = window
    self.depthCameraController = depthCameraController
    self.dataEngine = dataEngine
    
    toolbar.addWidget(QtGui.QLabel('Source: '))
    
    self.sources = QtGui.QComboBox()
    self.sources.currentIndexChanged.connect(self.depthCameraController.setCurrentSource)
    
    self.depthCameraController.sourceListChanged.connect(self.populateSources)
    self.depthCameraController.sourceSelected.connect(self.sources.setCurrentIndex)
    
    self.populateSources()
    
    toolbar.addWidget(self.sources)
    
    self.recordTool = RecordTool(self.depthCameraController, window)
    
    toolbar.addWidget(self.recordTool)
    
    self.saveSeparator = toolbar.addSeparator()
    
    self.playAction = QtGui.QAction(window.style().standardIcon(QtGui.QStyle.SP_MediaPlay), 'Play/Pause', self)
    self.playAction.setShortcut('Ctrl+P')
    self.playAction.setStatusTip('Play/Pause')
    self.playAction.triggered.connect(self.startPlayback)
    toolbar.addAction(self.playAction)
    
    self.stopAction = QtGui.QAction(window.style().standardIcon(QtGui.QStyle.SP_MediaStop), 'Stop', self)
    self.stopAction.setShortcut('Ctrl+U')
    self.stopAction.setStatusTip('Stop')
    self.stopAction.triggered.connect(self.stopPlayback)
    self.stopAction.setEnabled(False)
    toolbar.addAction(self.stopAction)
    
    self.depthCameraController.started.connect(self.onDepthCameraStart)
    self.depthCameraController.stopped.connect(self.onDepthCameraStop)
    
    self.dataEngine.connectData("phase", self.getFrameID, QtCore.Qt.QueuedConnection)
    self.frameUpdated.connect(self.updateSliderAndNumber, QtCore.Qt.QueuedConnection)
    
    self.slider = QtGui.QSlider(QtCore.Qt.Horizontal)
    self.slider.valueChanged.connect(self.sliderChanged)
    self.slider.setSingleStep(1)
    toolbar.addWidget(self.slider)

    self.doNotUpdate = False
    
    self.lcdNumber = FrameCountDisplay()
    toolbar.addWidget(self.lcdNumber)
    
    toolbar.addSeparator()
    
  def populateSources(self):
    sources = self.depthCameraController.getSources()
    
    i = self.sources.currentIndex()
    
    self.sources.blockSignals(True)
    self.sources.clear()
    if len(sources):
      for s in sources:
        self.sources.addItem(s.getName())
        
      if i >= 0:
        self.sources.setCurrentIndex(i)
    
    self.sources.blockSignals(False)
      
    
  def onDepthCameraStart(self):
    self.playAction.setIcon(self.window.style().standardIcon(QtGui.QStyle.SP_MediaPause))
    self.stopAction.setEnabled(True)
    self.currentTime = int(time.time()*1E6)
    
    s = self.depthCameraController.getCurrentSource()
    
    if s and s.isSeekable():
      self.slider.setEnabled(True)
      self.slider.setRange(0, s.length() - 1)
      self.slider.setSingleStep(1)
      self.slider.setTickInterval(1)
    else:
      self.slider.setEnabled(False)
      
  @QtCore.Slot(object, object, object)
  def getFrameID(self, id, timestamp, frame):
    self.frameUpdated.emit(id, timestamp)
    
  @QtCore.Slot(int)
  def sliderChanged(self, pos):
    s = self.depthCameraController.getCurrentSource()
    
    if s and s.isSeekable():
      s.seek(pos)

  @QtCore.Slot(object, object)
  def updateSliderAndNumber(self, frameID, frameTimestamp):
    self.lcdNumber.setData(frameTimestamp - self.currentTime, frameID)
    
    s = self.depthCameraController.getCurrentSource()
    
    if s and s.isSeekable():
      self.slider.blockSignals(True)
      self.slider.setValue(s.currentPosition())
      self.slider.blockSignals(False)
    
  def onDepthCameraStop(self):
    self.playAction.setIcon(self.window.style().standardIcon(QtGui.QStyle.SP_MediaPlay))
    self.stopAction.setEnabled(False)
    
        
  def startPlayback(self):
    if self.depthCameraController.isPaused() or not self.depthCameraController.isRunning():
      if not self.depthCameraController.start():
        QtGui.QMessageBox.critical(self.window, u"Playback start", u"Failed to start streaming")
      else:
        self.playAction.setIcon(self.window.style().standardIcon(QtGui.QStyle.SP_MediaPause))
    else:
      #if self.recordTool.recording:
      #  self.recordTool.toggleRecordingState()
          
      if not self.depthCameraController.pause():
        QtGui.QMessageBox.critical(self.window, u"Pause", u"Failed to pause streaming")
      else:
        self.playAction.setIcon(self.window.style().standardIcon(QtGui.QStyle.SP_MediaPlay))
        
      
  def stopPlayback(self):
    if self.recordTool.recording:
      self.recordTool.toggleRecordingState()
      
    if not self.depthCameraController.stop():
      QtGui.QMessageBox.critical(self.window, u"Playback stop", u"Failed to stop streaming")
      
      
