#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

class StatisticsDialog(QtGui.QDialog):
  
  def __init__(self, statusBar, dataEngine, parent = None):
    super(StatisticsDialog, self).__init__(parent)
    
    self.setWindowTitle('Statistics')
    self.statusBar = statusBar
    self.dataEngine = dataEngine
    
    layout = QtGui.QVBoxLayout(self)
    
    groupbox = QtGui.QGroupBox()
    layout.addWidget(groupbox)
    groupbox.setCheckable(True)
    groupbox.setTitle('Temporal Statistics')
    
    groupbox.toggled.connect(self.statisticsChanged)
    
    ivlayout = QtGui.QVBoxLayout()
    ilayout = QtGui.QHBoxLayout()
    
    ilayout.addWidget(QtGui.QLabel('Settling Time:'))
    
    spinbox = QtGui.QSpinBox()
    spinbox.setRange(1, 200)
    spinbox.setValue(self.dataEngine.settlingTime)
    spinbox.valueChanged.connect(self.dataEngine.setSettlingTime)
    self.dataEngine.rateFactorChanged.connect(self.setRateFactor, QtCore.Qt.QueuedConnection)
    
    ilayout.addWidget(spinbox)
    
    ivlayout.addLayout(ilayout)
    
    self.rateFactor = QtGui.QLabel()
    ivlayout.addWidget(self.rateFactor)
    
    groupbox.setLayout(ivlayout)
    
    self.setRateFactor(self.dataEngine.rateFactor)
    
  def setRateFactor(self, rateFactor):
    self.rateFactor.setText('Rate Factor = ' + str(rateFactor))
    
  def statisticsChanged(self, state):
    self.statusBar.enableStatistics.setChecked(state)

  # static method to create the dialog and return (date, time, accepted)
  @staticmethod
  def showDialog(statusBar, dataEngine, parent = None):
    dialog = StatisticsDialog(statusBar, dataEngine, parent)
    dialog.exec_()