#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.common.about import *

from PyVoxelViewer.icons import icons

class SplashDialog(QtGui.QDialog):
  
  dialog = None
  
  def __init__(self, title, parent = None):
    super(SplashDialog, self).__init__(parent)

    layout = QtGui.QVBoxLayout(self)
    
    screenWidth = QtGui.QDesktopWidget().screenGeometry().width()
    self.setModal(True)
    #self.setMaximumWidth(300)
    layout.setContentsMargins(QtCore.QMargins(0, 0, 0 , 0))
    pixSplash = QtGui.QPixmap(':/splash.png')
    pixSplash = pixSplash.scaledToWidth(int(0.35*screenWidth), QtCore.Qt.SmoothTransformation)
    splashLabel = QtGui.QLabel(self)
    splashLabel.setPixmap(pixSplash)
    layout.addWidget(splashLabel)
    
    self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.Dialog | QtCore.Qt.WindowStaysOnTopHint)
    ##self.setGeometry(QtGui.QStyle.alignedRect(QtCore.Qt.LeftToRight, QtCore.Qt.AlignCenter, QtCore.QSize(300, 300), app.desktop().availableGeometry()))
    
    ##hlayout = QtGui.QHBoxLayout()
    ##pix = QtGui.QPixmap(':/voxel.png')
    ##pix = pix.scaledToHeight(144, QtCore.Qt.SmoothTransformation)
    ##logo = QtGui.QLabel(self)
    ###logo.setPixmap(pix)
    ##logo.setFixedHeight(144)
    ##logo.setMaximumWidth(160)
    ##logo.setMargin(3)
    ##logo.setAlignment(QtCore.Qt.AlignCenter)
    ##hlayout.addWidget(logo)
    
    ##vlayout = QtGui.QVBoxLayout()
    ##name = QtGui.QLabel(title)
    ##name.setAlignment(QtCore.Qt.AlignRight)
    ##name.setStyleSheet('font-size: 48px; font-weight: 600; font-family: Serif; color: #FFFFFF;')
    ### version = QtGui.QLabel('Version: ' + VERSION_NUMBER)
    ### version.setStyleSheet('font-size: 12px; font-weight: 600; color: #FFFFFF;')
    ### version.setAlignment(QtCore.Qt.AlignRight)
    ##vlayout.addWidget(name)
    ### vlayout.addWidget(version)
    ##hlayout.addLayout(vlayout)
    ##layout.addLayout(hlayout)
    
    ##layout.addSpacing(10)
    
    ##pix = QtGui.QPixmap(':/Ti_hz_2c_pos_rgb_png_white.png')
    ##pix = pix.scaledToHeight(25, QtCore.Qt.SmoothTransformation)
    ##tiLogo = QtGui.QLabel(self)
    ##tiLogo.setPixmap(pix)
    ##tiLogo.setMargin(3)
    ##tiLogo.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
    ##tiLogo.setMinimumHeight(40)
    ##tiLogo.setStyleSheet('background-color: #CC0000;')
    ##layout.addWidget(tiLogo)
    
    ##copyright = QtGui.QLabel('Copyright (c) 2015, Texas Instruments Incorporated. All rights ##reserved')##
    ##copyright.setS##tyleSheet('color: white;')##
    ##copyright.setA##lignment(QtCore.Qt.AlignRight)##
    ##layout.addWidget(copyright)##
    ##print(QtGui.QDesktopWidget().screenGeometry(copyright))
    ##print(QtGui.QDesktopWidget().screenNumber(copyright))
    
    ###self.setStyleSheet('QDialog { background: qlineargradient(x1:0 y1:0, x2:1 y2:0, stop:0 rgba(100, 100, 100, 255), stop:1 black); }')
    ##self.setStyleSheet('QDialog { background: black; }')
    
    self.timer = QtCore.QTimer(self)
    self.timer.setSingleShot(True)
    self.timer.timeout.connect(self.quitDialog)
    self.timer.start(5000)
    
    self.timer2 = QtCore.QTimer(self)
    self.timer2.setSingleShot(True)
  
  def triggerEvent(self, timeout, handler):
    self.timer2.timeout.connect(handler)
    self.timer2.start(timeout)
    
  def accept(self):
    super(SplashDialog, self).accept()
    self.timer.stop()
    self.timer2.stop()
    
  def reject(self):      
    super(SplashDialog, self).reject()
    self.timer.timeout.emit()
    self.timer.stop()
    self.timer2.stop()
    
  def quitDialog(self):
    if SplashDialog.dialog != None:
      SplashDialog.dialog = None
      self.accept()
    
  @staticmethod
  def createDialog(title, parent = None):
    SplashDialog.dialog = SplashDialog(title, parent)
    ##QtGui.QPixmap.grabWidget(SplashDialog.dialog).save('D:/Anand/Work/Code/voxel-sdk/screenshot3434.png', fileformat='png')
    return SplashDialog.dialog