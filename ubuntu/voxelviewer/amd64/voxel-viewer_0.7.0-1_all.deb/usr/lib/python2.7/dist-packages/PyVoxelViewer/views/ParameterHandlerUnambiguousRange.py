#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

import Voxel

from PySide import QtGui, QtCore

import numbers

from XYSpinBox import XYSpinBox

from functools import partial

from ParameterHandler import ParameterHandler

from PyVoxelViewer.views.DataView import DataView

class UnambiguousRangeView(QtGui.QWidget):
  valueChanged = QtCore.Signal()
  
  paramsToShow = {
    'common': [
      "dealias_en",
      "mod_freq1",
      "quad_cnt_max",
      "sub_frame_cnt_max",
    ],
    'calculus.ti': [
      "dealias_en",
      "alt_frm_en",
      "mod_f",
      "sub_frame_cnt_max1"
    ]
  }
  
  paramsToShowIfDealiasing = {
    'common': [
      "mod_freq2",
      "ma",
      "mb",
      "dealias_16bit_op_enable",
      "dealiased_ph_mask"
    ],
    'calculus.ti': [
      "alt_freq_sel",
      "sub_frame_cnt_max2",
      "sup_frm_intg_scale"
    ]
  }
  
  @staticmethod
  def getID():
    return "unambiguous_range"
  
  def getTitle(self):
    return "Unambiguous Range (" + UnambiguousRangeView.getID() + ")"
  
  def __init__(self, window, depthCameraController):
    super(UnambiguousRangeView, self).__init__()
    
    self.window = window
    self.depthCameraController = depthCameraController
    
    vlayout = QtGui.QVBoxLayout(self)
    
    self.details = QtGui.QLabel()
    
    self.paramWidget = None
    
    self.depthCamera = self.depthCameraController.getDepthCamera()
    
    if self.depthCamera:
      self.chipset = self.depthCamera.chipset()
      
      if self.paramsToShow.has_key(self.chipset):
        self.paramSetToShow = self.chipset
      else:
        self.paramSetToShow = 'common'
      
      self.param = ParameterHandler.getParameterHandler(self.depthCamera, UnambiguousRangeView.getID())
      
      if self.param:
        self.paramWidget = self.param.getDetailedDisplayWidget()
        self.paramWidget.valueChanged.connect(self.valueChanged)
        vlayout.addWidget(self.paramWidget)
      else:
        self.details.setText('Parameter not available')
        
    self.details.setStyleSheet('QLabel { color: #777; }')
    self.details.setAlignment(QtCore.Qt.AlignLeft)
    
    vlayout.addWidget(self.details)
    
    self.setSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Minimum)
    
    self.init()
    
    self.valueChanged.connect(self.init)
      
  @QtCore.Slot()
  def init(self):
    
    if self.depthCamera == None or self.param == None:
      return
    
    if self.paramWidget:
      self.paramWidget.init()
    
    r, v = self.param.get()
    
    if not r:
      return
    
    DataView.communicator.thresholdsChanged.emit('depth', 0, v)
    
    t = ''
    
    dealiasing = False
    
    for i in UnambiguousRangeView.paramsToShow[self.paramSetToShow]:
      p, t = self.showParam(i, t)
      
      if i == "dealias_en":
        r, dealiasing = p.get()
          
    if dealiasing:
      for i in UnambiguousRangeView.paramsToShowIfDealiasing[self.paramSetToShow]:
        p, t = self.showParam(i, t)
    
    self.details.setText(t)
    
  def showParam(self, paramName, text):
    p = ParameterHandler.getParameterHandler(self.depthCamera, paramName)
      
    if p:
      text += p.getName() + ' = ' + p.getDisplayValue() + '\n'
        
    return p, text
       
       
       