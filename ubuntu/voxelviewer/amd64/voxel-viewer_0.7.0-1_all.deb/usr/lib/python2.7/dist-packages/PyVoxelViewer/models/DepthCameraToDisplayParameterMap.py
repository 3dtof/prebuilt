#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#


DepthCameraToDisplayParameterMap = { \
  "Voxel14Camera" : ["intg_time", "illum_volt", "mix_volt", "vco_freq", "mod_freq1", "mod_freq2"],
  "VoxelDCamera" : ["intg_time", "illum_volt", "mix_volt", "mod_freq1", "mod_freq2"],
}

ParameterDependencyMap = { \
  "Voxel14Camera" : { "mod_freq1": "vco_freq", "mod_freq2": "vco_freq" },
}
