#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.views.DataView import DataView

import string
import os

class PointWatchListElement(QtCore.QObject):
  def __init__(self, point, dataEngine):
    self.point = point # [x, y]
    self.dataEngine = dataEngine
    self.phase = ''
    self.amplitude = ''
    self.ambient = ''
    self.depth = ''
    
    self.dataEngine.connectData("depth", self.updateData, QtCore.Qt.QueuedConnection)
    
  @QtCore.Slot(object, object, object)
  def updateData(self, id, timestamp, frame):
    depth = self.dataEngine.data['depth'][self.point[0]][self.point[1]]
    a = self.dataEngine.data['amplitude'][self.point[0]][self.point[1]]
    p = self.dataEngine.data['phase'][self.point[0]][self.point[1]]
    amb = self.dataEngine.data['ambient'][self.point[0]][self.point[1]]
      
    if self.dataEngine.isStatisticsEnabled and (self.dataEngine.data.has_key('phase_avg') \
      and self.dataEngine.data.has_key('phase_std') \
      and self.dataEngine.data.has_key('amplitude_avg') \
      and self.dataEngine.data.has_key('amplitude_std')):
      
      aavg = self.dataEngine.data['amplitude_avg'][self.point[0]][self.point[1]]
      astd = self.dataEngine.data['amplitude_std'][self.point[0]][self.point[1]]
      
      pavg = self.dataEngine.data['phase_avg'][self.point[0]][self.point[1]]
      pstd = self.dataEngine.data['phase_std'][self.point[0]][self.point[1]]
      
      davg = self.dataEngine.data['depth_avg'][self.point[0]][self.point[1]]
      dstd = self.dataEngine.data['depth_std'][self.point[0]][self.point[1]]
      
      self.phase = '%5d (%7.2f, %7.2f)'%(p, pavg, pstd)
      self.amplitude = '%5d (%7.2f, %7.2f)'%(a, aavg, astd)
      self.depth = '%5.4f (%5.4f, %5.4f)'%(depth, davg, dstd)
    else:
      self.phase = '%5d'%p
      self.amplitude = '%5d'%a
      self.depth = '%5.4f'%depth
      
    self.ambient = '%3d'%amb
    
  def getPointAsString(self):
    return "(%3d, %3d)"%(self.point[0], self.point[1])
    
  def getCSVString(self):
    return self.getPointAsString() + ";" + \
      self.phase + ";" + \
      self.amplitude + ";" + \
      self.ambient + ";" + \
      self.depth + ";"

class PointWatchListModel(QtCore.QAbstractTableModel):
  def __init__(self, dataEngine):
    super(PointWatchListModel, self).__init__()
    
    self.sectionNames = ["Point", "Phase", "Amplitude", "Ambient", "Z, meters"]
    self.sectionNamesStats = ["Point", "Phase (Avg, Std)", "Amplitude (Avg, Std)", "Ambient", "Z, meters (Avg, Std)"]
    
    self.dataEngine = dataEngine
    
    self.watchListElements = []
    
  def getWatchElementString(self, index):
    if index < 0 or index >= len(self.watchListElements):
      return None
    
    w = self.watchListElements[index]
    
    if self.dataEngine.isStatisticsEnabled:
      s = self.sectionNamesStats
    else:
      s = self.sectionNames
    
    
    return w.getPointAsString() + \
        " -> " + s[1] + ": " + w.phase + \
        ", "   + s[2] + ": " + w.amplitude + \
        ", "   + s[3] + ": " + w.ambient + \
        ", "   + s[4] + ": " + w.depth
    
    
  def getHeaderCSVString(self):
    if not self.dataEngine.isStatisticsEnabled:
      return string.join(self.sectionNames, ';')
    else:
      return string.join(self.sectionNamesStats, ';')
    
  def addWatchListPoint(self, point):
    w = PointWatchListElement(point, self.dataEngine)
    self.watchListElements.append(w)
    
  def flags(self, index):
    f = super(PointWatchListModel, self).flags(index)
    return f | QtCore.Qt.ItemIsSelectable
    
  def rowCount(self, parent = QtCore.QModelIndex()):
    return len(self.watchListElements)
  
  def columnCount(self, parent = QtCore.QModelIndex()):
    return 5
  
  def data(self, index, role = QtCore.Qt.DisplayRole):
    
    if role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      w = self.watchListElements[index.row()]
      
      if index.column() == 0:
        return w.getPointAsString()
      elif index.column() == 1:
        return w.phase
      elif index.column() == 2:
        return w.amplitude
      elif index.column() == 3:
        return w.ambient
      elif index.column() == 4:
        return w.depth
      else:
        return None
  
  def headerData(self, section, orientation, role = QtCore.Qt.DisplayRole):
    if role == QtCore.Qt.DisplayRole:
      if orientation == QtCore.Qt.Horizontal:
        if self.dataEngine.isStatisticsEnabled:
          return self.sectionNamesStats[section]
        else:
          return self.sectionNames[section]
      else:
        return None
    elif role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      return None

class PointWatchListDelegate(QtGui.QAbstractItemDelegate):
  def __init__(self, tableView, dataEngine):
    super(PointWatchListDelegate, self).__init__()
    
    self.tableView = tableView
    
    self.dataEngine = dataEngine
    
  def paint(self, painter, option, index):
    if option.state & QtGui.QStyle.State_Selected:
      if option.state & QtGui.QStyle.State_Active:
        painter.setBrush(QtGui.QBrush(self.tableView.palette().highlight()))
      else:
        painter.setBrush(QtGui.QBrush(self.tableView.palette().color(QtGui.QPalette.Inactive, QtGui.QPalette.Highlight)))
      painter.drawRect(option.rect)
    painter.drawText(option.rect, QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter, index.data())
  
  def sizeHint(self, option, index):
    return option.rect.size() # Occupy full size
  
class PointWatchListView(QtGui.QTableView):
  def __init__(self, dataEngine, parent = None):
    super(PointWatchListView, self).__init__(parent)
    self.dataEngine = dataEngine
    self.model = PointWatchListModel(self.dataEngine)
    self.currentRow = -1
    
    self.watchListDelegate = PointWatchListDelegate(self, dataEngine)
    self.setItemDelegate(self.watchListDelegate)
    self.setModel(self.model)
    
    self.setToolTip('Shift-click in 2D views to add here')
    
    self.horizontalHeader().setResizeMode(QtGui.QHeaderView.Stretch)
    self.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
    self.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
    
    DataView.communicator.setShiftClickPoint2D.connect(self.addPoint, QtCore.Qt.QueuedConnection)
    
    self.dataEngine.connectData("depth", self.modelChanged, QtCore.Qt.QueuedConnection)
    
    self.menu = QtGui.QMenu(self)
    
    copyAction = QtGui.QAction('Copy to clipboard', self)
    copyAction.triggered.connect(self.copyPointWatchListElement)
    
    saveAction = QtGui.QAction('Save all to CSV', self)
    saveAction.triggered.connect(self.saveWatchList)
    
    removeAction = QtGui.QAction('Remove', self)
    removeAction.triggered.connect(self.removePointWatchListElement)
    
    removeAllAction = QtGui.QAction('Remove All', self)
    removeAllAction.triggered.connect(self.removeAllPointWatchListElements)
    
    self.menu.addAction(copyAction)
    self.menu.addAction(saveAction)
    self.menu.addAction(removeAction)
    self.menu.addAction(removeAllAction)
    self.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
    
  def contextMenuEvent(self, event):
    self.menu.popup(event.globalPos())
    
  @QtCore.Slot()
  def removePointWatchListElement(self):
    if self.currentRow >= 0 and self.currentRow < len(self.model.watchListElements):
      del self.model.watchListElements[self.currentRow]
      self.currentRow = -1
    else:
      QtGui.QMessageBox.critical(self, 'Watch List Element', 'Failed to remove watch list element')
      
  def removeAllPointWatchListElements(self):
    self.model.watchListElements = []
    self.model.reset()
      
  @QtCore.Slot()
  def copyPointWatchListElement(self):
    s = self.model.getWatchElementString(self.currentRow)
    print s
    if s:
      c = QtGui.QApplication.clipboard()
      c.setText(s)
      self.currentRow = -1
    else:
      QtGui.QMessageBox.critical(self, 'Watch List Element', 'Failed to remove watch list element')
      
  @QtCore.Slot()
  def saveWatchList(self):
    
    s = 'sep=;\n' + self.model.getHeaderCSVString() + '\n'
    
    for w in self.model.watchListElements:
      s += w.getCSVString() + '\n'
    
    filename, _ = QtGui.QFileDialog.getSaveFileName(self, 'Save CSV to file', filter = "CSV files (*.csv)")
    
    if filename:
      try:
        print 'Saving CSV to file ', filename, '...'
        f = open(filename, 'w')
        f.write(s)
        f.close()
        print 'Done'
      except IOError, e:
        QtGui.QMessageBox.critical('Save CSV to file', 'Failed to save CSV to file ' + filename)
    
  @QtCore.Slot(object, object, object)
  def modelChanged(self, id, timestamp, frame):
    self.model.reset()
      
  def addPoint(self, point):
    x = int(point.x())
    y = int(point.y())
    
    f = self.dataEngine.getFrameSize()
    
    if not f:
      return
    
    if x < 0 or x >= f[0] or y < 0 or y >= f[1]:
      return
    
    self.model.addWatchListPoint([x, y])
    
  def mousePressEvent(self, e):
    super(PointWatchListView, self).mousePressEvent(e)
    self.currentRow = self.currentIndex().row()  