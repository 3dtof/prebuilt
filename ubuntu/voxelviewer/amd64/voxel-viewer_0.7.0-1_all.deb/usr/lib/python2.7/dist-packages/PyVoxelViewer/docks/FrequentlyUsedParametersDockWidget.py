#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

import string

from PyVoxelViewer.views.ParameterHandler import *
from PyVoxelViewer.views.ParameterHandlerROI import RegionOfInterestParameterView
from PyVoxelViewer.views.ParameterHandlerVideoMode import VideoModeParameterView
from PyVoxelViewer.views.ParameterHandlerIntegrationDutyCycle import IntegrationDutyCycleView
from PyVoxelViewer.views.ParameterHandlerUnambiguousRange import UnambiguousRangeView
from PyVoxelViewer.views.ParameterHandlerIlluminationPower import IlluminationPowerView

from PyVoxelViewer.models.DepthCameraToDisplayParameterMap import *

class FrequentlyUsedParametersDockWidget(QtGui.QDockWidget):
  
  paramValueSet = QtCore.Signal(str)
  
  def __init__(self, window, depthCameraController):
    QtGui.QDockWidget.__init__(self, "Frequently Used Parameters")
    
    self.setMinimumWidth(350)
    self.setMaximumWidth(350)
    
    self.params = [UnambiguousRangeView, IlluminationPowerView, IntegrationDutyCycleView, VideoModeParameterView, RegionOfInterestParameterView]
    
    self.window = window
    self.depthCameraController = depthCameraController
    self.depthCameraController.onDepthCameraSet.connect(self.updateView)
    
    self.paramWidgets = {}
    
  @QtCore.Slot(str)
  def initParams(self, paramName):
    for id, w in self.paramWidgets.iteritems():
      w.init()
    
  def showParam(self, param):
    groupbox = QtGui.QGroupBox()
    
    p = param(self.window, self.depthCameraController)
    
    p.valueChanged.connect(lambda: self.paramValueSet.emit(p.getID()))
    
    layout = QtGui.QHBoxLayout()
    layout.addWidget(p)
    groupbox.setLayout(layout)
    self.layout.addWidget(groupbox)
    
    self.paramWidgets[p.getID()] = p
    
    groupbox.setTitle(p.getTitle())
    
    #self.depthCamera = self.depthCameraController.getDepthCamera()
    
    #if self.depthCamera:
      #p = ParameterHandler.getParameterHandler(self.depthCamera, param)
      
      #if p:
        #w = p.getDetailedDisplayWidget()
        #self.paramWidgets[param] = w
        
        #if w:
          #groupbox = QtGui.QGroupBox()
          #groupbox.setTitle(p.getDisplayName() + " (" + p.getName() + ")")
      
          #layout = QtGui.QHBoxLayout()
          #layout.addWidget(w)
          #groupbox.setLayout(layout)
          #self.layout.addWidget(groupbox)
          
  @QtCore.Slot()  
  def updateView(self):
    self.depthCamera = self.depthCameraController.getDepthCamera()
    
    if self.depthCamera == None:
      return
    
    self.paramWidgets = {}
    
    ## Use param names in self.params
    self.scrollArea = QtGui.QScrollArea()
    self.scrollArea.setWidgetResizable(True)
    self.mwidget = QtGui.QWidget()
    self.layout = QtGui.QVBoxLayout()
    
    for p in self.params:
      self.showParam(p)
    
    self.mwidget.setLayout(self.layout)
    
    self.layout.addStretch(0)
    
    self.scrollArea.setWidget(self.mwidget)
    self.setWidget(self.scrollArea)
      
    self.paramWidgets[RegionOfInterestParameterView.getID()].valueChanged.connect(self.paramWidgets[VideoModeParameterView.getID()].init)
    self.paramWidgets[VideoModeParameterView.getID()].valueChanged.connect(self.paramWidgets[RegionOfInterestParameterView.getID()].init)
    self.paramWidgets[VideoModeParameterView.getID()].valueChanged.connect(self.paramWidgets[IntegrationDutyCycleView.getID()].init)
    
    
