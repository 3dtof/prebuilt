#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.common.Logger import Logger

from PyVoxelViewer.common.about import SOFTWARE_NAME, COMPANY_NAME, VERSION_NUMBER

import Voxel

class LogDockWidget(QtGui.QDockWidget):
  
  colors = {
    Voxel.LOG_CRITICAL: (QtGui.QColor.fromRgbF(1.0, 0.5, 0.5), QtGui.QColor.fromRgbF(1.0, 1.0, 1.0)),
    Voxel.LOG_ERROR: (QtGui.QColor.fromRgbF(1.0, 1.0, 1.0), QtGui.QColor.fromRgbF(0.87, 0.0, 0.0)),
    Voxel.LOG_WARNING: (QtGui.QColor.fromRgbF(1.0, 1.0, 1.0), QtGui.QColor.fromRgbF(0.87, 0.0, 0.0)),
    Voxel.LOG_INFO: (QtGui.QColor.fromRgbF(1.0, 1.0, 1.0), QtGui.QColor.fromRgbF(0, 0.0, 0.0)),
    Voxel.LOG_DEBUG: (QtGui.QColor.fromRgbF(1.0, 1.0, 1.0), QtGui.QColor.fromRgbF(0.0, 0.0, 0.0)),
    }
  
  def __init__(self, window):
    QtGui.QDockWidget.__init__(self, "Logs")
    self.setMinimumHeight(100)
    
    self.window = window
    
    self.logger = Logger()
    
    self.logger.outputAvailable.connect(self.updateLog)
    
    widget = QtGui.QWidget()
    
    vlayout = QtGui.QVBoxLayout()
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Default Log Level:'))
    
    self.logLevels = QtGui.QComboBox()
    self.logLevels.addItems(['Critical', 'Error', 'Warning', 'Information', 'Debug'])
    
    self.logLevels.setCurrentIndex(self.logger.getDefaultLogLevel())
    
    self.logLevels.currentIndexChanged.connect(self.setLogLevel)
    
    hlayout.addWidget(self.logLevels)
    
    hlayout.addStretch()
    
    hlayout.addWidget(QtGui.QLabel('Log file:'))
    self.fileName = QtGui.QLineEdit()
    self.fileName.setText(self.logger.getLogFileName())
    self.fileName.returnPressed.connect(self.setLogFile)
    hlayout.addWidget(self.fileName)
    browseButton = QtGui.QPushButton(self.window.style().standardIcon(QtGui.QStyle.SP_DirOpenIcon), '')
    browseButton.clicked.connect(self.browseFile)
    hlayout.addWidget(browseButton)
    applyButton = QtGui.QPushButton('Apply')
    applyButton.clicked.connect(self.setLogFile)
    hlayout.addWidget(applyButton)
    
    vlayout.addLayout(hlayout)
    
    self.logBox = QtGui.QTextBrowser()
    
    self.logBox.setReadOnly(True)
    
    self.logBox.setText(SOFTWARE_NAME + " v" + VERSION_NUMBER + "\n" + COMPANY_NAME + "\n\n")
    
    vlayout.addWidget(self.logBox)
    
    widget.setLayout(vlayout)
    self.setWidget(widget)
    
  @QtCore.Slot()
  def browseFile(self):
    filename, _ = QtGui.QFileDialog.getSaveFileName(self, 'Save Log', filter = "Log files (*.txt)")
    
    if filename:
      self.fileName.setText(filename)
      self.setLogFile()
      
  @QtCore.Slot()
  def setLogFile(self):
    self.logger.setLogFileName(self.fileName.text())
    
  @QtCore.Slot(int)
  def setLogLevel(self, index):
    self.logger.setDefaultLogLevel(index)
      
  @QtCore.Slot(object, object)
  def updateLog(self, logLevel, text):
    self.logBox.moveCursor(QtGui.QTextCursor.End)
    self.logBox.setTextColor(self.colors[logLevel][1])
    self.logBox.setTextBackgroundColor(self.colors[logLevel][0])
    self.logBox.insertPlainText(text)
    
    
  def stop(self):
    self.logger.stop()
