#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

import Voxel

from PySide import QtGui, QtCore

import numbers

from XYSpinBox import XYSpinBox

from functools import partial

########## Generic parameter handlers
class ParameterHandler(QtCore.QObject):
  
  PARAM_TYPE_DEPTH_CAMERA = 0
  PARAM_TYPE_FILTER = 1
  
  ParamTypeSets = [
      {
        'StrobeBool': Voxel.StrobeBoolParameter,
        'Bool': Voxel.BoolParameter,
        'Int': Voxel.IntegerParameter,
        'Uint': Voxel.UnsignedIntegerParameter,
        'Float': Voxel.FloatParameter,
        'Enum': Voxel.EnumParameter
      },
      {
        'StrobeBool': Voxel.BoolFilterParameter,
        'Bool': Voxel.BoolFilterParameter,
        'Int': Voxel.SignedFilterParameter,
        'Uint': Voxel.UnsignedFilterParameter,
        'Float': Voxel.FloatFilterParameter,
        'Enum': Voxel.EnumFilterParameter
      },
    ]
  
  def __init__(self, engine, param, type, parent = None):
    super(ParameterHandler, self).__init__(parent)
    self.param = param
    self.type = type
    self.engine = engine
  
  @staticmethod
  def getParameterHandler(engine, param, parent = None, paramSetType = PARAM_TYPE_DEPTH_CAMERA):
    
    ParamTypeSet = ParameterHandler.ParamTypeSets[paramSetType]
    
    if isinstance(param, basestring):
      param = engine.getParam(param)
    
    strobeBoolParam = ParamTypeSet['StrobeBool'].typeCast(param)
    
    if strobeBoolParam:
      return StrobeBoolParameterHandler(engine, strobeBoolParam, 'Bool', parent)
    
    boolParam = ParamTypeSet['Bool'].typeCast(param)
    
    if boolParam:
      return BoolParameterHandler(engine, boolParam, 'Bool', parent)
    
    enumParam = ParamTypeSet['Enum'].typeCast(param)
    
    if enumParam:
      return EnumParameterHandler(engine, enumParam, 'Int', parent)
    
    intParam = ParamTypeSet['Int'].typeCast(param)
    
    if intParam:
      return IntegerParameterHandler(engine, intParam, 'Int', parent)
    
    uintParam = ParamTypeSet['Uint'].typeCast(param)
    
    if uintParam:
      return UnsignedIntegerParameterHandler(engine, uintParam, 'Uint', parent)
    
    floatParam = ParamTypeSet['Float'].typeCast(param)
    
    if floatParam:
      return FloatParameterHandler(engine, floatParam, 'Float', parent)
    
    return None
  
  # Return QWidget which can control this parameter
  def getDisplayWidget(self, parent = None):
    return None
  
  def getDetailedDisplayWidget(self, parent = None):
    return None
  
  def getDisplayName(self):
    name = self.param.displayName()
    
    if len(name) == 0:
      name = self.param.name()
    return name
  
  def getName(self):
    name = self.param.name()
    return name
  
  def getDisplayValue(self, value = None):
    pass
  
  def set(self, value):
    r, v = self.param.get()
    
    if r and v == value:
      return [True, value]
    else:
      return self.setInternal(value)
    
  def get(self, refresh = False):
    return self.param.get(refresh)
  
  def setInternal(self, value):
    pass
  
  def getDescription(self):
    d = self.param.name()
    
    if self.param.ioType() == Voxel.Parameter.IO_READ_ONLY:
      d += " [RO]"
    elif self.param.ioType() == Voxel.Parameter.IO_WRITE_ONLY:
      d += " [WO]"
    else:
      d += " [RW]"
    
    displayName = self.param.displayName()
    
    if len(displayName):
      d += " " + displayName
      
    d += "\n\n"
    
    description = self.param.description()
    
    if len(description):
      d += description.replace('$', '\n') + "\n\n"
      
    if self.param.address():
      d += "Register: 0x%x [%d:%d]\n\n"%(self.param.address(), self.param.msb(), self.param.lsb())
      
    return d
  
class EnumParameterHandler(ParameterHandler):
  def __init__(self, engine, param, type, parent = None):
    super(EnumParameterHandler, self).__init__(engine, param, type, parent)
    
  def getDisplayValue(self, value = None):
    
    if not value:
      r, value = self.param.get()
    else:
      r = True
    
    if r:
      
      v = int(value)
      
      if isinstance(self, BoolParameterHandler):
        index = v
      else:
        values = self.param.allowedValues()
      
        i = 0
        index = -1
        
        for x in values:
          if x == value:
            index = i
            break
          i += 1
        
        
      if index < 0:
        value = "(Unknown)"
      else:
        valueMeanings = self.param.valueMeaning()
        
        if len(valueMeanings) > index and len(valueMeanings[index]):
          value = str(value) + " (" + valueMeanings[index] + ")"
        else:
          value = str(value)
    else:
      value = "(Unknown)"
    
    return value
  
  def allowedValues(self):
    return self.param.allowedValues()
  
  def getDisplayWidget(self, parent = None):
    a = self.allowedValues()
    valueMeanings = self.param.valueMeaning()
    displayValues = []
    for i in range(0, len(a)):
      
      value = a[i]
      
      if len(valueMeanings) > i and len(valueMeanings[i]):
        value = str(value) + " (" + valueMeanings[i] + ")"
      else:
        value = str(value)
        
      displayValues.append(value)
    
    
    r, value = self.param.get()
    
    if r:
      return EnumParameterView(a, displayValues, value, parent)
    else:
      return EnumParameterView(a, displayValues, a[0], parent)
  
  def setInternal(self, value):
    return self.engine.seti(self.param.name(), value)
  
  def getDescription(self):
    d = ParameterHandler.getDescription(self)
    
    r, value = self.param.get()
    
    if r:
      d += "Current Value: " + str(value) + "\n"
    
    d += "Possible Values: \n"
    
    a = self.allowedValues()
    valueMeanings = self.param.valueMeaning()
    valueDescription = self.param.valueDescription()
    displayValues = []
    for i in range(0, len(a)):
      
      value = a[i]
      
      if len(valueMeanings) > i and len(valueMeanings[i]):
        value = str(value) + " -> " + valueMeanings[i]
      else:
        value = str(value)
        
      if len(valueDescription) > i and len(valueDescription[i]):
        value += " (" + valueDescription[i] + ")\n"
      else:
        value += "\n"
        
      d += value
      
    return d
      

class BoolParameterHandler(EnumParameterHandler):
  def __init__(self, engine, boolParam, type, parent = None):
    super(BoolParameterHandler, self).__init__(engine, boolParam, type, parent)
    
  def allowedValues(self):
    return [False, True]
  
  def setInternal(self, value):
    return self.engine.setb(self.param.name(), value)
  
  def getDisplayValue(self, value = None):
    if isinstance(value, basestring):
      value = bool(value)
    return super(BoolParameterHandler, self).getDisplayValue(value)

    
class StrobeBoolParameterHandler(BoolParameterHandler):
  def __init__(self, engine, strobeBoolParam, type, parent = None):
    super(StrobeBoolParameterHandler, self).__init__(engine, strobeBoolParam, type, parent)
    
  def set(self, value):
    return self.engine.setb(self.param.name(), value)
    
class RangeParameterHandler(ParameterHandler):
  def __init__(self, engine, param, type, format, parent = None):
    super(RangeParameterHandler, self).__init__(engine, param, type, parent)
    self.format = format
    
  def getDisplayValue(self, value = None):
    
    if not value:
      r, value = self.param.get()
    else:
      r = True
    
    if r:
      unit = self.param.unit()
      
      s = self.format + '%s'
      value = s%(value, unit)
    else:
      value = "(Unknown)"
    
    return value
  
  def getDisplayWidget(self, parent = None):
    r, value = self.param.get()
    
    if not r:
      value = 0
    
    return RangeParameterView(self.param.lowerLimit(), self.param.upperLimit(), value, self.param.unit(), parent)
  
  def getDescription(self):
    d = ParameterHandler.getDescription(self)
    
    r, value = self.param.get()
    
    unit = self.param.unit()
    
    if r:
      d += "Current Value: " + str(value) + unit + "\n"
    
    d += "Limits: [" + str(self.param.lowerLimit()) + unit + ", " + str(self.param.upperLimit()) + unit + "]"
      
    return d
  
class IntegerParameterHandler(RangeParameterHandler):
  def __init__(self, engine, param, type, parent = None):
    super(IntegerParameterHandler, self).__init__(engine, param, type, '%d', parent)
    
  def setInternal(self, value):
    return self.engine.seti(self.param.name(), value)
  
  def getDetailedDisplayWidget(self, parent = None):
    return RangeParameterDetailedView(self, self.param.unit(), True, parent)

class UnsignedIntegerParameterHandler(RangeParameterHandler):
  def __init__(self, engine, param, type, parent = None):
    super(UnsignedIntegerParameterHandler, self).__init__(engine, param, type, '%u', parent)
    
  def setInternal(self, value):
    return self.engine.setu(self.param.name(), value)
  
  def getDetailedDisplayWidget(self, parent = None):
    return RangeParameterDetailedView(self, self.param.unit(), True, parent)
    
class FloatParameterHandler(RangeParameterHandler):
  def __init__(self, engine, param, type, parent = None):
    super(FloatParameterHandler, self).__init__(engine, param, type, '%.2f', parent)
    
  def setInternal(self, value):
    return self.engine.setf(self.param.name(), value)
  
  def getDetailedDisplayWidget(self, parent = None):
    return RangeParameterDetailedView(self, self.param.unit(), False, parent)
    
############# Parameter view classes
class EnumParameterView(QtGui.QComboBox):
  
  paramValueChanged = QtCore.Signal(object)
  
  def __init__(self, values, displayValues, current, parent = None):
    super(EnumParameterView, self).__init__(parent)
    self.values = values
    self.addItems(displayValues)
    
    for i in range(0, len(self.values)):
      if self.values[i] == current:
        self.setCurrentIndex(i)
        break
    
    self.setAutoFillBackground(True)
    self.setContentsMargins(0, 0, 0, 0)
    
    self.currentIndexChanged.connect(self.indexChanged)
    
  @QtCore.Slot(int)
  def indexChanged(self, index):
    if index < len(self.values):
      self.paramValueChanged.emit(self.values[self.currentIndex()])
    
  def getValue(self):
    if self.currentIndex() < len(self.values):
      return self.values[self.currentIndex()]
    
class RangeParameterView(QtGui.QWidget):
  
  paramValueChanged = QtCore.Signal(object)
  
  def __init__(self, minimum, maximum, current, unit, parent = None, flags = 0):
    super(RangeParameterView, self).__init__(parent)
    self.layout = QtGui.QHBoxLayout()
    
    if isinstance(minimum, numbers.Integral):
      self.spinbox = QtGui.QSpinBox()
      #self.spinbox.setSingleStep(max((maximum - minimum)/100, 1))
    else:
      self.spinbox = QtGui.QDoubleSpinBox()
      #self.spinbox.setSingleStep((maximum - minimum)/100)
      
    self.spinbox.setMinimum(minimum)
    self.spinbox.setMaximum(maximum)
    self.spinbox.setValue(current)
    
    self.spinbox.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)

    self.layout.addWidget(self.spinbox)
    
    if len(unit):
      self.layout.addWidget(QtGui.QLabel(unit))
      
    self.setLayout(self.layout)
    
    #self.spinbox.setFocusPolicy(QtCore.Qt.StrongFocus)
    self.spinbox.setFocus()
    
    self.setAutoFillBackground(True)
    self.setContentsMargins(0, 0, 0, 0)
    self.layout.setContentsMargins(0, 0, 0, 0)
    
    self.setFocusProxy(self.spinbox)
    
    self.oldStepBy = self.spinbox.stepBy
    self.spinbox.stepBy = partial(self.stepBy, self.spinbox)
    self.spinbox.editingFinished.connect(self.editFinished)
    
  def stepBy(self, spinbox, value):
    self.oldStepBy(value)
    self.paramValueChanged.emit(self.getValue())
      
  def editFinished(self):
    self.paramValueChanged.emit(self.getValue())
    
  def getValue(self):
    return self.spinbox.value()


### Detailed view classes

## Filter out and remove mouse wheel events on range sliders
class WheelEventFilter(QtCore.QObject):
  def __init__(self, parent = None):
    super(WheelEventFilter, self).__init__(parent)
    
  def eventFilter(self, obj, event):
    if event.type() == QtCore.QEvent.Wheel:
      event.ignore()
      return True
    else:
      return super(WheelEventFilter, self).eventFilter(obj, event)
      

class RangeParameterDetailedView(QtGui.QWidget):
  
  valueChanged = QtCore.Signal()
  
  def __init__(self, paramHandler, unit, isInteger, parent = None, flags = 0):
    super(RangeParameterDetailedView, self).__init__(parent)
    self.layout = QtGui.QHBoxLayout()
    
    self.paramHandler = paramHandler
    
    self.slider = QtGui.QSlider()
    self.slider.setOrientation(QtCore.Qt.Horizontal)
    self.slider.setMinimumWidth(100)
    self.slider.setSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Preferred)
    
    
    self.layout.addWidget(self.slider)
    
    if isInteger:
      self.spinbox = QtGui.QSpinBox()
    else:
      self.spinbox = QtGui.QDoubleSpinBox()
      
    self.slider.installEventFilter(WheelEventFilter(self))
    self.spinbox.installEventFilter(WheelEventFilter(self))
      
    #print minimum, maximum, isInteger, paramHandler.getName()
    
    self.layout.addWidget(self.spinbox)
    
    if len(unit):
      self.layout.addWidget(QtGui.QLabel(unit))
      
    self.setLayout(self.layout)
    
    self.slider.valueChanged.connect(self.updateSpinBox)
    self.spinbox.editingFinished.connect(self.updateParam)
    
    self.oldStepBy = self.spinbox.stepBy
    self.spinbox.stepBy = partial(self.stepBy, self.spinbox)
    self.init()
    
  def stepBy(self, spinbox, value):
    self.oldStepBy(value)
    self.updateParam()
  
  @QtCore.Slot()
  def init(self):
    minimum = self.paramHandler.param.lowerLimit()
    maximum = self.paramHandler.param.upperLimit()
    
    #print minimum, maximum
    
    self.spinbox.blockSignals(True)
    self.slider.blockSignals(True)
    self.spinbox.setRange(minimum, maximum)
    self.slider.setRange(int(minimum), int(maximum))
    self.spinbox.blockSignals(False)
    self.slider.blockSignals(False)
    
    r, v = self.paramHandler.get()
    
    if r:
      self.spinbox.blockSignals(True)
      self.slider.blockSignals(True)
      self.spinbox.setValue(v)
      self.slider.setValue(v)
      self.spinbox.blockSignals(False)
      self.slider.blockSignals(False)
      
  @QtCore.Slot()
  def updateSpinBox(self):
    self.spinbox.blockSignals(True)
    self.spinbox.setValue(self.slider.value())
    self.spinbox.blockSignals(False)
    self.updateParam()
    
  @QtCore.Slot()
  def updateParam(self):
    value = self.spinbox.value()
    self.slider.blockSignals(True)
    self.slider.setValue(int(value))
    self.slider.blockSignals(False)
    r, v = self.paramHandler.set(value)
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter set failed', 'Failed to set parameter "' + self.paramHandler.getName() + '"')
    else:
      self.valueChanged.emit()
      self.init()