#
# TI Voxel Viewer component.
#
# Inspired from http://stackoverflow.com/questions/19855288/duplicate-stdout-stderr-in-qtextedit-widget
# 
# Copyright (c) 2015 Texas Instruments Inc.
#

from PySide import QtGui, QtCore
import sys

class StreamWrapper(QtCore.QObject):
  outputWritten = QtCore.Signal(object)

  def __init__(self, parent, stdout = True):
    QtCore.QObject.__init__(self, parent)
    if stdout:
      self._stream = sys.stdout
      sys.stdout = self
    else:
      self._stream = sys.stderr
      sys.stderr = self

  def write(self, text):
    self._stream.write(text)
    self.outputWritten.emit(text)

  def __getattr__(self, name):
    return getattr(self._stream, name)

  def __del__(self):
    try:
      if self._stdout:
        sys.stdout = self._stream
      else:
        sys.stderr = self._stream
    except AttributeError:
      pass