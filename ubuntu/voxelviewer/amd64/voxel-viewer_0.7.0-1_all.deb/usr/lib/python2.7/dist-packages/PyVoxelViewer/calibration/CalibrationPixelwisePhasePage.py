#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from CalibrationWizard import CalibrationPage

from PyVoxelViewer.calibration.CalibrationDataCaptureDialog import CalibrationDataCaptureDialog

import Voxel

from PyVoxelViewer.views.DataView2D import DataView2D
from PyVoxelViewer.views.CustomViewBox import CustomViewBox

import struct

import pyqtgraph

import os

import numpy as np

import math

import cv2

#import matplotlib.pyplot as plt
#from mpl_toolkits.mplot3d import Axes3D
#from matplotlib import cm

class View2DMenu(QtGui.QMenu):
  
  def __init__(self, parent):
    super(View2DMenu, self).__init__(parent)
    
    self.resetAction = QtGui.QAction(QtGui.QIcon.fromTheme('reset'), '&Reset view', parent)
    self.resetAction.setShortcut('R')
    self.resetAction.triggered.connect(parent.resetView)
    self.addAction(self.resetAction)
    
    self.autoLevelsAction = QtGui.QAction(QtGui.QIcon.fromTheme('auto'), '&Update Thresholds', parent)
    self.autoLevelsAction.setShortcut('A')
    self.autoLevelsAction.triggered.connect(parent.autoLevels)
    self.addAction(self.autoLevelsAction)


class CalibrationPixelWisePhasePage(CalibrationPage):
  
  PHASE_FILE_NAME = 'phase-offset-file.npy'
  MAX_PHASE_VALUE = 4096
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationPixelWisePhasePage, self).__init__(calibrationWizard, index, parent = parent, 
          definingParams = definingParams, calibParams = calibParams)
          
    self.calibrationWizard = calibrationWizard
    
    self.setTitle('Pixelwise Phase Calibration')
    self.setSubTitle('Phase offset computation per pixel.\nClick on calibrate to capture ' + 
                     'average phase image\n of a uniform wall and compute necessary per-pixel phase offset.')
    
    self.layout = QtGui.QVBoxLayout(self)
    
    self.setMinimumHeight(200)
    self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addStretch()
    self.calibrateButton = QtGui.QPushButton('&Calibrate')
    self.calibrateButton.setShortcut('Alt+C')
    self.calibrateButton.pressed.connect(self.capturePhaseData)
    hlayout.addWidget(self.calibrateButton)
    hlayout.addStretch()
    
    self.layout.addLayout(hlayout)
    
    groupbox = QtGui.QGroupBox()
    self.layout.addWidget(groupbox)
    groupbox.setTitle('Phase Offset')
    
    vglayout = QtGui.QVBoxLayout()
    
    groupbox.setLayout(vglayout)
    
    self.graphicsWidget = pyqtgraph.GraphicsLayoutWidget()
    
    self.viewBox = CustomViewBox()
    self.graphicsWidget.addItem(self.viewBox)
    
    self.imageItem = pyqtgraph.ImageItem()
    self.levels = [-2048.0, 2047.0]
    pos = np.array([0., 0.25, 0.50, 0.75, 1.])*(self.levels[1] - self.levels[0]) + self.levels[0]
    color = np.array([[255,0,0,255], [255,255,0,255], [0,255,0,255], [0,255,255,255], [0,0,255,255]], dtype=np.uint16)
    self.cmap = pyqtgraph.ColorMap(pos, color)
    self.colorMap = self.cmap.getLookupTable(self.levels[0], self.levels[1], self.levels[1], alpha = True, mode='byte')
    self.imageItem.setLookupTable(self.colorMap)
    self.viewBox.addItem(self.imageItem)
    
    vglayout.addWidget(self.graphicsWidget)
    
    self.pointLabel = QtGui.QLabel()
    self.layout.addWidget(self.pointLabel)
    self.pointLabel.setAlignment(QtCore.Qt.AlignRight)
    
    self.viewBox.resetView.connect(self.resetView)
    self.viewBox.autoHistogram.connect(self.autoLevels)
    self.setFocusProxy(self.graphicsWidget)
    
    self.graphicsWidget.scene().sigMouseMoved.connect(self.getMousePosition)
    
    self.menu = View2DMenu(self)
    self.viewBox.setMenu(self.menu)
    
    self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
    
    self.frameSize = None
    self.calibrated = False
    
    r, self.dealiasEnabled = self.depthCamera.getb('dealias_en')
    r1, self.dealiased16BitEnabled = self.depthCamera.getb('dealias_16bit_op_enable')
    r2, self.currentDealiasedPhaseMask = self.depthCamera.geti('dealiased_ph_mask')
    r3, ma = self.depthCamera.getu('ma')
    r4, mb = self.depthCamera.getu('mb')
    if not r or not r1 or not r2 or not r3 or not r4:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not read dealiasing related parameters')
      return
    
    if not self.dealiasEnabled:
      self.dealiasedPhaseMask = 0
    else:
      if self.dealiased16BitEnabled:
        self.dealiasedPhaseMask = int(np.log2(2.0/min(ma, mb)))
      else:
        self.dealiasedPhaseMask = int(np.log2(32.0/min(ma, mb)))
    
  def getMousePosition(self, pos):
    p = self.imageItem.mapFromScene(pos)
    
    if self.frameSize != None:
      if p.x() < 0 or p.x() >= self.frameSize[0] or p.y() < 0 or p.y() >= self.frameSize[1]:
        return
      
      x = int(p.x())
      y = int(p.y())
      
      self.pointLabel.setText('Current point (%d, %d). Phase offset = %d'%(x, y, self.deltaPhase[y, x]))
    
  @QtCore.Slot()
  def resetView(self):
    self.viewBox.autoRange()
    self.autoLevels()
    
  def autoLevels(self):
    
    b, h = self.imageItem.getHistogram(bins = 100)
    
    if h == None or b == None:
      return
    
    h = (h - DataView2D.HISTOGRAM_THRESHOLD).clip(0)
    
    i = np.nonzero(h)
    
    self.imageItem.setLevels([b[i[0][0]], b[i[0][-1]]])
    
  def initializePage(self):
    c = Voxel.Configuration()
    r, self.phaseOffsetFileName = c.getLocalConfFile(self.depthCamera.name() + \
      self.calibrationWizard.currentProfileName.replace(' ', '') + "PhaseOffset.bin")
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Path failed', 'Failed to get path for offset file name')
      return
    
    print 'Phase offset file name = ', self.phaseOffsetFileName
    
    super(CalibrationPixelWisePhasePage, self).initializePage()
    self.calibrate()
    
  def capturePhaseData(self):
    fileName = self.basePath + os.sep + CalibrationPixelWisePhasePage.PHASE_FILE_NAME
    
    r = self.depthCamera.seti('dealiased_ph_mask', self.dealiasedPhaseMask)
      
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not set "dealiased phase mask" parameter')
      return
    
    data = CalibrationDataCaptureDialog.showDialog(self.calibrationWizard.cameraSystem, \
      self.depthCamera, fileName,\
      'phase', 200)
    
    r = self.depthCamera.seti('dealiased_ph_mask', self.currentDealiasedPhaseMask)
      
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not reset "dealiased phase mask" parameter')
      return
      
    if data == None:
      return
    
    self.calibrate()
    
  def computeDirectionCosines(self):
    fx = self.fx = self.calibrationWizard.currentConfiguration.getFloat('calib', 'fx')
    fy = self.fy = self.calibrationWizard.currentConfiguration.getFloat('calib', 'fy')
    cx = self.cx = self.calibrationWizard.currentConfiguration.getFloat('calib', 'cx')
    cy = self.cy = self.calibrationWizard.currentConfiguration.getFloat('calib', 'cy')
    k1 = self.calibrationWizard.currentConfiguration.getFloat('calib', 'k1')
    k2 = self.calibrationWizard.currentConfiguration.getFloat('calib', 'k2')
    k3 = self.calibrationWizard.currentConfiguration.getFloat('calib', 'k3')
    p1 = self.calibrationWizard.currentConfiguration.getFloat('calib', 'p1')
    p2 = self.calibrationWizard.currentConfiguration.getFloat('calib', 'p2')
    
    self.cGrid = np.mgrid[0:self.rows,0:self.columns].astype(np.float32) #create a grid of indices
    self.shape = [self.rows, self.columns]
    
    self.cGrid1d = np.reshape(np.transpose(self.cGrid, (1, 2, 0)), (self.rows*self.columns, 1, 2)).astype(np.float32)
    
    print self.cGrid1d.shape
    
    self.cGridCorrected1d = cv2.undistortPoints(self.cGrid1d, np.array([[fy, 0, cy], [0, fx, cx], [0, 0, 1]]), np.array([k1, k2, p1, p2, k3]))
    self.cGridCorrected = np.transpose(np.reshape(self.cGridCorrected1d, (self.rows, self.columns, 2)), (2, 0, 1))
    
    ry = self.cGridCorrected[0]
    rx = self.cGridCorrected[1]
    
    # Uncomment to get undistortion mapping
    #with open('temp2.txt', 'w') as f:
      #for r in range(0, self.rows):
        #for c in range(0, self.columns):
          #f.write('(%d, %d) -> (%.2f, %.2f)\n'%(self.cGrid[1, r, c], self.cGrid[0, r, c], rx[r, c], ry[r, c]))
        
    rad2DSquare = ((rx**2) + (ry**2))
    rad2D = rad2DSquare**0.5 #calculate the distance of each pixel from the center pixel

    self.cosA = 1/((rad2DSquare + 1)**0.5)
    #self.sinA = rad2D/((rad2DSquare + 1)**0.5)
    #self.sinB = ry/rad2D
    #self.cosB = rx/rad2D
    #self.sinB[int(cy),int(cx)] = 1
    #self.cosB[int(cy),int(cx)] = 1 
    
  def calibrate(self):
    
    fileName = self.basePath + os.sep + CalibrationPixelWisePhasePage.PHASE_FILE_NAME
    
    if not os.path.exists(fileName):
      return
    
    lensCorrectedPhase = np.load(fileName)
    
    self.rows = lensCorrectedPhase.shape[0]
    self.columns = lensCorrectedPhase.shape[1]
    
    self.computeDirectionCosines()
    
    deltaPhase = lensCorrectedPhase - lensCorrectedPhase[self.cy, self.cx]/self.cosA
    
    try:
      with open(self.phaseOffsetFileName, 'wb') as f:
        f.write(struct.pack('H', self.rows))
        f.write(struct.pack('H', self.columns))
        f.write(struct.pack('H', np.uint16(self.dealiasedPhaseMask) & 0x000F))
        np.reshape(deltaPhase, self.rows*self.columns).astype(np.short).tofile(f)
    except IOError, e:
      QtGui.QMessageBox.critical(self, 'Phase Offset', 'Could not save to file "' + self.phaseOffsetFileName + '"')
    
    x = (np.linspace(0, self.columns, self.columns) - self.cx)
    y = (np.linspace(0, self.rows, self.rows) - self.cy)
    
    self.frameSize = [self.columns, self.rows]
    self.deltaPhase = deltaPhase
    
    self.imageItem.setImage(deltaPhase.T, levels = self.levels)
    self.resetView()
    
    #fig = plt.figure()
    #ax1 = fig.add_subplot(121, projection='3d')
    #ax1.set_title("Z-distance vs pixels")
    #ax1.plot_surface(self.cGrid[0],self.cGrid[1],deltaPhase,cmap=cm.jet)
    #ax1.set_zlim([-4096, 4096])

    #ax2 = fig.add_subplot(122, projection='3d')
    #ax2.set_title("Radial distance offset vs pixels")
    #ax2.plot_surface(self.cGrid[0], self.cGrid[1], 1/self.cosA, cmap=cm.jet)
    #ax2.set_zlim([-1, 1])
    #plt.show()


    self.calibParams['phasecorrection'] = CalibrationPage.FILE_PREFIX + os.path.basename(self.phaseOffsetFileName)
    
    self.calibrated = True
    self.completeChanged.emit()
    
  def isComplete(self):
    return self.calibrated
