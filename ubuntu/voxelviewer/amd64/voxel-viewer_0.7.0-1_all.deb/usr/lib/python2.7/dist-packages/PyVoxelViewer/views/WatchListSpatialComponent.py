#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

from PyVoxelViewer.views.DataView import DataView

from XYSpinBox import XYSpinBox

import string
import os

import numpy as np

class SpatialWatchListModel(QtCore.QAbstractTableModel):
  def __init__(self, dataEngine, x1, x2, y1, y2):
    super(SpatialWatchListModel, self).__init__()
    
    self.sectionNames = ["Average", "Std"]
    
    self.dataEngine = dataEngine
    
    self.dataEngine.statisticsChanged.connect(self.getWatchListKeys)
    
    self.getWatchListKeys()
    
    self.watchListElements = {}
    
    self.dataEngine.connectData("depth", self.updateElements, QtCore.Qt.QueuedConnection)
    
    self.setSpatialLimits(x1, x2, y1, y2)
    
  def setSpatialLimits(self, x1, x2, y1, y2):
    self.x1 = x1
    self.x2 = x2
    self.y1 = y1
    self.y2 = y2
    
  @QtCore.Slot(object, object, object)
  def updateElements(self, id, timestamp, frame):
    for w in self.watchListRows:
      try:
        d = self.dataEngine.data[w][self.y1:self.y2, self.x1:self.x2]
        self.watchListElements[w] = ['%7.2f'%np.mean(d), '%7.2f'%np.std(d)]
      except Exception, e:
        pass
    
  def getWatchListKeys(self):
    if self.dataEngine.isStatisticsEnabled:
      self.watchListRows = ['ambient', 'amplitude_avg', 'phase_avg', 'depth_avg', 'distance']
    else:
      self.watchListRows = ['ambient', 'amplitude', 'phase', 'depth', 'distance']
    
  def getWatchElementString(self, index):
    if index < 0 or index >= len(self.watchListRows):
      return None
    
    w = self.watchListRows[index]
    
    if self.watchListElements.has_key(w):
      return w + ' -> avg:' + self.watchListElements[w][0] + ', std:' + self.watchListElements[w][1]
    else:
      return ''
    
  def getHeaderCSVString(self):
    return ';avg;std'
    
  def flags(self, index):
    f = super(SpatialWatchListModel, self).flags(index)
    return f | QtCore.Qt.ItemIsSelectable
    
  def rowCount(self, parent = QtCore.QModelIndex()):
    return len(self.watchListRows)
  
  def columnCount(self, parent = QtCore.QModelIndex()):
    return 2
  
  def data(self, index, role = QtCore.Qt.DisplayRole):
    
    if role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      w = self.watchListRows[index.row()]
      
      if not self.watchListElements.has_key(w):
        return None
      
      if index.column() == 0:
        return self.watchListElements[w][0]
      elif index.column() == 1:
        return self.watchListElements[w][1]
      else:
        return None
  
  def headerData(self, section, orientation, role = QtCore.Qt.DisplayRole):
    if role == QtCore.Qt.DisplayRole:
      if orientation == QtCore.Qt.Horizontal:
        if section < len(self.sectionNames):
          return self.sectionNames[section]
        else:
          return None
      else:
        if section < len(self.watchListRows):
          return self.watchListRows[section]
        else:
          return None
    elif role == QtCore.Qt.InitialSortOrderRole:
      return QtCore.Qt.AscendingOrder
    else:
      return None

class SpatialWatchListDelegate(QtGui.QAbstractItemDelegate):
  def __init__(self, tableView, dataEngine):
    super(SpatialWatchListDelegate, self).__init__()
    
    self.tableView = tableView
    
    self.dataEngine = dataEngine
    
  def paint(self, painter, option, index):
    if option.state & QtGui.QStyle.State_Selected:
      if option.state & QtGui.QStyle.State_Active:
        painter.setBrush(QtGui.QBrush(self.tableView.palette().highlight()))
      else:
        painter.setBrush(QtGui.QBrush(self.tableView.palette().color(QtGui.QPalette.Inactive, QtGui.QPalette.Highlight)))
      painter.drawRect(option.rect)
    painter.drawText(option.rect, QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter, index.data())
  
  def sizeHint(self, option, index):
    return option.rect.size() # Occupy full size
  
class SpatialWatchTableView(QtGui.QTableView):
  def __init__(self, dataEngine, parent = None):
    super(SpatialWatchTableView, self).__init__(parent)
    self.dataEngine = dataEngine
    self.model = SpatialWatchListModel(self.dataEngine, 0, 0, 0, 0)
    self.currentRow = -1
    
    self.watchListDelegate = SpatialWatchListDelegate(self, dataEngine)
    self.setItemDelegate(self.watchListDelegate)
    self.setModel(self.model)
    
    self.horizontalHeader().setResizeMode(QtGui.QHeaderView.Stretch)
    self.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
    self.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
    
    self.dataEngine.connectData("depth", self.modelChanged, QtCore.Qt.QueuedConnection)
    
    self.menu = QtGui.QMenu(self)
    
    copyAction = QtGui.QAction('Copy to clipboard', self)
    copyAction.triggered.connect(self.copySpatialWatchListElement)
    
    saveAction = QtGui.QAction('Save all to CSV', self)
    saveAction.triggered.connect(self.saveWatchList)
    
    self.menu.addAction(copyAction)
    self.menu.addAction(saveAction)
    self.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
    
  def contextMenuEvent(self, event):
    self.menu.popup(event.globalPos())
    
  @QtCore.Slot()
  def copySpatialWatchListElement(self):
    s = self.model.getWatchElementString(self.currentRow)
    print s
    if s:
      c = QtGui.QApplication.clipboard()
      c.setText(s)
      self.currentRow = -1
    else:
      QtGui.QMessageBox.critical(self, 'Watch List Element', 'Failed to copy watch list element')
      
  @QtCore.Slot()
  def saveWatchList(self):
    
    s = 'sep=;\n' + self.model.getHeaderCSVString() + '\n'
    
    for k in self.model.watchListRows:
      if not self.model.watchListElements.has_key(k):
        continue
      
      w = self.model.watchListElements[k]
      s += k + ";" + w[0] + ";" + w[1] + '\n'
    
    filename, _ = QtGui.QFileDialog.getSaveFileName(self, 'Save CSV to file', filter = "CSV files (*.csv)")
    
    if filename:
      try:
        print 'Saving CSV to file ', filename, '...'
        f = open(filename, 'w')
        f.write(s)
        f.close()
        print 'Done'
      except IOError, e:
        QtGui.QMessageBox.critical('Save CSV to file', 'Failed to save CSV to file ' + filename)
    
  @QtCore.Slot(object, object, object)
  def modelChanged(self, id, timestamp, frame):
    self.model.reset()
    
  def mousePressEvent(self, e):
    super(SpatialWatchTableView, self).mousePressEvent(e)
    self.currentRow = self.currentIndex().row()
    
    
class SpatialWatchListView(QtGui.QWidget):
  
  def __init__(self, dataEngine, parent = None):
    super(SpatialWatchListView, self).__init__(parent)
    
    self.setMaximumWidth(300)
    self.setMinimumWidth(300)
    
    self.dataEngine = dataEngine
    
    vlayout = QtGui.QVBoxLayout(self)
    
    l = QtGui.QLabel('Spatial Statistics')
    l.setAlignment(QtCore.Qt.AlignCenter)
    l.setStyleSheet('font-weight: 500;')
    
    vlayout.addWidget(l)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('From:'))
    self.topLeft = XYSpinBox()
    hlayout.addWidget(self.topLeft)
    
    hlayout.addWidget(QtGui.QLabel(' to:'))
    self.bottomRight = XYSpinBox()
    hlayout.addWidget(self.bottomRight)
    
    vlayout.addLayout(hlayout)
    
    
    self.topLeft.xSpinBox.valueChanged.connect(self.setSpatialLimits)
    self.topLeft.ySpinBox.valueChanged.connect(self.setSpatialLimits)
    self.bottomRight.xSpinBox.valueChanged.connect(self.setSpatialLimits)
    self.bottomRight.ySpinBox.valueChanged.connect(self.setSpatialLimits)
    
    self.tableView = SpatialWatchTableView(dataEngine)
    
    vlayout.addWidget(self.tableView)
    
    self.width = self.height = 0
    
    self.setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Preferred)
    
    self.dataEngine.getDepthCameraController().started.connect(self.prepareToResetRange)
    
    DataView.communicator.viewRangeChanged.connect(self.setSpatialCoordinates)
    
  def prepareToResetRange(self):
    self.dataEngine.connectData("phase", self.updateRanges, QtCore.Qt.QueuedConnection)
    
  def disconnectResetRange(self):
    self.dataEngine.disconnectData("phase", self.updateRanges)
    
  def setSpatialCoordinates(self, x1, y1, x2, y2):
    if x2 < x1 or y2 < y1:
      return
    
    self.topLeft.setRange(0, x2, 0, y2)
    self.bottomRight.setRange(x1, self.width - 1, y1, self.height - 1)
    self.topLeft.setXY(x1, y1)
    self.bottomRight.setXY(x2, y2)
    self.tableView.model.setSpatialLimits(x1, x2, y1, y2)
    
  def setSpatialLimits(self):
    x1, y1 = self.topLeft.getXY()
    x2, y2 = self.bottomRight.getXY()
    self.topLeft.setRange(0, x2, 0, y2)
    self.bottomRight.setRange(x1, self.width - 1, y1, self.height - 1)
    self.tableView.model.setSpatialLimits(x1, x2, y1, y2)
    
  @QtCore.Slot(object, object, object)
  def updateRanges(self, id, timestamp, frame):
    self.width, self.height = self.dataEngine.data['phase'].shape
    
    self.topLeft.setRange(0, self.width - 1, 0, self.height - 1)
    self.topLeft.setXY(0, 0)
    self.bottomRight.setRange(0, self.width - 1, 0, self.height - 1)
    self.bottomRight.setXY(self.width - 1, self.height - 1)
    
    self.setSpatialLimits()
    try:
      self.disconnectResetRange()
    except Exception, e:
      pass
      