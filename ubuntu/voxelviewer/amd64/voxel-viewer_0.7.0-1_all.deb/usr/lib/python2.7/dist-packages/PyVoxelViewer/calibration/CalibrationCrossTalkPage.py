#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui
from CalibrationWizard import CalibrationPage

from PyVoxelViewer.models.DepthCameraStreamController import DepthCameraStreamController
from PyVoxelViewer.models.DataEngine import DataEngine
from PyVoxelViewer.views.DataViewContainer import DataViewContainer

import os
import csv

import math

import numpy as np

import Voxel

class CalibrationCrossTalkPage(CalibrationPage):
  
  MAX_PHASE_VALUE = 4096
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationCrossTalkPage, self).__init__(calibrationWizard, index, parent = parent, 
          definingParams = definingParams, calibParams = calibParams)
          
    self.calibrationWizard = calibrationWizard
    
    self.setTitle('Cross-talk Calibration')
    self.setSubTitle('Cross-talk coefficients computation. Please point to a flat wall.')
    
    self.layout = QtGui.QVBoxLayout(self)
    
    self.setMinimumHeight(200)
    self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
    
    hlayout = QtGui.QHBoxLayout()
    
    self.calibrateButton = QtGui.QPushButton('&Calibrate')
    self.calibrateButton.pressed.connect(self.calibrate)
    self.calibrateButton.setShortcut('Alt+C')
    hlayout.addWidget(self.calibrateButton)
    
    self.layout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    self.numberOfFrames = 200
    hlayout.addWidget(QtGui.QLabel('Number of frames to capture: '))
    self.frameCount = QtGui.QSpinBox()
    self.frameCount.setRange(50, 500)
    self.frameCount.setValue(self.numberOfFrames)
    self.frameCount.valueChanged.connect(self.setNumberOfFrames)
    hlayout.addWidget(self.frameCount)
    hlayout.addStretch()
    
    self.layout.addLayout(hlayout)
    
    self.depthCameraController = DepthCameraStreamController(self.calibrationWizard.cameraSystem, None)
    self.dataEngine = DataEngine(self.depthCameraController)
    self.dataEngine.disableStatistics()
    
    self.captureRunning = False
    self.dataEngine.connectData("phase", self.computeAverage, QtCore.Qt.QueuedConnection)
    
    self.dataView = DataViewContainer(self.dataEngine, 'phase', shouldLinkViewBox = False, showFormatMenu = True)
    
    self.layout.addWidget(self.dataView)
    
    self.progressBar = QtGui.QProgressBar()
    self.currentProgressValue = 0
    self.progressBar.setValue(0)
    
    self.layout.addWidget(self.progressBar)
    
    self.progressText = QtGui.QLabel()
    self.layout.addWidget(self.progressText)
    
    self.paramsGroupbox = QtGui.QGroupBox()
    self.paramsGroupbox.setTitle('Cross-talk Parameters')
    self.layout.addWidget(self.paramsGroupbox)
    
    self.paramsText = QtGui.QLabel()
    
    vglayout = QtGui.QVBoxLayout()
    vglayout.addWidget(self.paramsText)
    self.paramsGroupbox.setLayout(vglayout)
    
    self.paramsGroupbox.hide()
    
    self.dataView.dataView.graphicsWidget.scene().sigMouseMoved.connect(self.getMousePosition)
    
    self.calibrated = False
    self.frameSize = None
    self.phaseData = None
    
  def setNumberOfFrames(self, value):
    self.numberOfFrames = value
    
  def isComplete(self):
    return self.calibrated
  
  def enterPage(self):
    super(CalibrationCrossTalkPage, self).enterPage()
    self.depthCameraController.setDepthCamera(self.calibrationWizard.depthCamera)
    self.depthCameraController.start()
    
  def leavePage(self):
    self.depthCameraController.stop()
    
  def setProgress(self, progressIncrement, progressMessage = None):
    self.currentProgressValue += progressIncrement
    self.progressBar.setValue(self.currentProgressValue)
    
    if progressMessage != None:
      self.progressText.setText(progressMessage)
      
  def closePage(self):
    self.dataEngine.stop()
    
  def validatePage(self):
    r = super(CalibrationCrossTalkPage, self).validatePage()
    
    if r:
      self.depthCameraController.disconnectDepthCamera(onlyFromUI = True)
      
    return r
    
  @QtCore.Slot(object, object, object)
  def computeAverage(self, id, timestamp, frame):
    
    if not self.captureRunning:
      return
    
    self.phaseData = self.dataEngine.data['phase']*math.pi/2048
    self.amplitudeData = self.dataEngine.data['amplitude']
    
    self.frameSize = [self.phaseData.shape[1], self.phaseData.shape[0]]
    
    if self.currentFrameCount == 0:
      r = r1 = False
      if self.dealiasEnabled:
        if self.average1 == None:
          r = self.depthCamera.setb('ind_freq_data_en', True)
          r1 = self.depthCamera.setb('ind_freq_data_sel', False)
          self.setProgress(0, 'Computing cross-talk coefficients for first modulation frequency...')
        else:
          r = self.depthCamera.setb('ind_freq_data_en', True)
          r1 = self.depthCamera.setb('ind_freq_data_sel', True)
          self.skipFrameTotalCount = 30
          self.setProgress(0, 'Computing cross-talk coefficients for second modulation frequency...')
      else:
        r = r1 = True
        
      if not r or not r1:
        self.stopCalibration()
    
    if self.skipFrameCount < self.skipFrameTotalCount:
      self.skipFrameCount += 1
      self.currentFrameCount += 1
      return
    
    if self.average == None:
      self.average = np.zeros(self.phaseData.shape, dtype='complex')
    
    self.average += np.array(self.amplitudeData)*(np.cos(self.phaseData) + 1j*np.sin(self.phaseData))
    
    self.currentFrameCount += 1
    self.setProgress(self.progressPercentage/self.numberOfFrames, None)
    
    if self.currentFrameCount >= self.numberOfFrames + self.skipFrameTotalCount:
      self.average /= self.numberOfFrames
      
      if not self.dealiasEnabled:
        self.average1 = self.average
        self.average = None
        self.currentFrameCount = 0
        self.finishCalibration()
      elif self.average1 != None:
        self.average2 = self.average
        self.average = None
        self.finishCalibration()
      else:
        self.average1 = self.average
        self.average = None
        self.currentFrameCount = 0
        
  def getMousePosition(self, pos):
    p = self.dataView.dataView.imageItem.mapFromScene(pos)
    
    if self.dataEngine.frameSize != None and self.phaseData != None:
      if p.x() < 0 or p.x() >= self.frameSize[0] or p.y() < 0 or p.y() >= self.frameSize[1]:
        return
      
      x = int(p.x())
      y = int(p.y())
      
      self.progressText.setText('Current point (%d, %d). Phase = %d'%(x, y, self.phaseData[y, x]))
      
  def calibrate(self):
    r, dealiasEnabled = self.depthCamera.getb('dealias_en')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not read "dealias_en" parameter')
      return
    
    self.dealiasEnabled = dealiasEnabled
    
    if self.dealiasEnabled:
      self.progressPercentage = 50.0
    else:
      self.progressPercentage = 100.0
    
    self.average = None
    self.average1 = self.average2 = None
    self.currentFrameCount = 0
    self.skipFrameTotalCount = 0
    self.skipFrameCount = 0
    self.captureRunning = True
    self.currentProgressValue = 0
    self.calibrateButton.setDisabled(True)
    
  def stopCalibration(self):
    self.average = None
    self.captureRunning = False
    self.currentProgressValue = 0
    self.progressBar.setValue(0)
    self.calibrateButton.setEnabled(True)
    
    r = self.depthCamera.setb('ind_freq_data_en', False)
    
  def extractImpulseResponse(self, average):
    amplitudeAverage = np.abs(average)
    phaseAverage = np.angle(average)
    
    # get the location of impulse
    highPassFilt = np.array([[-0.1,-0.2,-0.1],
                             [-0.2  , 1,-0.2],
                             [-0.1,-0.2,-0.1]])
    
    hpf = Voxel.FloatVector()
    hpf.resize(9)
    
    i = np.array(hpf, copy = False)
    np.copyto(i, highPassFilt.reshape((9)).astype(np.float32))
    
    conv = Voxel.Convolve2D(hpf, 3, 3)
    
    s = amplitudeAverage.shape
    inVec = Voxel.FloatVector()
    inVec.resize(s[0]*s[1])
    
    i = np.array(inVec, copy = False)
    np.copyto(i, amplitudeAverage.reshape((s[0]*s[1])).astype(np.float32))
    
    r, filtered = conv.convolve(inVec, s[0], s[1])
    
    highPassFiltered = np.array(filtered).reshape((s[0], s[1]))
    
    index = np.unravel_index(np.argmax(highPassFiltered), highPassFiltered.shape)

    print "CalibrationCrossTalkPage: Looks like impulse is here - ", index
    
    y = index[0]
    x = index[1]
    
    #print amplitude[y-2:y+3,x-2:x+3]
    phaseOffset = phaseAverage[y, x]
    amplitudeOffsetArray = np.zeros((7,7))
    amplitudeOffsetArray[:,:] = amplitudeAverage[y - 3:y + 4,x - 3:x + 4]
    amplitudeOffsetArray[1:6,1:6] = 0
    amplitudeOffset = np.sum(amplitudeOffsetArray)
    amplitudeOffset /= 2*(7 + 5)
    
    correctedAmplitude = amplitudeAverage[y - 2:y + 3,x - 2:x + 3]-amplitudeOffset
    correctedAmplitude[correctedAmplitude < 0] = 0
    correctedPhase = phaseAverage[y - 2:y + 3,x - 2:x + 3] - phaseOffset
            
    resp = correctedAmplitude*(np.cos(correctedPhase) + 1j*np.sin(correctedPhase))
    
    resp = (resp[:,::-1] + resp)
    resp = (resp[::-1,:] + resp)
    
    sum = np.sum(np.abs(resp))
    impulseResp = resp/sum
    
    return impulseResp
  
  def calculateInverse(self, response):
    s = self.average1.shape
    
    width = 1 << (s[1] - 1).bit_length() # Nearest power of 2 greater than width (E.g.: For 320, this will be 512)
    hWidth = width/2
    
    #put the pattern into a big array (array should be bigger than the sensor's longest rectilinear dimension)
    spatialResp = np.zeros((width, width)) + 1j*np.zeros((width, width))
    spatialResp[hWidth - 2:hWidth + 3,hWidth - 2:hWidth + 3] = response

    spatialFFT = np.fft.fft2(np.fft.ifftshift(spatialResp))
    spatialFFTInverse = 1.0/spatialFFT
    spatialInverse = np.fft.fftshift(np.fft.ifft2(spatialFFTInverse))
    
    localSpatialInverse = spatialInverse[hWidth - 2:hWidth + 3,hWidth - 2:hWidth + 3]
    
    #sum = np.sum(np.abs(localSpatialInverse))
    #localSpatialInverse = localSpatialInverse/sum
    
    localSpatialInverse = localSpatialInverse[1:4, 1:4]/localSpatialInverse[2, 2]
    
    print 'CalibrationCrossTalkPage: Full coefficient matrix of cross talk filter =\n', localSpatialInverse
    
    return localSpatialInverse

    
  def finishCalibration(self):
    self.stopCalibration()
    
    if self.average1 == None or (self.dealiasEnabled and self.average2 == None):
      QtGui.QMessageBox.critical(self, 'Data Missing', 'Cannot perform calibration with missing data')
      return
    
    response = self.extractImpulseResponse(self.average1)
    crossTalkCoeff = self.calculateInverse(response)
    
    crossTalkCoeff[-1:1,-1:1] = 0
    
    self.calibParams['x_filt_coeff_f1'] = '(' + str(crossTalkCoeff[1, 0].real) + ', ' + str(crossTalkCoeff[1, 0].imag) + ')'
    self.calibParams['y_filt_coeff_f1'] = '(' + str(crossTalkCoeff[0, 1].real) + ', ' + str(crossTalkCoeff[0, 1].imag) + ')'
    
    if self.dealiasEnabled:
      response = self.extractImpulseResponse(self.average2)
      crossTalkCoeff = self.calculateInverse(response)
    
      crossTalkCoeff[-1:1,-1:1] = 0
    
      self.calibParams['x_filt_coeff_f2'] = '(' + str(crossTalkCoeff[1, 0].real) + ', ' + str(crossTalkCoeff[1, 0].imag) + ')'
      self.calibParams['y_filt_coeff_f2'] = '(' + str(crossTalkCoeff[0, 1].real) + ', ' + str(crossTalkCoeff[0, 1].imag) + ')'
      
      self.paramsText.setText('x_filt_coeff_f1 = %s,\n y_filt_coeff_f1 = %s,\n x_filt_coeff_f2 = %s,\n y_filt_coeff_f2 = %s\n'\
        %(self.calibParams['x_filt_coeff_f1'], self.calibParams['y_filt_coeff_f1'],\
          self.calibParams['x_filt_coeff_f2'], self.calibParams['y_filt_coeff_f2']))
      
    else:
      self.calibParams['x_filt_coeff_f2'] = self.calibParams['y_filt_coeff_f2'] = '(0, 0)'
      self.paramsText.setText('x_filt_coeff = %s,\ny_filt_coeff = %s\n'\
        %(self.calibParams['x_filt_coeff_f1'], self.calibParams['y_filt_coeff_f1']))
    
    self.paramsGroupbox.show()
    self.calibrated = True
    
    self.completeChanged.emit()