#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui
from CalibrationWizard import CalibrationPage, c

from PyVoxelViewer.models.DepthCameraStreamController import DepthCameraStreamController
from PyVoxelViewer.models.DataEngine import DataEngine
from PyVoxelViewer.views.DataViewContainer import DataViewContainer

import os
import csv

import math

import numpy as np

class CalibrationCommonPhasePage(CalibrationPage):
  
  MAX_PHASE_VALUE = 4096
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationCommonPhasePage, self).__init__(calibrationWizard, index, parent = parent, 
          definingParams = definingParams, calibParams = calibParams)
          
    self.calibrationWizard = calibrationWizard
    
    self.setTitle('Common Phase Calibration')
    self.setSubTitle('Common phase offset computation. Please measure the phase value at cx, cy')
    
    self.layout = QtGui.QVBoxLayout(self)
    
    self.setMinimumHeight(200)
    self.setSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
    
    hlayout = QtGui.QHBoxLayout()
    self.centerPointText = QtGui.QLabel()
    hlayout.addWidget(self.centerPointText)
    
    hlayout.addStretch()
    
    self.calibrateButton = QtGui.QPushButton('&Calibrate')
    self.calibrateButton.pressed.connect(self.calibrate)
    self.calibrateButton.setShortcut('Alt+C')
    hlayout.addWidget(self.calibrateButton)
    
    self.layout.addLayout(hlayout)
    
    hlayout = QtGui.QHBoxLayout()
    
    hlayout.addWidget(QtGui.QLabel('Distance from flat surface: '))
    
    self.distance = QtGui.QDoubleSpinBox()
    self.distance.setRange(0.1, 50)
    self.distance.setSingleStep(0.001)
    self.distance.setDecimals(3)
    hlayout.addWidget(self.distance)
    hlayout.addWidget(QtGui.QLabel('m'))
    hlayout.addStretch()
    self.layout.addLayout(hlayout)
    
    
    hlayout = QtGui.QHBoxLayout()
    self.numberOfFrames = 200
    hlayout.addWidget(QtGui.QLabel('Number of frames to capture: '))
    self.frameCount = QtGui.QSpinBox()
    self.frameCount.setRange(50, 500)
    self.frameCount.setValue(self.numberOfFrames)
    self.frameCount.valueChanged.connect(self.setNumberOfFrames)
    hlayout.addWidget(self.frameCount)
    hlayout.addStretch()
    
    self.layout.addLayout(hlayout)
    
    self.depthCameraController = DepthCameraStreamController(self.calibrationWizard.cameraSystem, None)
    self.dataEngine = DataEngine(self.depthCameraController)
    self.dataEngine.disableStatistics()
    
    self.captureRunning = False
    self.dataEngine.connectData("phase", self.computeAveragePhases, QtCore.Qt.QueuedConnection)
    
    self.dataView = DataViewContainer(self.dataEngine, 'phase', shouldLinkViewBox = False, showFormatMenu = True)
    
    self.layout.addWidget(self.dataView)
    
    self.progressBar = QtGui.QProgressBar()
    self.currentProgressValue = 0
    self.progressBar.setValue(0)
    
    self.layout.addWidget(self.progressBar)
    
    self.progressText = QtGui.QLabel()
    self.layout.addWidget(self.progressText)
    
    self.paramsGroupbox = QtGui.QGroupBox()
    self.paramsGroupbox.setTitle('Common Phase Parameters')
    self.layout.addWidget(self.paramsGroupbox)
    
    self.paramsText = QtGui.QLabel()
    
    vglayout = QtGui.QVBoxLayout()
    vglayout.addWidget(self.paramsText)
    self.paramsGroupbox.setLayout(vglayout)
    
    self.paramsGroupbox.hide()
    
    self.dataView.dataView.graphicsWidget.scene().sigMouseMoved.connect(self.getMousePosition)
    
    self.calibrated = False
    self.frameSize = None
    self.phaseData = None
    
  def setNumberOfFrames(self, value):
    self.numberOfFrames = value
    
  def isComplete(self):
    return self.calibrated
  
  def initializePage(self):
    if self.calibrationWizard.currentConfiguration.isPresent('calib', 'actual_distance'):
      self.distance.setValue(self.calibrationWizard.currentConfiguration.getFloat('calib', 'actual_distance'))
    
    super(CalibrationCommonPhasePage, self).initializePage()
    
    
    self.cx = round(self.calibrationWizard.currentConfiguration.getFloat('calib', 'cx'), 1)
    self.cy = round(self.calibrationWizard.currentConfiguration.getFloat('calib', 'cy'), 1)
    
    self.centerPointText.setText('From lens calibration, cx = %.1f, cy = %.1f'%(self.cx, self.cy))
    
  def enterPage(self):
    super(CalibrationCommonPhasePage, self).enterPage()
    self.depthCameraController.setDepthCamera(self.calibrationWizard.depthCamera)
    self.depthCameraController.start()
    
  def leavePage(self):
    self.depthCameraController.stop()
    
  def setProgress(self, progressIncrement, progressMessage = None):
    self.currentProgressValue += progressIncrement
    self.progressBar.setValue(self.currentProgressValue)
    
    if progressMessage != None:
      self.progressText.setText(progressMessage)
      
  def closePage(self):
    self.dataEngine.stop()
    
  def validatePage(self):
    r = super(CalibrationCommonPhasePage, self).validatePage()
    
    if r:
      print 'Stopping camera...'
      self.depthCameraController.disconnectDepthCamera(onlyFromUI = True)
      
    return r
    
  @QtCore.Slot(int, long, object)
  def computeAveragePhases(self, id, timestamp, frame):
    
    if not self.captureRunning:
      return
    
    self.phaseData = frame
    
    self.frameSize = [self.phaseData.shape[1], self.phaseData.shape[0]]
    
    if self.currentFrameCount == 0:
      r = r1 = False
      if self.dealiasEnabled:
        if self.phaseAverage1 == None:
          r = self.depthCamera.setb('ind_freq_data_en', True)
          r1 = self.depthCamera.setb('ind_freq_data_sel', False)
          self.setProgress(0, 'Computing phase offset for first modulation frequency...')
        else:
          r = self.depthCamera.setb('ind_freq_data_en', True)
          r1 = self.depthCamera.setb('ind_freq_data_sel', True)
          self.skipFrameTotalCount = 30
          self.setProgress(0, 'Computing phase offset for second modulation frequency...')
      else:
        r = r1 = True
        
      if not r or not r1:
        self.stopCalibration()
    
    if self.skipFrameCount < self.skipFrameTotalCount:
      self.skipFrameCount += 1
      self.currentFrameCount += 1
      return
      
    
    if self.phaseAverage == None:
      self.phaseAverage = np.zeros((self.averageWindow, self.averageWindow), dtype='complex')
      
    phase = self.dataEngine.data['phase']\
      [self.centerShape[0]:self.centerShape[1], self.centerShape[2]:self.centerShape[3]]*np.pi/2048
    self.phaseAverage += self.dataEngine.data['amplitude']\
      [self.centerShape[0]:self.centerShape[1], self.centerShape[2]:self.centerShape[3]]*(np.cos(phase)+1j*np.sin(phase))
    self.currentFrameCount += 1
    self.setProgress(self.progressPercentage/self.numberOfFrames, None)
    
    if self.currentFrameCount >= self.numberOfFrames + self.skipFrameTotalCount:
      self.phaseAverage /= self.numberOfFrames
      self.phaseAverage = np.sum(self.phaseAverage)/self.averageWindow/self.averageWindow
      self.phaseAverage = np.angle(self.phaseAverage)*(4096/(2*math.pi))
      
      if not self.dealiasEnabled:
        self.phaseAverage1 = self.phaseAverage
        self.phaseAverage = None
        self.currentFrameCount = 0
        self.finishCalibration()
      elif self.phaseAverage1 != None:
        self.phaseAverage2 = self.phaseAverage
        self.phaseAverage = None
        self.finishCalibration()
      else:
        self.phaseAverage1 = self.phaseAverage
        self.phaseAverage = None
        self.currentFrameCount = 0
        
  def getMousePosition(self, pos):
    p = self.dataView.dataView.imageItem.mapFromScene(pos)
    
    if self.dataEngine.frameSize != None and self.phaseData != None:
      if p.x() < 0 or p.x() >= self.frameSize[0] or p.y() < 0 or p.y() >= self.frameSize[1]:
        return
      
      x = int(p.x())
      y = int(p.y())
      
      self.progressText.setText('Current point (%d, %d). Phase = %d'%(x, y, self.phaseData[y, x]))
      
  def calibrate(self):
    r, dealiasEnabled = self.depthCamera.getb('dealias_en')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Failed', 'Could not read "dealias_en" parameter')
      return
    
    self.dealiasEnabled = dealiasEnabled
    
    if self.dealiasEnabled:
      self.progressPercentage = 50.0
    else:
      self.progressPercentage = 100.0
      
    print self.progressPercentage, self.dealiasEnabled
    
    self.averageWindow = 4 # Use even numbers only
    self.centerShape = [self.cy - self.averageWindow/2, self.cy + self.averageWindow/2,
                        self.cx - self.averageWindow/2, self.cx + self.averageWindow/2]
    
    self.phaseAverage = None
    self.phaseAverage1 = self.phaseAverage2 = None
    self.currentFrameCount = 0
    self.skipFrameTotalCount = 0
    self.skipFrameCount = 0
    self.captureRunning = True
    self.currentProgressValue = 0
    self.calibrateButton.setDisabled(True)
    
  def stopCalibration(self):
    self.phaseAverage = None
    self.captureRunning = False
    self.currentProgressValue = 0
    self.progressBar.setValue(0)
    self.calibrateButton.setEnabled(True)
    
    r = self.depthCamera.setb('ind_freq_data_en', False)
    
  def finishCalibration(self):
    self.stopCalibration()
    
    if self.phaseAverage1 == None or (self.dealiasEnabled and self.phaseAverage2 == None):
      QtGui.QMessageBox.critical(self, 'Data Missing', 'Cannot perform calibration with missing data')
      return
    
    r, tSensorCalib = self.depthCamera.geti('tsensor')
    r1, tIllumCalib = self.depthCamera.geti('tillum')
    
    if not r:
      tSensorCalib = 0
      QtGui.QMessageBox.critical(self, 'Sensor temperature', 'Could not get sensor temperature')
      return
      
    if not r1:
      tIllumCalib = 0
      
    if tSensorCalib < 0:
      tSensorCalib = tIllumCalib
      
    r, mf1 = self.depthCamera.getf("mod_freq1")
    ds1 = c/(2*mf1*1E6)
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Modulation Frequency', 'Failed to get modulation frequency 1')
      return
    
    phaseActual1 = self.distance.value()/ds1*4096
    
    print '\nphaseActual1 = ', phaseActual1
    
    if self.dealiasEnabled:
      r1, mf2 = self.depthCamera.getf("mod_freq2")
      ds2 = c/(2*mf2*1E6)
      
      if not r:
        QtGui.QMessageBox.critical(self, 'Modulation Frequency', 'Failed to get modulation frequency 2')
        return
    
      phaseActual2 = self.distance.value()/ds2*4096
      
      print '\nphaseActual2 = ', phaseActual2
    else:
      phaseActual2 = phaseActual1
    
    if self.phaseAverage2 == None:
      self.phaseAverage2 = phaseActual2 # Canceling out and setting to zero
      
    self.calibParams['tillum_calib'] = int(tIllumCalib)
    self.calibParams['tsensor_calib'] = int(tSensorCalib)
    
    additivePhase = self.depthCamera.getb('phase_corr_add')
    
    if additivePhase:
      self.calibParams['phase_corr_1'] = int(self.wrapPhaseToSignedInteger(phaseActual1 - self.phaseAverage1))
      self.calibParams['phase_corr_2'] = int(self.wrapPhaseToSignedInteger(phaseActual2 - self.phaseAverage2))
    else:  
      self.calibParams['phase_corr_1'] = int(self.wrapPhaseToSignedInteger(self.phaseAverage1 - phaseActual1))
      self.calibParams['phase_corr_2'] = int(self.wrapPhaseToSignedInteger(self.phaseAverage2 - phaseActual2))
    self.calibParams['actual_distance'] = self.distance.value()
    
    self.paramsText.setText('tillum_calib = %d, tsensor_calib = %d, \nphase_corr_1 = %d, phase_corr_2 = %d,\n'%\
      (tIllumCalib, tSensorCalib, self.calibParams['phase_corr_1'], self.calibParams['phase_corr_2']))
    self.paramsGroupbox.show()
    self.calibrated = True
    
    self.completeChanged.emit()
  
  def wrapPhaseToSignedInteger(self, phase):
    if phase >= CalibrationCommonPhasePage.MAX_PHASE_VALUE/2:
      return -1*(CalibrationCommonPhasePage.MAX_PHASE_VALUE - phase)
    elif phase < -CalibrationCommonPhasePage.MAX_PHASE_VALUE/2:
      return (CalibrationCommonPhasePage.MAX_PHASE_VALUE + phase)
    else:
      return phase