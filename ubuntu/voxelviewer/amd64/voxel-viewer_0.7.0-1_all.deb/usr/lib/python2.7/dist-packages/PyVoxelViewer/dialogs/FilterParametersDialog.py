#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

import Voxel

from PyVoxelViewer.views.ParameterHandler import *

from functools import partial

class FilterParametersDialog(QtGui.QDialog):
  def __init__(self, filter, parent = None):
    super(FilterParametersDialog, self).__init__(parent)
    
    self.setWindowTitle('Filter Parameters (' + filter.name() + ')')
    self.setMinimumWidth(100)
    self.setMinimumHeight(80)

    self.filter = filter
    
    params = self.filter.parameters().values()
    
    layout = QtGui.QVBoxLayout(self)
    glayout = QtGui.QGridLayout()
    glayout.setSizeConstraint(QtGui.QLayout.SetMaximumSize)
    count = 0
    for p in params:
      l = QtGui.QLabel(p.displayName())
      l.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
      glayout.addWidget(l, count, 0, QtCore.Qt.AlignRight)
      paramHandler = ParameterHandler.getParameterHandler(filter, p, paramSetType = ParameterHandler.PARAM_TYPE_FILTER)
      paramWidget = paramHandler.getDisplayWidget()
      paramWidget.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
      l.setToolTip(p.description())
      paramWidget.setToolTip(p.description())
      glayout.addWidget(paramWidget, count, 1, QtCore.Qt.AlignLeft)
      paramWidget.paramValueChanged.connect(partial(self.setParam, paramHandler))
      count = count + 1
      
    layout.addStretch(0)
    l = QtGui.QLabel(filter.name())
    l.setAlignment(QtCore.Qt.AlignCenter)
    l.setStyleSheet('font-weight: 500;')
    layout.addWidget(l)
    layout.addStretch(0)
    layout.addLayout(glayout)
    layout.addStretch(0)
      
  def setParam(self, paramHandler, value):
    r, v = paramHandler.set(value)
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Parameter Set Failed', 'Failed to set parameter')

  ## static method to create the dialog and return
  @staticmethod
  def showDialog(filter, parent = None):
    dialog = FilterParametersDialog(filter, parent)
    dialog.exec_()
    return None