#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtCore, QtGui

from PyVoxelViewer.views.ParameterHandler import ParameterHandler
from PyVoxelViewer.models.Config import Config

import os

import shutil

import Voxel

#from scipy.constants import c
c = 299792458 # m/s

class Calibration(object):
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}):
    self.calibIndex = index
    self.definingParams = definingParams
    self.calibParams = calibParams
    self.calibrationWizard = calibrationWizard
    
  def needsCalibration(self):
    calib = False
    for p in self.definingParams:
      
      if p == 'frame_rate':
        r, f = self.calibrationWizard.depthCamera.getFrameRate()
        
        if not r:
          return True
        
        f1 = self.calibrationWizard.previousConfiguration.getFloat('defining_params', p)
        
        if int(f.getFrameRate()*100) != int(f1*100):
          return True
        
        continue
      
      param = ParameterHandler.getParameterHandler(self.calibrationWizard.depthCamera, p)
      
      if not param:
        continue
      
      r, v1 = param.get()
      
      if not r:
        return True
        
      if param.type == 'Int' or param.type == 'Uint':
        v2 = self.calibrationWizard.previousConfiguration.getInteger('defining_params', p)
        if v1 != v2:
          return True
      
      elif param.type == 'Float':
        v2 = self.calibrationWizard.previousConfiguration.getFloat('defining_params', p)
        if int(v1*100) != int(v2*100):
          return True
        
      elif param.type == 'Bool':
        v2 = self.calibrationWizard.previousConfiguration.getBoolean('defining_params', p)
        
        if v1 != v2:
          return True
      
      
    return not self.isPresentInPrevious()
    
  def isPresentInPrevious(self):
    for c in self.calibParams.keys():
      if not self.calibrationWizard.previousConfiguration.isPresent('calib', c):
        return False
    return True
    
    
class CalibrationPage(QtGui.QWizardPage):
  
  FILE_PREFIX = 'file:'
  CHIPSET_TINTIN = 'tintin.ti'
  CHIPSET_HADDOCK = 'haddock.ti'
  CHIPSET_CALCULUS = 'calculus.ti'
  
  def __init__(self, calibrationWizard, index, definingParams = [], calibParams = {}, parent = None):
    super(CalibrationPage, self).__init__(parent)
    
    self.calibrationWizard = calibrationWizard
    self.calibIndex = index
    self.depthCamera = self.calibrationWizard.depthCamera
    
    self.chipset = self.depthCamera.chipset()
    
    self.definingParams = definingParams
    
    self.calibParams = calibParams
    
    self.calibrationObject = Calibration(calibrationWizard, index, definingParams, calibParams)
    
    self.doShow = self.needsCalibration()
    
  def writeDefiningParams(self):
    for p in self.definingParams:
      if p == 'frame_rate':
        r, f = self.depthCamera.getFrameRate()
        
        if not r:
          return True
        
        self.calibrationWizard.currentConfiguration.set('defining_params', p, str(f.getFrameRate()))
        continue
        
      param = ParameterHandler.getParameterHandler(self.depthCamera, p)
      
      if not param:
        continue
      
      r, v1 = param.get()
      
      if not r:
        return False
      
      self.calibrationWizard.currentConfiguration.set('defining_params', p, str(v1))
  
  def needsCalibration(self):
    return self.calibrationObject.needsCalibration()
  
  def isPresentInPrevious(self):
    return self.calibrationObject.isPresentInPrevious()
  
  def disableThisAndNextCalibrations(self):
    disableIndices = 0
    
    for p in self.calibrationWizard.pages:
      if p.calibIndex >= self.calibIndex:
        disableIndices += (1 << p.calibIndex)
      
    print "indices to disable = %x"%disableIndices
    self.calibrationWizard.currentConfiguration.setInteger("calib", Voxel.CALIB_DISABLE, disableIndices)
    
  # Copy from previous configuration, and don't configure newly
  def copyCalibrationFromPrevious(self):
    if not self.calibrationWizard.currentConfiguration:
      return 
    
    for c in self.calibParams.keys():
      self.calibrationWizard.currentConfiguration.set('calib', c, \
        self.calibrationWizard.previousConfiguration.get('calib', c))
      self.calibParams[c] = self.calibrationWizard.previousConfiguration.get('calib', c)
  
  # Remove this calibration from current configuration
  def removeCalibration(self):
    if not self.calibrationWizard.currentConfiguration:
      return 
    
    for c in self.calibParams.keys():
      self.calibrationWizard.currentConfiguration.remove('calib', c)
      
  def initializePage(self):
    c = Voxel.Configuration()
    r, self.basePath = c.getLocalPath('profiles')
    
    if not r:
      QtGui.QMessageBox.critical(self, 'Path failed', 'Failed to get base path')
      return
    
    self.basePath += os.sep + self.depthCamera.name() + os.sep + self.calibrationWizard.currentProfileName
    
    print 'Base path = ', self.basePath
    
    if not os.path.exists(self.basePath):
      os.makedirs(self.basePath)
      
    self.leavePage()
      
  def cleanupPage(self):
    self.leavePage()
    
  def enterPage(self):
    self.disableThisAndNextCalibrations()
    pass
  
  def leavePage(self):
    pass
  
  def closePage(self):
    pass
    
  def validatePage(self):
    if self.isComplete():
      if not self.calibrationWizard.currentConfiguration:
        return False
      for c, v in self.calibParams.iteritems():
        self.calibrationWizard.currentConfiguration.set('calib', c, str(v))
        
      self.leavePage()
      return True
    else:
      return False
    
    
from CalibrationInitPage import CalibrationInitPage
from CalibrationLensPage import CalibrationLensPage
from CalibrationCommonPhasePage import CalibrationCommonPhasePage
from CalibrationPixelwisePhasePage import CalibrationPixelWisePhasePage
from CalibrationFrequencyPage import CalibrationFrequencyPage
from CalibrationTemperaturePage import CalibrationTemperaturePage
from CalibrationCrossTalkPage import CalibrationCrossTalkPage
from CalibrationNonLinearityPage import CalibrationNonLinearityPage
from CalibrationConclusionPage import CalibrationConclusionPage
    
class CalibrationWizard(QtGui.QWizard):
  
  def __init__(self, cameraSystem, depthCamera, editIndex = -1, parent = None, flags = 0):
    super(CalibrationWizard, self).__init__(parent, flags)
    
    self.ready = False
    
    self.depthCamera = depthCamera
    self.cameraSystem = cameraSystem
    
    self.setMinimumHeight(600)
    self.setMinimumWidth(400)
    
    self.setWizardStyle(QtGui.QWizard.ModernStyle)
    self.setWindowTitle('Calibration Wizard')
    self.setOption(QtGui.QWizard.IndependentPages, False)
    
    self.mainConfiguration = self.depthCamera.configFile
    self.setPreviousConfiguration(self.depthCamera.getCurrentCameraProfileID())
    self.currentConfiguration = None
    self.currentProfileID = None
    self.currentProfileFileName = None
    self.isNewProfile = False
    
    self.addPage(CalibrationInitPage(self, editIndex))
    
    info = self.depthCamera.configFile.getCalibrationInformation()
    
    calibPages = [
      ('lens', CalibrationLensPage), 
      ('frequency', CalibrationFrequencyPage),
      ('cross_talk', CalibrationCrossTalkPage), 
      ('non_linearity', CalibrationNonLinearityPage), 
      ('temperature', CalibrationTemperaturePage),
      ('common_phase_offset', CalibrationCommonPhasePage), 
      ('pixelwise_phase_offset', CalibrationPixelWisePhasePage)
    ]

    self.pages = []
    for i, c in calibPages:
      if info.has_key(i):
        inf = info[i]
        p = c(self, inf.id, definingParams = list(inf.definingParameters), calibParams = dict((el, 0) for el in list(inf.calibrationParameters)))
        self.addPage(p)
        self.pages.append(p)
        
    
    self.addPage(CalibrationConclusionPage(self))
    
    self.accepted.connect(self.onCompletion)
    self.rejected.connect(self.restorePreviousCondition)
    
    self.ready = True
    
    self.currentIdChanged.connect(self.onPageChange)
    
    self.saveToHW = False
    self.setAsDefault = True
    
  def setPreviousConfiguration(self, id):
    c = self.depthCamera.configFile.getCameraProfile(id)
    
    if not c:
      QtGui.QMessageBox.critical(self, 'Calibration Wizard', 'Could not get configuration for camera profile "' + self.depthCamera.getCurrentCameraProfileID() + '"')
      return
    
    self.previousConfiguration = Voxel.ConfigurationFile(c)
    self.previousProfileID = self.depthCamera.getCurrentCameraProfileID()
    
  def isReady(self):
    return self.ready
  
  def onCompletion(self):
    if self.currentConfiguration:
      self.currentConfiguration.remove("calib", Voxel.CALIB_DISABLE)
    
    if self.saveToHW or (self.currentConfiguration and self.currentConfiguration.getLocation() == Voxel.ConfigurationFile.IN_CAMERA):
      if self.currentProfileID:
        #ProgressDialog.setProgress(False, -1, 'Saving to hardware...')

        r, id = self.depthCamera.saveCameraProfileToHardware(self.currentProfileID)
        if not r:
          QtGui.QMessageBox.warning(self, 'Save Profile to Hardware', 'Failed to save camera profile to hardware')
        else:
          if self.setAsDefault:
            self.depthCamera.configFile.setDefaultCameraProfile(id)
        if self.currentConfiguration and self.currentConfiguration.getLocation() == Voxel.ConfigurationFile.IN_HOST:
          self.currentConfiguration.write() # Save
          
          if self.setAsDefault:
            self.depthCamera.configFile.setDefaultCameraProfile(self.currentProfileID)
        
        #ProgressDialog.setProgress(True, 100, '')
    else:
      if self.currentConfiguration:
        self.currentConfiguration.write() # Save
    
      if self.setAsDefault:
        self.depthCamera.configFile.setDefaultCameraProfile(self.currentProfileID)
    
  
  def onPageChange(self, currentID):
    p = self.currentPage()
    
    if isinstance(p, CalibrationPage):
      p.enterPage()
  
  def closePages(self):
    for p in self.pages:
      if isinstance(p, CalibrationPage):
        p.closePage()
  
  def restorePreviousCondition(self):
    
    if self.isNewProfile and self.currentProfileID:
      self.depthCamera.removeCameraProfile(self.currentProfileID)
      
    if not self.isNewProfile and self.previousConfiguration:
      p = self.depthCamera.configFile.getCameraProfile(self.previousProfileID)
      
      if p:
        p.copy(self.previousConfiguration)
    
    self.depthCamera.setCameraProfile(self.previousProfileID)
    
  def nextId(self):
    p = self.currentPage()
    
    id = self.currentId() + 1
    nextPage = self.page(id)
    
    if not nextPage:
      return -1
    
    if not isinstance(nextPage, CalibrationPage):
      return id
    
    while nextPage and not nextPage.doShow:
      if not nextPage.isPresentInPrevious():
        if not hasattr(nextPage, 'skipQuestionAnswer'):
          # r = QtGui.QMessageBox.question(self, nextPage.title(), 'Necessary parameters are not present for skipping "' + nextPage.title() + '" step.' + 
          #                        ' Do you want to really skip this step?', 
          #                        buttons = QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
          # 
          # if r == QtGui.QMessageBox.No:
          # return id
          # else:
          # nextPage.skipQuestionAnswer = True
          nextPage.skipQuestionAnswer = True
        else:
          if not nextPage.skipQuestionAnswer:
            return id
      id = id + 1
      nextPage = self.page(id)
      
      if not isinstance(nextPage, CalibrationPage):
        return id
    
    if not nextPage:
      return -1
    else:
      return id
    
    