#
# TI Voxel Viewer component.
#
# Copyright (c) 2014 Texas Instruments Inc.
#

from PySide import QtGui, QtCore

import math

import Voxel

from functools import partial

from PyVoxelViewer.dialogs.FilterParametersDialog import FilterParametersDialog

FrameTypeToName = {
  Voxel.DepthCamera.FRAME_RAW_FRAME_UNPROCESSED: "Raw Frame (unprocessed)",
  Voxel.DepthCamera.FRAME_RAW_FRAME_PROCESSED: "Raw Frame (processed)",
  Voxel.DepthCamera.FRAME_DEPTH_FRAME: "Depth\nFrame",
  Voxel.DepthCamera.FRAME_XYZI_POINT_CLOUD_FRAME: "Point Cloud\nFrame"
}

class DataBlock(object):
  
  def __init__(self, dataDiagramDockWidget, blockName, inputType, outputType, status = ''):
    self.blockName = blockName
    self.status = status
    self.inputType = inputType
    self.outputType = outputType
    self.dataDiagramDockWidget = dataDiagramDockWidget


class ProcessBlock(DataBlock):
  def __init__(self, dataDiagramDockWidget, inputType, outputType, status = ''):
    super(ProcessBlock, self).__init__(dataDiagramDockWidget, FrameTypeToName[outputType], inputType, outputType, status)



class DataBlockView(QtGui.QGraphicsRectItem):
  
  def __init__(self, dataBlock, size = [100, 100]):
    super(DataBlockView, self).__init__()
    self.dataBlock = dataBlock
    self.blockName = dataBlock.blockName
    self.size = size
    self.status = dataBlock.status
    self.inputType = dataBlock.inputType
    self.outputType = dataBlock.outputType
    self.dataDiagramDockWidget = dataBlock.dataDiagramDockWidget
    
    self.setRect(self.boundingRect())
    
    self.textOption = QtGui.QTextOption()
    self.textOption.setAlignment(QtCore.Qt.AlignCenter)
    self.textOption.setWrapMode(QtGui.QTextOption.WrapAtWordBoundaryOrAnywhere)
    self.initMenu()
    
  def boundingRect(self):
    return QtCore.QRectF(0, 0, self.size[0], self.size[1])
  
  def paint(self, painter, option, widget):
    painter.setPen(QtGui.QPen(QtGui.QColor('black')))
    painter.setBrush(QtGui.QBrush(QtGui.QColor('white')))
    rect = QtCore.QRectF(self.boundingRect())
    painter.drawRect(rect)
    painter.drawText(rect, self.blockName, self.textOption)
    rect.moveTop(self.size[1])
    painter.drawText(rect, self.status, self.textOption)
    super(DataBlockView, self).paint(painter, option, widget)
    
  def initMenu(self):
    self.menu = QtGui.QMenu()
    
    if self.inputType != None:
      filters = self.dataDiagramDockWidget.getFiltersFor(self.inputType)
      
      if len(filters) > 0:
        self.filtersBeforeMenu = QtGui.QMenu('Add Filter Before')
        
        for f in filters:
          fa = QtGui.QAction(f, self.dataDiagramDockWidget)
          fa.triggered.connect(partial(self.dataDiagramDockWidget.addFilterBefore, self.dataBlock, f, self.inputType))
          self.filtersBeforeMenu.addAction(fa)
          
        self.menu.addMenu(self.filtersBeforeMenu)
        
    if self.outputType != None:
      filters = self.dataDiagramDockWidget.getFiltersFor(self.outputType)
      
      if len(filters) > 0:
        self.filtersAfterMenu = QtGui.QMenu('Add Filter After')
        
        for f in filters:
          fa = QtGui.QAction(f, self.dataDiagramDockWidget)
          fa.triggered.connect(partial(self.dataDiagramDockWidget.addFilterAfter, self.dataBlock, f, self.outputType))
          self.filtersAfterMenu.addAction(fa)
          
        self.menu.addMenu(self.filtersAfterMenu)
  
  def contextMenuEvent(self, event):
    self.menu.popup(event.screenPos())
    event.accept()



class ProcessBlockView(DataBlockView):
  def __init__(self, processBlock, size = [100, 100]):
    super(ProcessBlockView, self).__init__(processBlock, size)
    
class FilterBlock(DataBlock):
  
  def __init__(self, filter, filterIndex, dataDiagramDockWidget, inputType, outputType, status = ''):
    super(FilterBlock, self).__init__(dataDiagramDockWidget, filter.name().replace('::','::\n'), inputType, outputType, status)
    
    self.filter = filter
    self.filterIndex = filterIndex


class FilterBlockView(DataBlockView):
  
  def __init__(self, filterBlock, size = [100, 100]):
    super(FilterBlockView, self).__init__(filterBlock, size)
  
  def initMenu(self):
    super(FilterBlockView, self).initMenu()
    
    self.menu.addSeparator()
    
    fa = QtGui.QAction('Move Left', self.dataDiagramDockWidget)
    fa.triggered.connect(partial(self.dataDiagramDockWidget.moveFilterLeft, self.dataBlock))
    self.menu.addAction(fa)
    
    fa = QtGui.QAction('Move Right', self.dataDiagramDockWidget)
    fa.triggered.connect(partial(self.dataDiagramDockWidget.moveFilterRight, self.dataBlock))
    self.menu.addAction(fa)
    
    fa = QtGui.QAction('Remove', self.dataDiagramDockWidget)
    fa.triggered.connect(partial(self.dataDiagramDockWidget.removeFilter, self.dataBlock))
    self.menu.addAction(fa)
    
    fa = QtGui.QAction('Properties', self.dataDiagramDockWidget)
    fa.triggered.connect(partial(self.dataDiagramDockWidget.showFilterParameters, self.dataBlock))
    self.menu.addAction(fa)


class DataArrow(QtGui.QGraphicsLineItem):
  
  def __init__(self, type, size = [100, 100]):
    QtGui.QGraphicsLineItem.__init__(self)
    self.caption = FrameTypeToName[type]
    self.length = size[0]
    self.myColor = QtCore.Qt.black
    self.setPen(QtGui.QPen(self.myColor, 2, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin));
    self.arrowSize = 5
    self.type = type
    
    self.size = size
    
    self.textOption = QtGui.QTextOption()
    self.textOption.setAlignment(QtCore.Qt.AlignCenter)
    self.textOption.setWrapMode(QtGui.QTextOption.WrapAtWordBoundaryOrAnywhere)
    
  def boundingRect(self):
    return QtCore.QRectF(0, 0, self.size[0], self.size[1])
    #extra = (self.pen().width() + 20) / 2.0;
    #return QtCore.QRectF(self.line().p1(), QtCore.QSizeF(self.line().p2().x() - self.line().p1().x(), self.line().p2().y() - self.line().p1().y())).normalized().adjusted(-extra, -extra, extra, extra);
  
  def makeArrowHead(self, angle):
    arrowP1 = self.line().p2() - QtCore.QPointF(math.sin(angle + math.pi / 3) * self.arrowSize, math.cos(angle + math.pi / 3) * self.arrowSize)
    arrowP2 = self.line().p2() - QtCore.QPointF(math.sin(angle + math.pi* 2.0 / 3) * self.arrowSize, math.cos(angle + math.pi * 2.0 / 3) * self.arrowSize);

    self.arrowHead = QtGui.QPolygonF([arrowP1, arrowP2, self.line().p2()])
  
  def shape(self):
    path = super(DataArrow, self).shape()
    path.addPolygon(self.arrowHead)
    return path
  
  def updateLine(self):
    self.setLine(0, self.size[1]/2, self.length, self.size[1]/2)
  
  def paint(self, painter, option, widget):
    myPen = self.pen()
    myPen.setColor(self.myColor)
    painter.setPen(myPen)
    painter.setBrush(self.myColor)
    
    self.updateLine()
    
    angle = math.acos(self.line().dx() / self.line().length())
    if self.line().dy() > 0:
      angle = (math.pi * 2) - angle

    self.makeArrowHead(angle)
    
    painter.drawLine(self.line())
    painter.drawPolygon(self.arrowHead)
    painter.drawText(self.boundingRect(), self.caption, self.textOption)


class DataDiagramDockWidget(QtGui.QDockWidget):
  
  def __init__(self, cameraSystem, depthCameraController):
    QtGui.QDockWidget.__init__(self, "Data Flow Diagram")
    self.setMinimumHeight(150)
    
    self.cameraSystem = cameraSystem
    self.depthCameraController = depthCameraController
    self.depthCameraController.onDepthCameraSet.connect(self.setDepthCamera)
    self.setDepthCamera()
    
    self.diagram = QtGui.QGraphicsScene(self)
    
    self.mwidget = QtGui.QGraphicsView(self.diagram)
    
    self.setWidget(self.mwidget)
    
    self.sizeX = 95
    self.sizeY = 60
    self.size = [self.sizeX, self.sizeY]
    
    self.prepareFilterData()
    self.prepareData()
    self.prepareDiagram()
    
  def prepareData(self):
    
    self.items = []
    
    self.items.append(ProcessBlock(self, None, Voxel.DepthCamera.FRAME_RAW_FRAME_UNPROCESSED))
    self.items.append(ProcessBlock(self, Voxel.DepthCamera.FRAME_RAW_FRAME_UNPROCESSED, Voxel.DepthCamera.FRAME_RAW_FRAME_PROCESSED))
    self.items.append(ProcessBlock(self, Voxel.DepthCamera.FRAME_RAW_FRAME_PROCESSED, Voxel.DepthCamera.FRAME_DEPTH_FRAME))
    self.items.append(ProcessBlock(self, Voxel.DepthCamera.FRAME_DEPTH_FRAME, Voxel.DepthCamera.FRAME_XYZI_POINT_CLOUD_FRAME))
    
    
  def addFilter(self, filterName, type, beforeFilterIndex, blockPosition):
    if self.depthCamera == None:
      QtGui.QMessageBox.critical(self, 'Depth Camera Missing', 'No depth camera selected to add filter')
      return False
    
    # Allow passing already created filter
    if isinstance(filterName, str):
      filter = self.cameraSystem.createFilter(filterName, type)
    else:
      filter = filterName
      filterName = filter.name()
    
    if filter == None:
      QtGui.QMessageBox.critical(self, 'Filter not found', 'Could not create filter "' + filterName + '"')
      return False
    
    filterIndex = self.depthCamera.addFilter(filter, type, beforeFilterIndex)
    
    if filterIndex < 0:
      QtGui.QMessageBox.critical(self, 'Failed to add filter', 'Could not add filter "' + filterName + '"')
      del filter
      return False
    
    self.items.insert(blockPosition, FilterBlock(filter, filterIndex, self, type, type, ''))
    self.prepareDiagram()
    
    return True
    
  def addFilterAfter(self, item, filterName, type):
    if item not in self.items:
      QtGui.QMessageBox.critical(self, 'Internal Error', 'Item not present?')
      return
    
    blockPosition = self.items.index(item)
    
    self.addFilter(filterName, type, self.getNextFilterIndex(item), blockPosition + 1)
    
      
      
  def addFilterBefore(self, item, filterName, type):
    if item not in self.items:
      QtGui.QMessageBox.critical(self, 'Internal Error', 'Item not present?')
      return
    
    blockPosition = self.items.index(item)
    
    self.addFilter(filterName, type, self.getPreviousFilterIndex(item), blockPosition)
    
  def getNextFilterIndex(self, item):
    if item not in self.items:
      return -1
    
    i = self.items.index(item)
    
    i = i + 1
    if i >= len(self.items):
      return -1
    
    item = self.items[i]
    
    if isinstance(item, ProcessBlock):
      return -1
    else:
      return item.filterIndex
    
  def getPreviousFilterIndex(self, item):
    if isinstance(item, ProcessBlock):
      return -1
    else:
      return item.filterIndex
    
  def setDepthCamera(self):
    self.depthCamera = self.depthCameraController.getDepthCamera()
    
  def prepareFilterData(self):
    self.filters = {
      Voxel.DepthCamera.FRAME_RAW_FRAME_UNPROCESSED: [],
      Voxel.DepthCamera.FRAME_RAW_FRAME_PROCESSED: [],
      Voxel.DepthCamera.FRAME_DEPTH_FRAME: [],
      Voxel.DepthCamera.FRAME_XYZI_POINT_CLOUD_FRAME: []
    }
    
    filters = self.cameraSystem.getSupportedFilters()
    
    types = self.filters.keys()
    
    for f in filters:
      d = Voxel.FilterDescription()
      
      r = self.cameraSystem.getFilterDescription(f, d)
      
      if not r:
        continue
      
      for t in types:
        if d.supports(t):
          self.filters[t].append(f)
          
  def getFiltersFor(self, type):
    return self.filters[type]
    
  def prepareDiagram(self):
    
    self.diagram.clear()
    
    x = 0
    y = 0
    for i in range(0, len(self.items)):
      if isinstance(self.items[i], ProcessBlock):
        block = ProcessBlockView(self.items[i], self.size)
      else:
        block = FilterBlockView(self.items[i], self.size)
      block.setPos(x, y)
      self.diagram.addItem(block)
      x += self.sizeX
      
      arrow = DataArrow(self.items[i].outputType, [self.sizeX, self.sizeY])
      arrow.setPos(x, y)
      self.diagram.addItem(arrow)
      x += self.sizeX
      
  
  def getLeftItem(self, item):
    
    index = self.items.index(item)
    if index <= 0:
      return None
    
    return self.items[index - 1]
  
  def getRightItem(self, item):
    
    index = self.items.index(item)
    if index < 0 or index == len(self.items) - 1:
      return None
    
    return self.items[index + 1]
    
      
  def moveFilterLeft(self, item):
    if not isinstance(item, FilterBlock):
      QtGui.QMessageBox.critical(self, 'Not valid type', 'Item not a filter block?')
      return
    
    index = self.items.index(item)
    
    if index < 0:
      QtGui.QMessageBox.critical(self, 'Filter location', 'Item not present?')
      return
    
    if index == 0:
      QtGui.QMessageBox.critical(self, 'Cannot move filter', 'Filter is already the first item and cannot move it left.')
      return
    
    leftItem = self.items[index - 1]
    
    if isinstance(leftItem, FilterBlock):
      if self.removeFilter(item, False):
        item.filter.reset()
        self.addFilterBefore(leftItem, item.filter, item.inputType)
    else: # Process block
      QtGui.QMessageBox.critical(self, 'Cannot move filter', 'Filter is already the first item and cannot move it left.')
      return
      
    
  def moveFilterRight(self, item):
    if not isinstance(item, FilterBlock):
      QtGui.QMessageBox.critical(self, 'Not valid type', 'Item not a filter block?')
      return
    
    index = self.items.index(item)
    
    if index < 0:
      QtGui.QMessageBox.critical(self, 'Filter location', 'Item not present?')
      return
    
    if index == len(self.items) - 1:
      QtGui.QMessageBox.critical(self, 'Cannot move filter', 'Filter is already the last item and cannot move it right.')
      return
    
    rightItem = self.items[index + 1]
    
    if isinstance(rightItem, FilterBlock):
      if self.removeFilter(item, False):
        item.filter.reset()
        self.addFilterAfter(rightItem, item.filter, item.inputType)
    else: # Process block
      QtGui.QMessageBox.critical(self, 'Cannot move filter', 'Filter is already the last item and cannot move it right.')
      return
  
  def removeFilter(self, item, updateDiagram = True):
    if not isinstance(item, FilterBlock):
      QtGui.QMessageBox.critical(self, 'Not valid type', 'Item not a filter block?')
      return False
    
    index = self.items.index(item)
    
    if index < 0:
      QtGui.QMessageBox.critical(self, 'Filter location', 'Item not present?')
      return False
    
    if self.depthCamera == None:
      QtGui.QMessageBox.critical(self, 'Depth Camera Missing', 'No depth camera selected to add filter')
      return False
    
    if not self.depthCamera.removeFilter(item.filterIndex, item.outputType):
      QtGui.QMessageBox.critical(self, 'Remove Filter Failed', 'Failed to remove filter')
      return False
    
    del self.items[index]
    
    if updateDiagram:
      self.prepareDiagram()
    return True
  
  def showFilterParameters(self, item):
    FilterParametersDialog.showDialog(item.filter)